---
source_url: https://www.scrum.org/events/54546/agile-hartford-dec-2021-dave-west-increasing-velocity-value
date_scraped: 2025-06-29T05:44:38.368783
---

[ Skip to main content ](https://www.scrum.org/events/54546/agile-hartford-dec-2021-dave-west-increasing-velocity-value#main-content)
#  Agile Hartford Dec. 2021 - Dave West, 'Increasing the Velocity of Value'
At this Agile Hartford event, Dave West, CEO of Scrum.org talks about why orienting to value rather than work is critical to success.
Presentation Description:
Scrum is famous for introducing the idea of velocity. Increasing the amount of work that a team can deliver. But Scrum was never focused on increasing the velocity of work it was always focused on increasing the velocity of value. The ideas of self-management, goals, and the accountability of the Product Owner were meant to provide a foundation for teams to value-centric. But over the last 25 years, Scrum has often been applied to deliver work, a subtle but crucial difference. This has greatly reduced the ‘value’ that Scrum delivers and re-enforced many of the industrial concepts that agility was meant to replace.
In this talk, Dave West, CEO of Scrum.org talks about why orienting to value rather than work is a key requirement for building an agile capability, and how the 2020 update to the Scrum Guide provides a foundation for teams and organizations to review their approach to value.
Tonight's Presenter: Dave West
Dave West is the product owner and CEO at Scrum.org. He is a frequent keynote at major industry conferences and is a widely published author of articles and research reports. He also is the co-author of two books, The Nexus Framework For Scaling Scrum and Head First Object-Oriented Analysis and Design. He led the development of the Rational Unified Process (RUP) for IBM/Rational. After IBM/Rational, West returned to consulting and managed Ivar Jacobson Consulting for North America. Then as VP, research director Forrester research where he ran the software development and delivery practice. Prior to joining Scrum.org he was Chief Product Officer at Tasktop where he was responsible for product management, engineering and architecture. As a member of the company’s executive management team was also instrumental in growing Tasktop from a services business into a VC backed product business with a team of almost 100.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
