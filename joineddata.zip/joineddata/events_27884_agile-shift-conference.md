---
source_url: https://www.scrum.org/events/27884/agile-shift-conference
date_scraped: 2025-06-29T05:17:45.321525
---

[ Skip to main content ](https://www.scrum.org/events/27884/agile-shift-conference#main-content)
#  The Agile Shift Conference
This is a conference all about the unification of Agile and DevOps to build and deliver better teams and software. This one day industry event gathers professionals of all skill levels to learn and share ideas with each other. Dave West, CEO and Product Owner, Scrum.org is keynoting this event. 
[ visit event website ](https://theagileshift.com/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
