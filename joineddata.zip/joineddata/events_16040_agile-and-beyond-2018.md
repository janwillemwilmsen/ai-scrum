---
source_url: https://www.scrum.org/events/16040/agile-and-beyond-2018
date_scraped: 2025-06-29T05:07:19.110250
---

[ Skip to main content ](https://www.scrum.org/events/16040/agile-and-beyond-2018#main-content)
#  Agile and Beyond 2018
Agile & Beyond is a grassroots, volunteer run conference that helps people learn about agile principles and practices as well as covers topics that help make people and companies awesome. With pre-conference workshops and over 100 conference sessions, there is a wide variety of topics for the agile newbie all the way to the agile expert.
Eric Naiburg, VP of Marketing and Operations, Scrum.org will be presenting, "How to Avoid Reactive Agile to Build a Sustainable Agile Culture" On Thursday May 17, at 1:00 pm. 
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
