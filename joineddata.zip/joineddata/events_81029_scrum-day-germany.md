---
source_url: https://www.scrum.org/events/81029/scrum-day-germany
date_scraped: 2025-06-29T05:54:46.929600
---

[ Skip to main content ](https://www.scrum.org/events/81029/scrum-day-germany#main-content)
#  Scrum Day Germany
Germany
Der Scrum-Day hat sich im Laufe der Jahre zur größten Community Konferenz entwickelt. Schwerpunkte sind natürlich Scrum und alles rund um das beliebte agile Framework. So adressieren wir auch Themen wie agile Organisationsentwicklung, agile Strategien, agiles Management, Scrum und Agilität im großen Stil (Skalierung) und vieles mehr. Ziel der Veranstaltung ist es, den Teilnehmer:innen eine breite Kommunikationsplattform rund um Agilität und Scrum in der Praxis zu bieten.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
