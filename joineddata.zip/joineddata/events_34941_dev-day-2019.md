---
source_url: https://www.scrum.org/events/34941/dev-day-2019
date_scraped: 2025-06-29T05:31:44.024242
---

[ Skip to main content ](https://www.scrum.org/events/34941/dev-day-2019#main-content)
#  Dev Day 2019
Azerbaijan
Developers Day is one day event that filled with talks, panel discussions and networking – for, with and by developers and designers. The main goal of the event is to develop new opportunities and ideas for innovative technologies, design, and business. Professional Scrum Trainer [Martin Hinshelwood](https://www.scrum.org/martin-hinshelwood) will be speaking at the event. 
[ visit event website ](http://devday2019.az/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
