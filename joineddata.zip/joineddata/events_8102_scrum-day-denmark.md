---
source_url: https://www.scrum.org/events/8102/scrum-day-denmark
date_scraped: 2025-06-29T04:59:52.635225
---

[ Skip to main content ](https://www.scrum.org/events/8102/scrum-day-denmark#main-content)
#  Scrum Day Denmark
Denmark
Free event organized by [Mads Troels Hansen](https://www.scrum.org/user/97), [Ole Rich Henningsen](https://www.scrum.org/user/100), and [Mikkel Toudal Kristiansen](https://www.scrum.org/user/186) with the goal of improving the profession of software delivery across Denmark.
Gunther Verheyen kicks off the conference with a keynote: Re-vers-ify.
[ View Event Website ](https://scrumday.dk/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
