---
source_url: https://www.scrum.org/events/27393/agile-camp-berlin
date_scraped: 2025-06-29T05:16:04.869361
---

[ Skip to main content ](https://www.scrum.org/events/27393/agile-camp-berlin#main-content)
#  Agile Camp Berlin
Germany
Experience two energizing days with 200 agile peers focusing on community, sharing, and learning. Moreover, I am particularly excited that we will dedicate the second day to practicing games and exercises—from Liberating Structures to paper snowflakes and airplanes to building castles with 50 other folks, you have never met in your life!
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
