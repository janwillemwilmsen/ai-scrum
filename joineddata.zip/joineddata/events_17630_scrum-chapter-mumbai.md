---
source_url: https://www.scrum.org/events/17630/scrum-chapter-mumbai
date_scraped: 2025-06-29T05:10:27.401332
---

[ Skip to main content ](https://www.scrum.org/events/17630/scrum-chapter-mumbai#main-content)
#  Scrum Chapter Mumbai
India
The topic of this meetup presented by PSTs Hiren Doshi and Punit Doshi is Agile Scaling Frameworks.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
