---
source_url: https://www.scrum.org/events/46011/online-it-conference-frankfurter-entwicklertag-2021
date_scraped: 2025-06-29T05:39:38.064933
---

[ Skip to main content ](https://www.scrum.org/events/46011/online-it-conference-frankfurter-entwicklertag-2021#main-content)
#  Online IT Conference - Frankfurter Entwicklertag 2021
The conference with a focus on software engineering takes places on March 3rd and 4th and is 100% remote this year. You can expect a lot of interesting talks and workshops on agility, software quality, DevOps, and many more... Interested? Get your ticket now! Disclaimer: The talks and workshops are held in German language.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
