---
source_url: https://www.scrum.org/events/14805/scrum-chapter-meetup-mumbai
date_scraped: 2025-06-29T05:05:19.333007
---

[ Skip to main content ](https://www.scrum.org/events/14805/scrum-chapter-meetup-mumbai#main-content)
#  Scrum Chapter Meetup Mumbai
India
Professional Scrum Trainer [Hiren Doshi ](https://www.scrum.org/hiren-doshi)will be facilitating a session on how to “Lead Agile Adoption” as a Agile Coach based on my experience of past 12 years working with many Small, Medium and Large organizations. This will be an extremely interactive session without slides where as a team we will explore the Agile adoption at various dimensions like Top-Down buy-in, Engineering Practices, Organizations Culture, Vision, the Go to Market strategy, etc. 
> > > **When:** Saturday, 17th February 4:30pm to 7:00pm
>>> **Venue:**
>>> 1902, Lodha Supremus - Powai, 
>>> Opp. MTNL, Saki Vihar Road, Powai, Mumbai – 400072
>>> **Cost:** INR 200 (Pay at the venue)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
