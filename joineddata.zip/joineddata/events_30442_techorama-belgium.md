---
source_url: https://www.scrum.org/events/30442/techorama-belgium
date_scraped: 2025-06-29T05:22:50.481210
---

[ Skip to main content ](https://www.scrum.org/events/30442/techorama-belgium#main-content)
#  Techorama Belgium
Belgium
Professional Scrum Trainer Martin Hinshelwood will be speaking at this event. He will present "Scaling Unicorns and how to tame them", and "Agile is Dead, or is it". Learn more in the links below. [https://techoramabelgium2019.sched.com/event/KHzK/scaling-unicorns-and-how-to-tame-them?iframe=yes&w=100%&sidebar=yes&bg=dark](https://techoramabelgium2019.sched.com/event/KHzK/scaling-unicorns-and-how-to-tame-them?iframe=yes&w=100%&sidebar=yes&bg=dark) [https://techoramabelgium2019.sched.com/event/KI1H/agile-is-dead-or-is-it?iframe=yes&w=100%&sidebar=yes&bg=dark](https://techoramabelgium2019.sched.com/event/KI1H/agile-is-dead-or-is-it?iframe=yes&w=100%&sidebar=yes&bg=dark)
[ visit event website ](https://www.techorama.be/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
