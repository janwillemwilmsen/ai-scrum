---
source_url: https://www.scrum.org/events/14750/agile-india-2018
date_scraped: 2025-06-29T05:05:13.898553
---

[ Skip to main content ](https://www.scrum.org/events/14750/agile-india-2018#main-content)
#  Agile India 2018
India
[Agile India 2018](https://2018.agileindia.org/) is Asia's Largest and Premier International conference on Leading Edge Software Development Methods. Agile India is organized by [Agile Software Community of India](https://agileindia.org/), a non-profit registered society founded in 2004 with a vision to evangelize new, better ways of building products that delight the users.
Over the last **13 years** , we've organized **56 conferences** across **13 cities** in India. We've hosted **950+ speakers** from **38 countries** , who have delivered **1,100+** **sessions** to **8,500+** **attendees**. We continue to be a non-profit, volunteer-run community conference.
In 2018, we intend to focus on four key challenge areas that enterprises are heavily investing in. Each of the conference days would have a stand-alone program dedicated to a single area. An independent program committee, comprising of thought leaders from various companies will curate this program.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
