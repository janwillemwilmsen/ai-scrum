---
source_url: https://www.scrum.org/events/30160/meetup-scrum-mastery-what-why-and-how
date_scraped: 2025-06-29T05:22:17.162817
---

[ Skip to main content ](https://www.scrum.org/events/30160/meetup-scrum-mastery-what-why-and-how#main-content)
#  Meetup - Scrum Mastery - What, Why and How? 
India
This meetup if for Scrum Masters who would like to explore their role and responsibilities along with how to perform them. Who are the different stakeholders of a Scrum Master and what are the different stances a Scrum Master has to play for working with the stakeholders. The event is organized by Barco and sponsored by Scrum.org - The Home of Scrum. Barco designs technology to enable bright outcomes around the world. Seeing beyond the image, we develop visualization and collaboration solutions to help you work together, share insights, and wow audiences. Our focus is on three core markets: Enterprise (from meeting and control rooms to corporate spaces), Healthcare (from the radiology department to the operating room), and Entertainment (from movie theaters to live events and attractions). In 2018, we realized sales of 1.028 billion euro. We have a global team of 3,600 employees, whose passion for technology is captured in 400 granted patents.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
