---
source_url: https://www.scrum.org/events/7898/scrum-day-london
date_scraped: 2025-06-29T04:58:48.503678
---

[ Skip to main content ](https://www.scrum.org/events/7898/scrum-day-london#main-content)
#  Scrum Day London
United Kingdom
Now in its second year, Scrum Day London brings world-class Agile experts like [Dave West](https://www.scrum.org/user/252), [Ralph Jocham](https://www.scrum.org/user/110), [Martin Hinshelwood](https://www.scrum.org/user/184), [Jeronimo Palacios](https://www.scrum.org/user/148), [Barry Overeem](https://www.scrum.org/user/60), and Nana Abban to the heart of London. This year's theme: Growing your Agile Investment.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
