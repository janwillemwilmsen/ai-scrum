---
source_url: https://www.scrum.org/events/51379/scrum-gathering-tapei
date_scraped: 2025-06-29T05:43:31.850072
---

[ Skip to main content ](https://www.scrum.org/events/51379/scrum-gathering-tapei#main-content)
#  Scrum Gathering Tapei
Scrum Gathering Taipei takes place November 4-6. Patricia Kong will be speaking at the event.
[ visit event website ](https://rsg.taipei/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
