---
source_url: https://www.scrum.org/events/59923/scrum-facilitators-original-conference
date_scraped: 2025-06-29T05:47:04.865903
---

[ Skip to main content ](https://www.scrum.org/events/59923/scrum-facilitators-original-conference#main-content)
#  The Scrum Facilitators Original Conference
Netherlands
Sharing and collaborating on topics about Agility, Scrum and Kanban are in Scrum Facilitators’ DNA. usually, the more the merrier, but for this conference we make an exception. The event will be capped at 50 people.
This conference is an original conference and that means that you will see original, never seen before workshops and presentations.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
