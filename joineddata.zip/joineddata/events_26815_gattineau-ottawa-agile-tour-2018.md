---
source_url: https://www.scrum.org/events/26815/gattineau-ottawa-agile-tour-2018
date_scraped: 2025-06-29T05:15:12.238337
---

[ Skip to main content ](https://www.scrum.org/events/26815/gattineau-ottawa-agile-tour-2018#main-content)
#  Gattineau Ottawa Agile Tour 2018
Canada
GOAT 2018 is an awesome full day conference happening on Friday November 30th, 2018 at the Shaw Centre, centrally located in downtown Ottawa. GOAT has run for 7 years, and is part of the Agile Tour that takes place in 90 cities worldwide. Scrum.org will be exhibiting at this event and speakers include Kurt Bittner, [David Dame](https://www.scrum.org/david-dame) and [Pawel Mysliwiec](https://www.scrum.org/pawel-mysliwiec).
[ visit event website ](https://goagiletour.ca/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
