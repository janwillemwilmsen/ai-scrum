---
source_url: https://www.scrum.org/events/7084/scrumpulse-management-30-scrum
date_scraped: 2025-06-29T04:57:59.922589
---

[ Skip to main content ](https://www.scrum.org/events/7084/scrumpulse-management-30-scrum#main-content)
#  ScrumPulse: Management 3.0 & Scrum
### How to Become a Next Generation Agile Leader
Have you ever wondered what managers do in Scrum? Or maybe you have heard about Management 3.0 and wondered how it can help Agile Leaders. Interested in becoming a next generation Agile Leader who inspires Agile Teams to master the complexity of Software Delivery? If you answered yes to any of these questions, read on… With the increasing popularity of Agile Software Delivery, the management landscape is rapidly changing. Managers have a choice - be part of the new solution or become irrelevant with the status quo. If you chose to be part of the solution, you already made the first pivotal step toward Management 3.0. So what is exactly Management 3.0.? M3.0 is the third evolution in management:
  * M1.0 was all about hierarchies based on command and control. 
  * M2.0 was all about models like balanced scorecard, six sigma, and total quality management. These models are not wrong by itself but still don’t address the core problem: Complexity.
  * M3.0 is all about providing tools and exercises to cope with complexity.


Influence the conversation by tweeting your most challenging questions on this topic using @scrumdotorg #scrumpulse and then join us live for an interactive conversation.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
