---
source_url: https://www.scrum.org/events/29086/technical-agility-meetup
date_scraped: 2025-06-29T05:20:05.908930
---

[ Skip to main content ](https://www.scrum.org/events/29086/technical-agility-meetup#main-content)
#  Technical Agility Meetup
India
Have you ever practiced the Agile ways of working in a scaled environment involving multiple teams. How was your experience? Would you like to share it with others? Or would you like to hear from the others? The Technical Agility meetup will take place on April 5 and will feature Professional Scrum Trainer Sanjay Saini as a presenter. This is the second edition on the same topic and you are most welcome to join as a participant or as a speaker.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
