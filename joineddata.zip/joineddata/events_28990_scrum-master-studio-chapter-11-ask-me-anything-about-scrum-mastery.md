---
source_url: https://www.scrum.org/events/28990/scrum-master-studio-chapter-11-ask-me-anything-about-scrum-mastery
date_scraped: 2025-06-29T05:19:59.185165
---

[ Skip to main content ](https://www.scrum.org/events/28990/scrum-master-studio-chapter-11-ask-me-anything-about-scrum-mastery#main-content)
#  Scrum Master Studio - Chapter 11 "Ask me Anything about Scrum Mastery"
India
The "Scrum Master Studio" is intended to instill skills within Scrum Masters/Aspiring Leaders (in fact anyone) to create them as future leaders. Leadership require learning, convincing, nurturing and bringing in Change. That doesn't happen overnight, but its a journey. This edition will focus on Scrum Mastery and provide a forum to ask questions and get answers from Professional Scrum Trainer Venkatesh Rajamani. 
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
