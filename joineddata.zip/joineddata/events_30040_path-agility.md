---
source_url: https://www.scrum.org/events/30040/path-agility
date_scraped: 2025-06-29T05:21:19.431922
---

[ Skip to main content ](https://www.scrum.org/events/30040/path-agility#main-content)
#  The Path to Agility
The Path to Agility conference was developed to further COHAA’s mission to inspire creativity and innovation in the delivery of value. COHAA has engaged national and regional Agile thought leaders to provide session content focused on a mix of business, technical, and/or management topics. Whether you are well along the path or just starting out, this conference will help guide you in the right direction. Dave West will be a keynote speaker at this event.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
