---
source_url: https://www.scrum.org/events/75299/unfix-conference
date_scraped: 2025-06-29T05:52:53.631853
---

[ Skip to main content ](https://www.scrum.org/events/75299/unfix-conference#main-content)
#  unFix Conference 
Germany
The unFIXcon is the world’s only conference on the design of versatile organizations using the unFIX model by Jurgen Appelo. We invite entrepreneurs, leaders, and change-makers to two days of impulses, exchanges, and solution-finding together. PST [Jochen Krebs](https://www.scrum.org/joe-krebs) will be speaking at the event.
[ Visit Event Website ](https://unfixcon.events)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
