---
source_url: https://www.scrum.org/events/16062/professional-scrum-day
date_scraped: 2025-06-29T05:08:14.267880
---

[ Skip to main content ](https://www.scrum.org/events/16062/professional-scrum-day#main-content)
#  Professional Scrum Day
Peru
Lo invitamos al evento Professional Scrum Day donde trataremos temas relacionados al despliegue y la entrega continua de software usando herramientas de DevOps, Innovación digital en bancos, Testing Ágil, Escalamiento de Scrum y enfoques modernos asociados a la innovación digital en Fintechs.
Este evento le permitirá aprender la mejor manera de apoyar su adopción ágil y Scrum aplicando estas prácticas ágiles de ingeniería y DevOps usando a la vez herramientas que las soportan.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
