---
source_url: https://www.scrum.org/events/36691/immersion-workshop-liberating-structures
date_scraped: 2025-06-29T05:33:53.457878
---

[ Skip to main content ](https://www.scrum.org/events/36691/immersion-workshop-liberating-structures#main-content)
#  Immersion workshop: Liberating Structures
Switzerland
Spread over two days of practice, our immersion workshops are intense, fun and inspiring experiences.
They are designed to allow you to learn by doing. Each workshop is designed and led by a team of 2 to 4 people. Immerse yourself and discover how to make your groups work at the top of their intelligence.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
