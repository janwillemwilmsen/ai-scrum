---
source_url: https://www.scrum.org/events/31295/software-architecture-conference
date_scraped: 2025-06-29T05:24:18.022994
---

[ Skip to main content ](https://www.scrum.org/events/31295/software-architecture-conference#main-content)
#  Software Architecture Conference
Indonesia
Fast-paced and practical, the Software Architecture Conference will aspire software architects, engineers, and senior developers. Professional Scrum Trainer Joshua Partogi will be speaking at this conference.
**Topics Coverage**
Requirement Engineering, Agile Design, Scalable Systems, Microservices, Evolutionary Architecture, Distributed Systems, Continuous Delivery, Service-Based Architecture, Design Principles, Soft Skills, Web Application Security, Enterprise Messaging, Data Architecture, Architecture Patterns, Cloud Architectures, Measuring and Profiling, Artificial Intelligence, Machine Learning, Blockchain, Internet of Things, DevOps
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
