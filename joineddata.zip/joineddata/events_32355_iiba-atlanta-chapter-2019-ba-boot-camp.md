---
source_url: https://www.scrum.org/events/32355/iiba-atlanta-chapter-2019-ba-boot-camp
date_scraped: 2025-06-29T05:27:06.074331
---

[ Skip to main content ](https://www.scrum.org/events/32355/iiba-atlanta-chapter-2019-ba-boot-camp#main-content)
#  IIBA Atlanta Chapter - 2019 BA Boot Camp
**Grow today and Prosper tomorrow: Becoming the BA of the Future**
Program highlights include:
  * Keynote address
  * A full day of professional development!
  * Nine presentations across three tracks
  * Opportunities to interact with local business analysis experts
  * Earn up to 4.75 CDU by attending track sessions
  * Job Fair
  * Create networking and personal relationships with other business analysis professionals from the Atlanta area and surrounding regions


By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
