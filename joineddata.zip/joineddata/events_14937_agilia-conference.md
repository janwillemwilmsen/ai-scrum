---
source_url: https://www.scrum.org/events/14937/agilia-conference
date_scraped: 2025-06-29T05:05:30.526700
---

[ Skip to main content ](https://www.scrum.org/events/14937/agilia-conference#main-content)
#  Agilia Conference
Czechia
Agilia Conference is **Central European conference about agile methods in business**. Narrow focus on selected topics and private exclusive content makes this event unique. Every year we present, **what it is agile, why it is important for knowledge based business,** what benefits it brings to organizations and how to implement required changes. Topic covers Agile for Management, HR, Finance, Procurement, Legal, Sales, Marketing, Project Management, and also for IT and software development.
Gladly, and based on feedback from speakers and delegates, **Agilia Conference** **ranks among top 5 conferences in Europe** on **Agile** – **5 days of program** , more than **40 presentations** and **8 workshops!** Important component of the conference is networking: it enables visitors having expert discussions or gaining new business partners.
We wants to invite everyone to the table – aiming at more than **400 delegates** from all European countries and overseas, including: software development managers, heads of software engineering, heads of quality assurance, developers, test engineers, software architects, ScrumMasters, Product Owners, product designers, program managers, IT directors, R&D directors, coaches and trainers, idea makers, project managers, heads of PMOs, team managers, team leaders, line managers, decision makers and stakeholders, CTOs, CIOs, customer care managers, consultants, CEOs, CFOs, HR managers, start-up-ers, investors and technology lawyers.
In **2018** conference topic is „**Improving Business Performance with Agile** “.
[ Visit Event Website ](http://agiliaconference.com/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
