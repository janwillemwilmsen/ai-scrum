---
source_url: https://www.scrum.org/events/80239/scrum-day-madison
date_scraped: 2025-06-29T05:54:40.840706
---

[ Skip to main content ](https://www.scrum.org/events/80239/scrum-day-madison#main-content)
#  Scrum Day Madison
United States
Join us at Scrum Day 2024 in Madison, Wisconsin, to network with like-minded individuals and learn more about maximizing value for your Scrum Teams. 
[ Visit Event Website ](https://www.scrumday.org)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
