---
source_url: https://www.scrum.org/events/32121/agile-cambridge
date_scraped: 2025-06-29T05:26:23.132611
---

[ Skip to main content ](https://www.scrum.org/events/32121/agile-cambridge#main-content)
#  Agile Cambridge
United Kingdom
Agile Cambridge is a practical agile development conference that allows participants to connect and learn from their peers and leaders in the industry. The conference has a strong practical focus and attracts industry practitioners and decision-makers who want to improve their success with agile and lean methods.The event will provide three days of inspiring agile and lean learning from a dynamic mix of stimulating keynotes and practitioners working on the front line of the industry. Professional Scrum Trainer Julia Wester will be speaking at the event.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
