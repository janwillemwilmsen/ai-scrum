---
source_url: https://www.scrum.org/events/25524/xp-days-benelux
date_scraped: 2025-06-29T05:12:38.045138
---

[ Skip to main content ](https://www.scrum.org/events/25524/xp-days-benelux#main-content)
#  XP Days Benelux
Netherlands
XP Days Benelux is an international conference where we learn to bring software to life and grow mature systems that support business needs.
It provides an excellent environment for exchanging ideas, hands-on exercises and extreme experiences.
The conference is organized by the Dutch and Belgian agile community and the location alternates between Belgium and The Netherlands. Administration and invoicing is handled by a non-profit organization. Professional Scrum Trainers [Ron Eringa](https://www.scrum.org/ron-eringa), [Evelien Acun-Roos](https://www.scrum.org/evelien-roos), [Barry Overeem](https://www.scrum.org/user/60), [Christiaan Verwijs](https://www.scrum.org/christiaan-verwijs), [Laurens Bonnema](https://www.scrum.org/user/217755), [Dajo Breddels](https://www.scrum.org/user/130) and [Wim Heemskerk](https://www.scrum.org/user/115) will be speaking at this event.
[ visit event website ](http://www.xpdaysbenelux.nl/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
