---
source_url: https://www.scrum.org/events/48177/women-agile-global-conference
date_scraped: 2025-06-29T05:40:57.283819
---

[ Skip to main content ](https://www.scrum.org/events/48177/women-agile-global-conference#main-content)
#  Women in Agile Global Conference
This unique conference will bring together voices from across the Women in Agile global community. Together we will explore and celebrate our combined understanding of “What Agile Means”. Patricia Kong, PST Jill Graves and Leslie Morse will all be speaking at this event! The conference will take place May 8-9 for Asia/Pacific and May 11-12 for US/Europe.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
