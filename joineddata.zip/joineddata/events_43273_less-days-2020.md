---
source_url: https://www.scrum.org/events/43273/less-days-2020
date_scraped: 2025-06-29T05:37:35.919633
---

[ Skip to main content ](https://www.scrum.org/events/43273/less-days-2020#main-content)
#  LeSS Days 2020
LeSS Days brings together professionals around the world. All reports and workshops are real experience of implementing and using LeSS. Professional Scrum Trainers Cesario Ramos, Illya Pavlichenko, Roman Doroshenko and Sergey Lobin will be speaking at the event. 
[ visit event website ](https://lessdays.org/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
