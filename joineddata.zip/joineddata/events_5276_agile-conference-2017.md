---
source_url: https://www.scrum.org/events/5276/agile-conference-2017
date_scraped: 2025-06-29T04:57:32.602410
---

[ Skip to main content ](https://www.scrum.org/events/5276/agile-conference-2017#main-content)
#  Agile Conference 2017
Czechia
Join Scrum.org as we sponsor Agilia 2017 where you can meet and hear some of our Professional Scrum Trainers and other team members speak, including [Kurt Bittner](https://www.scrum.org/team/kurt-bittner "Kurt Bittner"), [Dominik Maximini](https://www.scrum.org/user/67), [Cesario Ramos](https://www.scrum.org/user/62) and [Gunther Verheyen](https://www.scrum.org/user/149).
Agilia Conference is Central European conference about agile methods. Narrow focus on selected topics and private exclusive content makes this event unique. Every year we present, what it is agile, why it is important for knowledge based business, what benefits it brings to organizations and how to implement required changes.
[ Visit Event Website ](http://agiliaconference.com)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
