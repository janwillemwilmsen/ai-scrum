---
source_url: https://www.scrum.org/events/17786/brewing-agile-2018
date_scraped: 2025-06-29T05:11:14.374833
---

[ Skip to main content ](https://www.scrum.org/events/17786/brewing-agile-2018#main-content)
#  Brewing Agile 2018
Sweden
This will of course most easily relate to the digital industry, but we hope to broaden the focus to other areas. We want our speakers and attendees to share tools across our fields, both for improving your own flow but also for understanding other area of expertise in the product process.
We want to invite not only developers but, project managers, marketing professionals, sales people, and many others. Anyone with passion about their products!
[ visit event website ](https://brewingagile.org/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
