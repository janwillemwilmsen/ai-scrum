---
source_url: https://www.scrum.org/events/29089/agile-east
date_scraped: 2025-06-29T05:20:14.716424
---

[ Skip to main content ](https://www.scrum.org/events/29089/agile-east#main-content)
#  Agile of East 
India
Agile Of East (AOE 2019) is a flagship conference on Agility in the Eastern part of India. It is focused to bring the best of minds, diversified ideas, delegates across industries – all under one roof, aimed to boost and stimulate the spread of Agile WoW in the Eastern part of India (and larger South East Asia). Professional Scrum Trainer [Punit Doshi](https://www.scrum.org/punit-doshi) will be speaking on Technology Agnostic Agility on November 11 at 11:15 AM.
[ visit event website ](http://zoneconnect.in/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
