---
source_url: https://www.scrum.org/events/42177/bosnia-agile-week
date_scraped: 2025-06-29T05:36:00.774935
---

[ Skip to main content ](https://www.scrum.org/events/42177/bosnia-agile-week#main-content)
#  Bosnia Agile Week
Bosnia Agile Week will be held October 19-23. Dave West will be presenting, Scrum Turns 25 - Usage and the Future. 
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
