---
source_url: https://www.scrum.org/events/51562/agile-online-summit
date_scraped: 2025-06-29T05:43:37.210988
---

[ Skip to main content ](https://www.scrum.org/events/51562/agile-online-summit#main-content)
#  Agile Online Summit
The Agile Online Summit brings together leading authors, coaches, and status quo challengers. This is a global conference October 25-27th will be bringing people from different countries and continents. Don’t miss out! Patricia Kong will be presenting a keynote at this event.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
