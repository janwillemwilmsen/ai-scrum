---
source_url: https://www.scrum.org/events/56530/agile-americas
date_scraped: 2025-06-29T05:45:37.847156
---

[ Skip to main content ](https://www.scrum.org/events/56530/agile-americas#main-content)
#  Agile Americas
Agile Americas is backed by 12+ years of inspect and adapt experience of Agile NCR and hosting live virtual conference and engaging and connecting practitioners of Agile. Dave West will be delivering a keynote at the event. 
[ Visit event website ](https://www.agileamericas.org/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
