---
source_url: https://www.scrum.org/events/68603/lean-agile-london
date_scraped: 2025-06-29T05:51:04.377454
---

[ Skip to main content ](https://www.scrum.org/events/68603/lean-agile-london#main-content)
#  Lean Agile London
Learn Agile London will take place 22 - 23 May 2023, London, UK. 
Lean Agile London (#LALDN23) is an affordable not-for-profit conference which focuses on supporting our community in a friendly, safe, diverse and inclusive environment.
The conference has a Code of Conduct. Please read it before making a booking.
As a community-focused event, our purpose is to create a conference with soul where people can fully engage and share experiences with others.
As an attendee of LALDN23 you will hear from inspiring voices in the industry, build relationships and gather some of the latest thinking & knowledge. We design the conference to allow spontaneous interactions, engagement and connections, giving you the chance to speak with Professional Scrum Trainersare speaking at the event! 
[ Visit Event Website ](https://leanagile.london/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
