---
source_url: https://www.scrum.org/events/32120/agile-greece-summit
date_scraped: 2025-06-29T05:26:17.678670
---

[ Skip to main content ](https://www.scrum.org/events/32120/agile-greece-summit#main-content)
#  Agile Greece Summit
Greece
Addressing developers, team leaders, managers and executives, AGRS brings together top class agile speakers and and agile practitioners from around the world. Following four very successful conferences and having hosted some of the most significant and influential people of the Agile movement, we’re up for the fifth AGRS.Focusing on improvement, we aim this year to bring you a different conference setup with an enriched experience. Professional Scrum Trainers [Glaudia Califano](https://www.scrum.org/glaudia-califano) and [David Spinks](https://www.scrum.org/david-spinks) will be speaking at the event.
[ visit event website ](https://agilesummit.gr/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
