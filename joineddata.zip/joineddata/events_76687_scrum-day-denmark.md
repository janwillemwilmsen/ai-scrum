---
source_url: https://www.scrum.org/events/76687/scrum-day-denmark
date_scraped: 2025-06-29T05:54:11.935029
---

[ Skip to main content ](https://www.scrum.org/events/76687/scrum-day-denmark#main-content)
#  Scrum Day Denmark
Scrum Day Denmark is an event for Scrum practitioners to meet, learn and and exchange ideas about Professional Scrum. 
Professional Scrum Trainers Steve Porter and Gunther Verheyen will be speaking at the event.
[ Visit Event Website ](https://scrumday.dk/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
