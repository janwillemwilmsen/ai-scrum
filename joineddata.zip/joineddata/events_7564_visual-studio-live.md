---
source_url: https://www.scrum.org/events/7564/visual-studio-live
date_scraped: 2025-06-29T04:58:22.018716
---

[ Skip to main content ](https://www.scrum.org/events/7564/visual-studio-live#main-content)
#  Visual Studio Live!
United States
As the development world's trusted educational provider of developer-focused content since 1993, Visual Studio Live! (VSLive!TM) provides attendees with cutting-edge techniques needed to solve development challenges with shipping or soon to be shipping technologies compatible with the .NET Framework and Visual Studio. No other conference, no corporate trainers, no one else compares to the Visual Studio Live! standard of editorial excellence and commitment by speakers, such as Microsoft Development Team members and renowned industry experts, to provide real-world, practical information.
Visual Studio Live! is for those involved or interested in using the .NET and Microsoft application development platform including Software Architects, Systems Analysts, Developers, designers, and anyone in the development industry looking to build their expertise.
PST and Microsoft MVP [Richard Hundhausen](https://vslive.com/events/las-vegas-2017/Speakers/Speaker%20Window.aspx?SpeakerId={4505163D-11B6-4F8C-A202-C3A00623F86F}&ID={3107BEF0-1552-4ADA-9955-15B225788EF9}) will deliver workshops on [Professional Scrum Development using Visual Studio 2017](https://vslive.com/Events/Las-Vegas-2017/Sessions/Wednesday/W14-Professional-Scrum-Development-using-Visual-Studio-2017.aspx), and [Using Visual Studio to Scale Agile in Your Enterprise](https://vslive.com/Events/Las-Vegas-2017/Sessions/Wednesday/W09-Use-Visual-Studio-to-Scale-Agile-in-Your-Enterprise.aspx).
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
