---
source_url: https://www.scrum.org/events/17634/agile-day-2018-new-york
date_scraped: 2025-06-29T05:10:52.635271
---

[ Skip to main content ](https://www.scrum.org/events/17634/agile-day-2018-new-york#main-content)
#  Agile Day 2018 New York
We are getting ready for the 9th Annual Agile Day 2018 in New York City. The conference will be held Wednesday September 5th at Pace University. Scrum.org is sponsoring the event!
[ visit event website ](https://www.agileday2018.org/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
