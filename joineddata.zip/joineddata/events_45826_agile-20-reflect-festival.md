---
source_url: https://www.scrum.org/events/45826/agile-20-reflect-festival
date_scraped: 2025-06-29T05:39:12.662644
---

[ Skip to main content ](https://www.scrum.org/events/45826/agile-20-reflect-festival#main-content)
#  Agile 20 Reflect Festival
Agile 20 Reflect is a community based festival of events in February reflecting on 20 years of the Agile Manifesto.
[ visit event website ](https://agile20reflect.org/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
