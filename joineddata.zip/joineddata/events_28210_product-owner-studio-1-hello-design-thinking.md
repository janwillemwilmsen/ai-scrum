---
source_url: https://www.scrum.org/events/28210/product-owner-studio-1-hello-design-thinking
date_scraped: 2025-06-29T05:18:03.043316
---

[ Skip to main content ](https://www.scrum.org/events/28210/product-owner-studio-1-hello-design-thinking#main-content)
#  Product Owner Studio 1: Hello Design Thinking
India
Product Owner Studio is aimed at instilling Product Thinking skills in Product Owners and Aspiring Product Owners. You will walk away with a knowledge on "What is Design Thinking" ?
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
