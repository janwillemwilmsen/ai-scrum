---
source_url: https://www.scrum.org/events/48365/improving-edge-conference
date_scraped: 2025-06-29T05:41:08.529111
---

[ Skip to main content ](https://www.scrum.org/events/48365/improving-edge-conference#main-content)
#  The Improving Edge Conference
Improving Edge was designed from the ground up to bring as much value to the community as possible. By leveraging our long standing relationships and community connections, we have pulled together a schedule of speakers that should bring value to individuals, executives, and team leaders alike. If you are looking for inspiration, new tips and techniques, or fellowship in the community then the Improving Edge is for you. Patricia Kong, Ty Crockett and Simon Reindl will be speaking at the event.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
