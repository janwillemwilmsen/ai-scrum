---
source_url: https://www.scrum.org/events/63236/pizzagility-levelling-your-leadership-skills-liberating-structures
date_scraped: 2025-06-29T05:49:45.710363
---

[ Skip to main content ](https://www.scrum.org/events/63236/pizzagility-levelling-your-leadership-skills-liberating-structures#main-content)
#  PizzAgility: Levelling Up Your Leadership Skills with Liberating Structures 
United States
PizzAgility events are free, informal and provide a great platform to connect, have a nice bite to eat, and participate in an engaging workshop. PizzAgility is highly participative with a string of different Liberating Structures to help attendees discover their own action items and unlock the knowledge and experience of others. This event will feature PST [Sander Dur](https://www.scrum.org/sander-dur).
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
