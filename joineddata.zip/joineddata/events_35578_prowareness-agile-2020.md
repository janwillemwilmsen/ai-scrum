---
source_url: https://www.scrum.org/events/35578/prowareness-agile-2020
date_scraped: 2025-06-29T05:32:36.963563
---

[ Skip to main content ](https://www.scrum.org/events/35578/prowareness-agile-2020#main-content)
#  Prowareness - Agile 2020
Netherlands
After the success of Agile 2019, in which more than 800 Agile professionals were enthralled, this Agile event is also all about acquiring knowledge and developing talent for all Scrum Masters, Product Owners & Team Members. During the second edition, spectacular keynotes and inspiring tracks will once again come along that contribute to the personal development of the various roles. Agile event 2020 therefore focuses on both starting and advanced Scrum Masters, Product Owners and Agile Coaches.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
