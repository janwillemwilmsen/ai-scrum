---
source_url: https://www.scrum.org/events/8104/scrum-day-2017
date_scraped: 2025-06-29T04:59:58.064169
---

[ Skip to main content ](https://www.scrum.org/events/8104/scrum-day-2017#main-content)
#  Scrum Day 2017
Germany
10 years of innovation and inspiration, as this conference enters double digits. Scrum Day has developed into the largest community conference over the years. 
Some highlights of the conference include:
  * [Dave West](http://www.scrum-day.de/home/keynote-speaker.html#west) keynotes
  * [Peter Götz](http://www.scrum-day.de/referenten/peter-goetz.html#details) delivers a [talk on PMI Agile Certification](http://www.scrum-day.de/vortraege/details/vortrag-2017-pmi-acp-wie-sinnvoll-ist-die-agile-zertifizierung-des-project-management-institute.html#details)
  * [Glenn Lamming](http://www.scrum-day.de/referenten/glenn-lamming.html#details) gives a lecture on [Coaching the Coach](http://www.scrum-day.de/vortraege/details/vortrag-2017-coach-den-coach-welches-coaching-braucht-der-coach.html#details)
  * [Fahd Al-Fatish](http://www.scrum-day.de/referenten/fahd-al-fatish.html#details) talks about [Agile Transformation with Bottom-Up Intelligence](http://www.scrum-day.de/vortraege/details/vortrag-2017-agile-transformation-mit-bottom-up-intelligence.html#details)
  * [Thomas Schissler](http://www.scrum-day.de/referenten/thomas-schissler.html#details) helps people better understand the [Definition of "Done"](http://www.scrum-day.de/vortraege/details/vortrag-2017-done-oder-nicht-done-das-ist-hier-die-frage.html#details "Done or Not Done: This is the Question!")


By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
