---
source_url: https://www.scrum.org/events/60132/scrum-day-europe
date_scraped: 2025-06-29T05:47:21.754331
---

[ Skip to main content ](https://www.scrum.org/events/60132/scrum-day-europe#main-content)
#  Scrum Day Europe
Netherlands
Scrum Day Europe celebrates its 10th anniversary and we’re celebrating! In collaboration with Scrum.org, Prowareness will be hosting the largest Scrum Day Europe yet on December 1st in the Amsterdam Arena. We’re inviting thought leaders and experts back on stage to share their insights with you from the past 10 years and together you’ll look forward to what’s ahead. We’re also inviting you, as one of our returnees or a new visitor to come together during one of the largest community events for Scrum in Europe! Share and learn with fellow Scrum enthusiasts during a day full of energy. Leslie Morse, Dave West and PST Gunther Verheyen will be speaking at this event.
[ Visit Event Website ](https://scrumdayeurope.com/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
