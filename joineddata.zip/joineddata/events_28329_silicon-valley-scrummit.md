---
source_url: https://www.scrum.org/events/28329/silicon-valley-scrummit
date_scraped: 2025-06-29T05:18:35.660673
---

[ Skip to main content ](https://www.scrum.org/events/28329/silicon-valley-scrummit#main-content)
#  Silicon Valley (Scrum)mit
The goal of the conference is to bring together people who have a variety of different interests vis-a-vis the Scrum Framework. We want to let people share learning and experience from their work on Scrum in a variety of settings. We hope to learn more about the Scrum Framework by comparing how it is used in different contexts. So far the speaker list indicates we’re succeeding. We’ll have people who are using Scrum for Human Resources, Mergers and Acquisitions, Education and Not-for-profit work. It should be very interesting. Kurt Bittner will be keynoting this event.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
