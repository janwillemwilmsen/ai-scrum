---
source_url: https://www.scrum.org/events/7994/keep-austin-agile
date_scraped: 2025-06-29T04:59:41.326461
---

[ Skip to main content ](https://www.scrum.org/events/7994/keep-austin-agile#main-content)
#  Keep Austin Agile
United States
The conference is a one-day event bringing together 750 attendees from over 200 companies and all walks of Agile expertise for a day full of education, networking, and fun!
Keep Austin Agile is one of the top regional Agile conferences in the nation. Our fifth conference continues Agile Austin’s mission to elevate the state of Agile practices and educate Agile practitioners of all levels. The conference’s multiple subject tracks and interactive workshops will appeal to everyone, from novices to gurus, and technical professionals to company executives.
[Stephanie Ockerman](https://keepaustinagile2017.sched.com/speaker/sockerman22) will deliver an excellent afternoon session on the [Secret to Scrum Success: Scrum Values](https://keepaustinagile2017.sched.com/event/9i1f/the-secret-to-scrum-success-scrum-values?iframe=yes&w=100%&sidebar=yes&bg=no). The Scrum values are the lifeblood of the Scrum framework. Without them, we are just going through the motions.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
