---
source_url: https://www.scrum.org/events/31920/agile-bodensee
date_scraped: 2025-06-29T05:25:45.555011
---

[ Skip to main content ](https://www.scrum.org/events/31920/agile-bodensee#main-content)
#  Agile Bodensee
Germany
Agile Bodensee is the largest conference for agile software developers and project managers in the Lake Constance region of Germany. IT companies and service providers involved in agile software development, and other experts come together to discuss agile development processes and practices. Professional Scrum Trainer Peter Gfader will be speaking at the event. 
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
