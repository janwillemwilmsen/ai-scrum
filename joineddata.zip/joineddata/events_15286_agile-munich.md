---
source_url: https://www.scrum.org/events/15286/agile-munich
date_scraped: 2025-06-29T05:06:14.657758
---

[ Skip to main content ](https://www.scrum.org/events/15286/agile-munich#main-content)
#  Agile Munich
Germany
Scrum is implemented. Scaling is a hot topic in your company. But these are just a few pieces of your Agile Transformation puzzle. Let’s explore together what you can do as a Leader. Learn from the visionairs and peer companies.
[ Visit Event Website ](http://www.agilemunich.com/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
