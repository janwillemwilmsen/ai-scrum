---
source_url: https://www.scrum.org/events/12912/agile-midwest
date_scraped: 2025-06-29T05:04:05.140451
---

[ Skip to main content ](https://www.scrum.org/events/12912/agile-midwest#main-content)
#  Agile Midwest
United States
Come join us for Agile Week in St. Louis! During Agile Week in St. Louis you can custom tailor your learning experience.
Agile Week in St. Louis brings together agilists in the Midwest region for informal networking, educational experience and sharing of innovative ideas through personal stories. Attendees will hear from industry leaders, participate in workshops and join in Agile games.
Featured sessions include:
  * [PSF Class](https://www.agilemidwest.org/agile-u/#professional-scrum-foundations) with [John Davis](https://www.scrum.org/john-davis)
  * Automating Your Test Suite: Incrementally Eating the Elephant with [Gary Pedretti](https://www.scrum.org/user/147)


By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
