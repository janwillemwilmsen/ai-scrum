---
source_url: https://www.scrum.org/events/7894/big-apple-scrum-day
date_scraped: 2025-06-29T04:58:37.541753
---

[ Skip to main content ](https://www.scrum.org/events/7894/big-apple-scrum-day#main-content)
#  Big Apple Scrum Day
United States
Big Apple Scrum Day (BASD2017) is a one-day community conference focused on Scrum/Agile principles and practices. This conference is about sharing knowledge, supporting local community, discovering new practices, and learning from peers. 
BASD2017 invites you to reflect on the importance of growing. ​ Growing your knowledge: through experimenting and failing, taking risks, and pushing your boundaries. Growing your team: through self-organizing, revisiting Scrum values, and getting to the “We are great” stage. Growing your Scrum: through applying a better use of Scrum practices and widening the use of them in your organization. Growing beyond your Scrum: opening your eyes to other frameworks and considering practices more suitable to the problem at hand. Keep growing and inspiring others to grow with you! All around you, plant the seeds of change for an Agile Mindset.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
