---
source_url: https://www.scrum.org/events/44033/new-scrum-guide-upgrade-kit
date_scraped: 2025-06-29T05:38:15.956223
---

[ Skip to main content ](https://www.scrum.org/events/44033/new-scrum-guide-upgrade-kit#main-content)
#  New Scrum Guide + Upgrade Kit
_Due to the large demand and to accommodate attendees from Europe better, we have scheduled 2 webinars that cover the same topics._
_NOV 18th, 2020 - 3pm ET - Length 20 Minutes. Please Register below._
_NOV 19th, 2020 - 8.30am ET - Length 20 Minutes. Please Register below._
**Join Incrementor for a very special occasion, as we would like to share the updates and changes to the new Scrum Guide 2020 with you. At that time, we will also give you access to our newly made “upgrade kit” to make your transition to Scrum 2020 easier.**
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
