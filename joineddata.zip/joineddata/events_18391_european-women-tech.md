---
source_url: https://www.scrum.org/events/18391/european-women-tech
date_scraped: 2025-06-29T05:12:09.436349
---

[ Skip to main content ](https://www.scrum.org/events/18391/european-women-tech#main-content)
#  European Women in Tech
Netherlands
European Women in Technology enables the sector to connect, learn and act on gender diversity by sharing the experiences of industry leaders and developing women’s skills, both soft and technical. We open people’s minds to new ideas and push the boundaries.
Through inspirational keynote speakers, personal development workshops, technical classes and networking opportunities, this conference provides all the content you need to progress and flourish in the tech sector. 
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
