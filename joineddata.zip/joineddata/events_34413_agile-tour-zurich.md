---
source_url: https://www.scrum.org/events/34413/agile-tour-zurich
date_scraped: 2025-06-29T05:30:10.099235
---

[ Skip to main content ](https://www.scrum.org/events/34413/agile-tour-zurich#main-content)
#  Agile Tour Zurich
Switzerland
Agile Tour is a day full of a variety of exciting talks related to Agility. This is a unique opportunity to learn more about the topic and share with the community members. Professional Scrum Trainer [Nedjma Saidani](https://www.scrum.org/nedjma-saidani) will be speaking at the event. 
[ visit event website ](https://agiletourzurich.com/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
