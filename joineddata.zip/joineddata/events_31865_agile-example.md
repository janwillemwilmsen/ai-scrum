---
source_url: https://www.scrum.org/events/31865/agile-example
date_scraped: 2025-06-29T05:25:40.671389
---

[ Skip to main content ](https://www.scrum.org/events/31865/agile-example#main-content)
#  Agile by Example
Poland
At Agile by Example, listen to selected keynote lectures, choose from 8 topic sessions, join the discussion on our panel and profit from one-on-one meetings with our experts and coaches.
[ visit event website ](https://agilebyexample.com/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
