---
source_url: https://www.scrum.org/events/16768/scrum-event-2018
date_scraped: 2025-06-29T05:09:21.311178
---

[ Skip to main content ](https://www.scrum.org/events/16768/scrum-event-2018#main-content)
#  Scrum Event 2018
Netherlands
The Scrum Event offers a full day program with useful workshops, interactive Scrum sessions and inspiring lectures by skilled Agile Coaches and visionaries in the field of Agile, Scrum and change management.
[ visit event website ](http://scrumevent.nl/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
