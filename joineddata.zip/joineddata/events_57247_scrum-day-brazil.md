---
source_url: https://www.scrum.org/events/57247/scrum-day-brazil
date_scraped: 2025-06-29T05:45:53.531222
---

[ Skip to main content ](https://www.scrum.org/events/57247/scrum-day-brazil#main-content)
#  Scrum Day Brazil
O mundo mudou numa velocidade muito mais rápida do que imaginamos. Definitivamente, as pessoas precisaram se adaptar! As interações entre as pessoas evoluíram, os processos foram alterados e as ferramentas se multiplicaram. 
Mas, entretanto, será que aprendemos a responder melhor às mudanças constantes? Já começamos a falar de futuro, de um "novo normal", mas será que realmente estamos preparadas para o que vem por aí?
[ visit event website ](https://www.scrumday.com.br/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
