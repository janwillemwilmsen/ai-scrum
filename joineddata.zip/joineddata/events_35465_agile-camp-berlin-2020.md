---
source_url: https://www.scrum.org/events/35465/agile-camp-berlin-2020
date_scraped: 2025-06-29T05:32:22.235618
---

[ Skip to main content ](https://www.scrum.org/events/35465/agile-camp-berlin-2020#main-content)
#  Agile Camp Berlin 2020
Germany
Join the Agile Camp Berlin and experience two energizing days with 200 agile peers focusing on community, sharing, and learning. We will practice games and exercises—from Liberating Structures to paper snowflakes and airplanes to building castles with 50 other folks you have never met in your life
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
