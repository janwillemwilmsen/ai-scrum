---
source_url: https://www.scrum.org/events/52062/agile-leadership-day
date_scraped: 2025-06-29T05:43:43.400358
---

[ Skip to main content ](https://www.scrum.org/events/52062/agile-leadership-day#main-content)
#  Agile Leadership Day
This conference covers the following topics:
  * Agile Leadership, Mindset & Culture
  * Team Agility (Scrum, Kanban & Co.)
  * Strategic Agility
  * Agile Organisation


Professional Scrum Trainer Ari Byland will be speaking at the event. More details [here](https://agileleadershipday.ch/speaker/ari-byland/). 
[ visit event website ](https://agileleadershipday.ch/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
