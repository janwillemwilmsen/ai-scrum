---
source_url: https://www.scrum.org/events/49798/global-online-pm-day
date_scraped: 2025-06-29T05:43:05.009292
---

[ Skip to main content ](https://www.scrum.org/events/49798/global-online-pm-day#main-content)
#  Global Online PM Day
This conference aims to provide an understanding of current trends in Project and Product management and answer questions that are currently relevant for those involved in project and product management. The event consists of three tracks (PM-Models, Agile, Product Management) which will be running simultaneously, 30 speakers and about 500 participants. Dave West and PST David Sabine will both be presenting at this event.
[ visit event website ](https://opmday.org/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
