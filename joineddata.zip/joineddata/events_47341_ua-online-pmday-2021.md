---
source_url: https://www.scrum.org/events/47341/ua-online-pmday-2021
date_scraped: 2025-06-29T05:40:12.540030
---

[ Skip to main content ](https://www.scrum.org/events/47341/ua-online-pmday-2021#main-content)
#  UA Online PMDay 2021
UA PM Day is coming up April 24! Leslie Morse from Scrum.org will be speaking. Professional Scrum Trainers David Sabine and Bogdan Onyshchenko will be speaking as well!
[ visit event website ](https://pmday.org/online)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
