---
source_url: https://www.scrum.org/events/30821/southern-fried-agile
date_scraped: 2025-06-29T05:23:28.350645
---

[ Skip to main content ](https://www.scrum.org/events/30821/southern-fried-agile#main-content)
#  Southern Fried Agile
Join the SFA family on October 18th for our 10th annual Southern Fried Agile Conference. We look forward to seeing our committed SFA'ers and new comers at the Charlotte Convention Center! Dave West will be the closing keynote.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
