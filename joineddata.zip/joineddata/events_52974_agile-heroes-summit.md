---
source_url: https://www.scrum.org/events/52974/agile-heroes-summit
date_scraped: 2025-06-29T05:44:15.866082
---

[ Skip to main content ](https://www.scrum.org/events/52974/agile-heroes-summit#main-content)
#  Agile Heroes Summit
Check out this lineup of great Agilists including Professional Scrum Trainers Daria Bagina and Mary Iqbal at #TheAgileHeroesSummit on October 26th from 12-6pm!
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
