---
source_url: https://www.scrum.org/events/17235/40th-athens-agilescrum-meetup
date_scraped: 2025-06-29T05:09:48.390374
---

[ Skip to main content ](https://www.scrum.org/events/17235/40th-athens-agilescrum-meetup#main-content)
#  40th Athens Agile/Scrum Meetup
Greece
Professional Scrum Trainer [Rich Hundhausen](https://www.scrum.org/richard-hundhausen) is doing a presentation at this meetup on the Nexus framework for scaling Scrum. 
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
