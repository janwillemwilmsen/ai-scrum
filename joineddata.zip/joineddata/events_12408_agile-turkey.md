---
source_url: https://www.scrum.org/events/12408/agile-turkey
date_scraped: 2025-06-29T05:02:53.430033
---

[ Skip to main content ](https://www.scrum.org/events/12408/agile-turkey#main-content)
#  Agile Turkey
Türkiye
Agile Turkey Summit 2017 is a single day, 3 tracks international event gathering Agile enthusiasts together. We would like to invite you to take part in the 5th Agile Turkey Summit at Wyndham Grand Levent, Istanbul, Turkey on 19th October 2017 to discuss the hot topics in Agile world. This year’s motto is “Agile Everywhere” and we have 3 main themes: Business Agility, Technical Agility, Organisational Agility.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
