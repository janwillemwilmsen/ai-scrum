---
source_url: https://www.scrum.org/events/32485/meetup-liberating-structures-scrum
date_scraped: 2025-06-29T05:27:22.477300
---

[ Skip to main content ](https://www.scrum.org/events/32485/meetup-liberating-structures-scrum#main-content)
#  Meetup- Liberating Structures with Scrum
Vietnam
This meetup will feature Professional Scrum Trainer Khoa Doan Tien and will cover uses of Liberating Structures with Scrum.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
