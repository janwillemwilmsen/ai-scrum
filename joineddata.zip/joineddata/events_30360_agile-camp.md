---
source_url: https://www.scrum.org/events/30360/agile-camp
date_scraped: 2025-06-29T05:22:38.954511
---

[ Skip to main content ](https://www.scrum.org/events/30360/agile-camp#main-content)
#  Agile Camp
Agile Camp is a full day conference where you can collaborate with other Agile Practitioners, Scrum Masters, Product Owners, and others that share a passion for agility.
The day will be filled with talks, presentations, panel discussions, and collaborative breakout sessions with plenty of time to network, including an optional social gathering following the event. Professional Scrum Trainer [Chad Beier](https://www.scrum.org/chad-beier) will be speaking at the event, and in the video below, he talks a little more about that. 
[ visit event website ](http://centa.re/agilecamp)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
