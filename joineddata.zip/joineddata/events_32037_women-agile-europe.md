---
source_url: https://www.scrum.org/events/32037/women-agile-europe
date_scraped: 2025-06-29T05:26:01.038148
---

[ Skip to main content ](https://www.scrum.org/events/32037/women-agile-europe#main-content)
#  Women in Agile Europe
Netherlands
This event is a whole day of learning and networking with women in agile. Professional Scrum Trainers Evelien Roos and Glaudia Califano will be speaking at this event.
[ visit event website ](https://womeninagile.eu/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
