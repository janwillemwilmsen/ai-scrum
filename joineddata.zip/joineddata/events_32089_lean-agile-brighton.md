---
source_url: https://www.scrum.org/events/32089/lean-agile-brighton
date_scraped: 2025-06-29T05:26:12.015371
---

[ Skip to main content ](https://www.scrum.org/events/32089/lean-agile-brighton#main-content)
#  Lean Agile Brighton
Brought to you by the organisers of the Brighton Lean Agile MeetUp Group (BLAG), the Lean Agile Brighton conference aims to bring together agile thought leaders, practitioners and enthusiasts from across the UK and beyond for a top tier, 1st className Agile conference in Brighton. Jean-Paul Bayley, Jose Casal and Daniel Vacanti will be speaking at the event!
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
