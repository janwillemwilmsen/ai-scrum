---
source_url: https://www.scrum.org/events/45029/vsm-devcon
date_scraped: 2025-06-29T05:39:06.221809
---

[ Skip to main content ](https://www.scrum.org/events/45029/vsm-devcon#main-content)
#  VSM DevCon
Virtual VSM DevCon is a one-day, digital conference examining the benefits of creating and managing value streams in your development organization. At Virtual VSM DevCon, you will learn how to apply value stream strategies to your development process to gain efficiencies, improve quality and cut costs. Dave West will be speaking about Value Streams and Scrum at this event.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
