---
source_url: https://www.scrum.org/events/15412/agile-product-open-meet
date_scraped: 2025-06-29T05:06:51.707302
---

[ Skip to main content ](https://www.scrum.org/events/15412/agile-product-open-meet#main-content)
#  Agile Product Open Meet Up 
Join our APO community for an interactive evening including networking, food, drink, and evening activity on our topic, Product Managers "versus" Product Owners". Tickets are $5 in advance or $10 if purchased the day of the event.Reserve your space on Eventbrite now (<https://www.eventbrite.com/e/product-manager-vs-product-owner-with-agile-product-open-tickets-43915600744>). Join us for an action-filled evening in which our evening facilitator, Dave West, CEO and Chief Product Owner with Scrum.org guides us through an activity that is both fun and enlightening on the ever-present confusions and conundrums of what is a PM vs PO. ** Light food and soft drinks / wine / beer will be provided** Agenda: 6:00-6:30 pm: Registration & pre-event networking 6:30-8:30 pm: Product Managers “vs” Product Owner 8:30 - Post-event networking Your registration ahead of time helps us plan food and drink, thank you! Register on Eventbrite here (<https://www.eventbrite.com/e/product-manager-vs-product-owner-with-agile-product-open-tickets-43915600744>). 
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
