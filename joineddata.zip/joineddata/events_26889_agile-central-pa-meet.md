---
source_url: https://www.scrum.org/events/26889/agile-central-pa-meet
date_scraped: 2025-06-29T05:15:17.046482
---

[ Skip to main content ](https://www.scrum.org/events/26889/agile-central-pa-meet#main-content)
#  Agile Central PA Meet Up
User Story Maps are a powerful and popular technique for discovering Agile Work Items (e.g. User Stories) and performing initial high-level planning. This meetup will provide a general introduction to User Story Maps that covers a basic overview of the User Story technique and process, benefits of User Story Maps, and additional resources. 
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
