---
source_url: https://www.scrum.org/events/44958/scrum-day-chennai
date_scraped: 2025-06-29T05:39:00.065080
---

[ Skip to main content ](https://www.scrum.org/events/44958/scrum-day-chennai#main-content)
#  Scrum Day Chennai
Scrum Day Chennai is tryScrum's flagship conference bringing all the best, most emergent ideas about Organizational Agility and some of the most important global minds working in the field under one roof. It will take place March 19 and 20, 2021.
tryScrum provides the platform for the Agile community to unleash the power and intelligence of people through its Studios. Now we are coming up with Scrum Day, where we proudly feature some of the most important knowledge-sharing, networking, keynotes, and professional interactions for Agile practitioners, Business Leaders, Executives and Professionals all over.
Dave West, Patricia Kong and PST Dan Vacanti are speaking at this event!
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
