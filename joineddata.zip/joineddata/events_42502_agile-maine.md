---
source_url: https://www.scrum.org/events/42502/agile-maine
date_scraped: 2025-06-29T05:37:13.811702
---

[ Skip to main content ](https://www.scrum.org/events/42502/agile-maine#main-content)
#  Agile Maine
Agile organizations know that frequent inspection of results limits risk and improves the ability to deliver value. Their leaders manage investments based on ROI and value. At the same time, they work to influence the organization to create an adaptive culture that allows it to take advantage of opportunities before their competitors do.
Evidence-Based Management (EBM) is a framework organizations can use to help them measure, manage, and increase the value they derive from their product delivery. EBM helps organizations put their right measures in place to invest in the right places, make smarter decisions and reduce risk using an iterative and incremental approach. Using empiricism helps organizations to embrace agile principles and values, helping them seek a better way forward by delivering value, inspecting the results, and adapting their approach to improve.
In this Agile Maine webinar we introduce the Evidence-Based Management framework and address the following questions:
**- What are organizations trying to achieve with agility?**
**- What are organizations trying to achieve with measurement?**
**- Why do traditional measures fail to achieve this?**
**- How can EBM help you continuously improve?**
Patricia Kong is the Product Owner of the Scrum.org enterprise solutions program, which includes the Nexus Framework, Evidence-Based Management, Scrum Studio, and Scrum Development Kit. She is co-author of The Nexus Framework for Scaling Scrum published by Pearson. She is also a public speaker and mentor. She also created and launched the Scrum.org Partners in Principle Program. Patricia emerged through the financial services industry, and has led product development, product management and marketing for several early stage companies in the US and Europe. At Forrester Research, Patricia worked with their largest clients focusing on business development and delivery engagements.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
