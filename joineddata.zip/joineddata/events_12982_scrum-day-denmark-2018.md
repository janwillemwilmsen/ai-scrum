---
source_url: https://www.scrum.org/events/12982/scrum-day-denmark-2018
date_scraped: 2025-06-29T05:04:16.650143
---

[ Skip to main content ](https://www.scrum.org/events/12982/scrum-day-denmark-2018#main-content)
#  Scrum Day Denmark 2018
Denmark
[ Visit Event Website ](http://scrumday.dk)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
