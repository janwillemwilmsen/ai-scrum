---
source_url: https://www.scrum.org/events/52211/give-thanks-scrum-2021
date_scraped: 2025-06-29T05:43:53.997314
---

[ Skip to main content ](https://www.scrum.org/events/52211/give-thanks-scrum-2021#main-content)
#  Give Thanks for Scrum 2021 
Join us on Tuesday November 23, 2021 virtually for Agile Boston’s 13th Annual Give Thanks For Scrum event.
That’s right … for 2021, the GIVE THANKS FOR SCRUM is once again GOING GLOBAL….over Zoom !!
You may not know that Scrum was born in Boston and thus it is very appropriate that Give Thanks For Scrum has become a true Boston tradition! AND NOW A WORLDWIDE EVENT. Register now (at the lowest price) and hear keynote and plenary sessions from our fantastic lineup:
  * Dr. Jeff Sutherland, co-creator of Scrum and founder of SCRUM INC
  * David West, CEO of Scrum.Org, with Elana Chong & Rishi Markenday of McKinsey 
  * Harrison Owen, the originator of Open Space Technology and noted authority on self-organization and self-management
  * Daniel Mezick, author and co-author of three books on organizational change: INVITING LEADERSHIP, OPENSPACE AGILITY, and THE CULTURE GAME. Co-founder of The Open Leadership Network; originator of the OpenSpace Agility engagement model. Coaching Scrum for over 15 years.
  * Antonio Mk Singleton, Prosci® certified ADKAR Practitioner, enterprise Scrum coach, and change management specialist
  * Christiaan Verwijs, Johannes Schartau, Barry Overeem, authors of the best selling book: THE ZOMBIE SCRUM SURVIVAL GUIDE
  * Peter Fischbach, the Germany-based executive coach and noted authority on Scrum. Peter has taught Scrum with Dr. Jeff Sutherland over 40 times. He is a co-producer of the annual Scrum Day event, the largest Scrum conference in Germany
  * Mercy George-Igbafe, educator, agile champion, Scrum professional, executive board member of Women in Agile. Community sponsor, leader and member of Agile Africa (https://agileafrica.net). Founder of Learntor (https://learntor.ng)
  * Dan LeFebvre, a 15-year Scrum professional, the first Certified Enterprise Coach in New England, and a noted authority on Scrum from SCRUM INC.


This event includes a panel Q&A session featuring Jeff, Dave, and Johannes Schartau, co-author of the Zombie Scrum Survival Guide. Bring your toughest questions!
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
