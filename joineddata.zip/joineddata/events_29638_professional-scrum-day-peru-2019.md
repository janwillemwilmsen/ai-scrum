---
source_url: https://www.scrum.org/events/29638/professional-scrum-day-peru-2019
date_scraped: 2025-06-29T05:20:42.158854
---

[ Skip to main content ](https://www.scrum.org/events/29638/professional-scrum-day-peru-2019#main-content)
#  Professional Scrum Day Peru 2019
“Evento Gratuito. Inscripciones en : [**https://lnkd.in/eTkF5Cn**](https://lnkd.in/eTkF5Cn)
Los invitamos al más importante evento de Scrum en el Perú: "Professional Scrum Day", presentado por los expertos de [**Scrum.org**](http://scrum.org/) y principales líderes de transformación digital.
El Professional Scrum Day, es una gran oportunidad para que las personas y organizaciones aumenten las posibilidades de éxito en la búsqueda de mejores resultados, basados en una cultura ágil que se fundamenta en valores de Scrum, usando el empirismo y fomentando la entrega continua de producto, enfocados al objetivo de negocio y en deleitar a nuestros clientes y usuarios.
Keynote: Dave West - CEO [**Scrum.org**](http://scrum.org/) (Vía Skype)
Nuestros Speakers:
Daniel S. Vacanti - Co-founder and CEO at ActionableAgile (Vía Skype).
Aldo Támara - Agile Transformation Coach en Coca Cola Perú (Arca Continental Lindley). Claudio Rodrigues - Gerente de Transformación Digital en Interbank.
Héctor Saira - Subgerente Agility & Open Innovation en BBVA Continental.
Joel Francia - Consultor Agile y Trainer [**Scrum.org**](http://scrum.org/)
Gunther Verheyen - Scrum Caretaker at Ullizee-Inc (Vía Skype).”
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
