---
source_url: https://www.scrum.org/events/33221/fall-experiment-2019
date_scraped: 2025-06-29T05:29:11.897563
---

[ Skip to main content ](https://www.scrum.org/events/33221/fall-experiment-2019#main-content)
#  Fall Experiment 2019
Fall Experiment is an immersive tech, art, gaming and music festival that convenes creators from all over the Greater Midwest. It is a diverse and inclusive festival that celebrates these intersections by hosting a multitude of experiences in specific tracks: developer and UX, product management, startup, tech and art, e-sports and gaming, and music.
Professional Scrum Trainers Chad Beier, Jeff Bubolz and Jeff Maleski will be speaking at the event.
[ visit event website ](https://fallexperiment.com)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
