---
source_url: https://www.scrum.org/events/29108/london-lean-kanban-days
date_scraped: 2025-06-29T05:20:20.145664
---

[ Skip to main content ](https://www.scrum.org/events/29108/london-lean-kanban-days#main-content)
#  London Lean Kanban Days
United Kingdom
Following the success of our 6 previous years, the BCS Agile SG is organizing another round of talks and workshops from some of the most respected figures in the Kanban and Agile world. Again, as a 2-day conference.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
