---
source_url: https://www.scrum.org/events/43516/entwicklertag-karlsruhe-2021
date_scraped: 2025-06-29T05:37:58.530209
---

[ Skip to main content ](https://www.scrum.org/events/43516/entwicklertag-karlsruhe-2021#main-content)
#  Entwicklertag Karlsruhe 2021
The conference for software engineering - "Shaping the digital world - let's talk about it!" Patricia Kong will be speaking at this event.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
