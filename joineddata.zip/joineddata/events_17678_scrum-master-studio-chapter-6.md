---
source_url: https://www.scrum.org/events/17678/scrum-master-studio-chapter-6
date_scraped: 2025-06-29T05:11:09.009629
---

[ Skip to main content ](https://www.scrum.org/events/17678/scrum-master-studio-chapter-6#main-content)
#  Scrum Master Studio Chapter 6 
India
The "Scrum Master Studio" is intended to instill skills within Scrum Masters to create them as future leaders. Leadership require learning, convincing, nurturing and bringing in Change. That doesn't happen overnight, but its a journey. 
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
