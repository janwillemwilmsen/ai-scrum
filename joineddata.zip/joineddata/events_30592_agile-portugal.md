---
source_url: https://www.scrum.org/events/30592/agile-portugal
date_scraped: 2025-06-29T05:23:00.544796
---

[ Skip to main content ](https://www.scrum.org/events/30592/agile-portugal#main-content)
#  Agile Portugal
Portugal
Agile Portugal is the premier international conference in Portugal about agile software development and its practices, technologies, attitudes and experiences. Created with both experts and beginners in mind, Agile Portugal is the place where the Portuguese agile community comes together to exchange and share their experiences about Agile development approaches. Professional Scrum Trainers [Barry Overeem](https://www.scrum.org/user/60) and [Jose Casal ](https://www.scrum.org/jose-casal)will be speaking at this event!
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
