---
source_url: https://www.scrum.org/events/26470/agile-vietnam
date_scraped: 2025-06-29T05:14:39.108305
---

[ Skip to main content ](https://www.scrum.org/events/26470/agile-vietnam#main-content)
#  Agile Vietnam
Vietnam
Agile Vietnam Conference 2018 is Our Annual Conference which bring over 30 speakers and 400 participants in Agile Communities around the world together, sharing experience and best practices about Agile and Lean Practices and relevant software topics like Lean Software Development, Software Craftsmanship, Agile Product Development, High Performing Team and more. Professional Scrum Trainer [Shirley Santiago](https://www.scrum.org/shirley-santiago) is speaking at this conference. 
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
