---
source_url: https://www.scrum.org/events/32511/agile-camp-dallas
date_scraped: 2025-06-29T05:28:10.660708
---

[ Skip to main content ](https://www.scrum.org/events/32511/agile-camp-dallas#main-content)
#  Agile Camp Dallas
Come learn with us at AgileCamp Dallas, located in one of the largest tech hubs in the US!
A city which lives large and thinks big, this magnetic place is one of the top tech regions in the nation. Dallas is a true cosmopolitan city and a sensational location for our conference at the Irving Convention Center. Professional Scrum Trainers [Julee Everett](https://www.scrum.org/julee-bellomo), [Nigel Thurlow](https://www.scrum.org/nigel-thurlow) and [Ram Srinivasan](https://www.scrum.org/ram-srinivasan) will be speaking at this event.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
