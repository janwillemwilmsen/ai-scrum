---
source_url: https://www.scrum.org/events/32510/agile-camp-portland
date_scraped: 2025-06-29T05:28:04.993329
---

[ Skip to main content ](https://www.scrum.org/events/32510/agile-camp-portland#main-content)
#  Agile Camp Portland
Gear up for AgileCamp 2019 in the Pacific Northwest!
Portland is a wonderfully eccentric city known for its unique and innovative take on craft beer, coffee, and artisanal foods. This eclectic, creative hub is the perfect location for AgileCamp which will be held at the Nike Headquarters.
With our Keynote Speakers announced, we are curating an awesome program for you. Our full program has been announced. Meanwhile, register by August 20th to take advantage of early-bird discounts for both individuals and groups! Professional Scrum Trainer [Julee Everett](https://www.scrum.org/julee-bellomo) will be speaking at the event.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
