---
source_url: https://www.scrum.org/events/27075/quest-2019
date_scraped: 2025-06-29T05:15:32.143372
---

[ Skip to main content ](https://www.scrum.org/events/27075/quest-2019#main-content)
#  QUEST 2019
QUEST 2019 Conference is the best source for new technologies and proven methods for Quality Engineered Software and Testing. Thought leaders, evangelists, innovative practitioners, and IT professionals from across North America gather together for a week packed with classes, tutorials, educational sessions, hand-on workshops, discussions groups, EXPO, and networking events. Professional Scrum Trainer [Steve Porter](https://www.scrum.org/steve-porter) will be speaking at this event on May 15. 
[ visit event website ](http://qaiquest.org/2019/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
