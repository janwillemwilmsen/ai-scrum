---
source_url: https://www.scrum.org/events/43654/lanzamiento-guia-de-scrum-2020
date_scraped: 2025-06-29T05:38:04.356571
---

[ Skip to main content ](https://www.scrum.org/events/43654/lanzamiento-guia-de-scrum-2020#main-content)
#  Lanzamiento Guía de Scrum 2020
Más transparente Más delgado. Más fácil de acceder y más directo, lo que abre la puerta a más profesionales en nuevas industrias y dominios de negocio.
Menos prescriptivo Scrum es un marco y no una metodología. Los experimentos, los cambios incrementales y los Sprints para entregar valor son los pilares de Scrum.
**UN MARCO CON MÚLTIPLES APLICACIONES** La Guía de Scrum actualizada es más sencilla, pero sigue siendo empírico. Sus pilares como Transparencia, Inspección y Adaptación siguen siendo los pilares de un buen Scrum. Estas actualizaciones se basan en 25 años de Scrum en la práctica. 
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
