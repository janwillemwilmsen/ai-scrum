---
source_url: https://www.scrum.org/events/31296/scrum-day-bandung
date_scraped: 2025-06-29T05:24:23.536879
---

[ Skip to main content ](https://www.scrum.org/events/31296/scrum-day-bandung#main-content)
#  Scrum Day Bandung
Indonesia
After two successes were held in 2017 and 2018, this year the 3rd Scrum Day Bandung will be held again in August 2019. Professional Scrum Trainer Joshua Partogi will be speaking at this event. 
[ visit event website ](http://scrumdaybandung.com/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
