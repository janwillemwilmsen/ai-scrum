---
source_url: https://www.scrum.org/events/18549/agile-impact-conference
date_scraped: 2025-06-29T05:12:14.867259
---

[ Skip to main content ](https://www.scrum.org/events/18549/agile-impact-conference#main-content)
#  Agile Impact Conference
Following the success of the first Agile Indonesia conference in 2017, we have decided to broaden the theme this year. As Agile has gained more popularity in Indonesia, we will have 5 main themes in this year’s conference:
  1. Agile leadership
  2. Business agility
  3. DevOps engineering culture
  4. Agile practices
  5. Digital transformation


By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
