---
source_url: https://www.scrum.org/events/57680/dag-van-de-projectmanager-2022
date_scraped: 2025-06-29T05:46:10.812750
---

[ Skip to main content ](https://www.scrum.org/events/57680/dag-van-de-projectmanager-2022#main-content)
#  Dag van de Projectmanager 2022
Belgium
Ready, set, go! Kriebelt het bij jou ook om terug samen te komen met gelijkgestemde projectmanagers? Wij staan alvast te trappelen om je opnieuw klassikaal te mogen ontvangen!
Op 14 juni 2022, in het Holiday Inn Brussels Airport in Diegem.
Hét jaarlijks event voor en door projectmanagers!
  * Ervaren of beginner?
  * Freelance of intern?
  * In IT, operations, engineering, research, logistiek, events of andere domeinen?
  * In grote of kleine organisaties?


Elk jaar stromen meer dan 200 projectmanagers toe op de Dag van de Projectmanager, sinds 2008 hét symbool voor leren en netwerken op maat van de projectmanager. Ben jij dit jaar, op 14 juni 2022, ook van de partij?
De Dag van de Projectmanager is dé place to be als je je projectmanagementskills wil bijschaven. Al 15 jaar een vaste waarde in de agenda van elke leergierige projectmanager! 
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
