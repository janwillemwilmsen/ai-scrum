---
source_url: https://www.scrum.org/events/4280/agile-tour-dublin
date_scraped: 2025-06-29T04:57:00.198102
---

[ Skip to main content ](https://www.scrum.org/events/4280/agile-tour-dublin#main-content)
#  Agile Tour Dublin
Agile Tour, a series of non-profit events over several cities throughout October and December. For several years, the AgileTour has been a way for enthusiasts of Agile to spread the word about Agile practices and to share their experiences, both good and bad, within their local community.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
