---
source_url: https://www.scrum.org/events/73592/scrum-day-india
date_scraped: 2025-06-29T05:52:27.027321
---

[ Skip to main content ](https://www.scrum.org/events/73592/scrum-day-india#main-content)
#  Scrum Day India
The “Scrum Day India” event is a platform provided to people to share their stories, be inspired by your favorite speakers and connect with the like minded. Over the past two years, everyone’s gotten used to the drill: log in, greet everyone, post your questions in the queue, and then sit back and listen to a full program of speakers – perhaps while sipping on coffee and still in your pajamas. Time to break the shell and have the option to get ready and meet people face to face. There’s an undeniable energy from reconnection in-person. Be ready on July 22nd, 2023 to reconnect and bring about the change that we seek. PST Gunther Verheyen will be speaking at the event. 
[ Visit Event Website ](https://scrumdayindia.org/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
