---
source_url: https://www.scrum.org/events/62963/project-summit-business-analyst-world-boston
date_scraped: 2025-06-29T05:49:19.369275
---

[ Skip to main content ](https://www.scrum.org/events/62963/project-summit-business-analyst-world-boston#main-content)
#  Project Summit / Business Analyst World Boston
United States
ProjectSummit*BusinessAnalystWorld is the largest conference for Project Managers and Business Analysts in North America. This industry leading event features expert speakers representing every sector, from all reaches of the globe.
From the opening Keynote to the close, ProjectSummit*BusinessAnalystWorld offers tangible education and non-stop opportunities to learn. You will leave feeling invigorated and motivated, armed with new skills, tools, and techniques that can be immediately applied in your workplace – not to mention an arsenal of new contacts. PS*BAW Global places great importance on connecting you with others in your community.
Eric Naiburg will be speaking at this event and Scrum.org will have a booth. Please stop by and say hello!
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
