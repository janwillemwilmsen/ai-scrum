---
source_url: https://www.scrum.org/events/18178/toronto-agile-community
date_scraped: 2025-06-29T05:11:40.701642
---

[ Skip to main content ](https://www.scrum.org/events/18178/toronto-agile-community#main-content)
#  Toronto Agile Community
Canada
This year, the 10th Annual Toronto Agile Community Conference is expected to be the largest to date! This will be the best learning and networking event of the year for Agilists in the Greater Toronto Area and you don't want to miss it. The date is October 30th, 2018 at the Beanfield Centre at Exhibition Place. Scrum.org, Global Knowledge and Pyxis will be exhibiting together at this event! 
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
