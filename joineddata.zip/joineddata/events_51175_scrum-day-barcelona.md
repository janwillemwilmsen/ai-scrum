---
source_url: https://www.scrum.org/events/51175/scrum-day-barcelona
date_scraped: 2025-06-29T05:43:26.190669
---

[ Skip to main content ](https://www.scrum.org/events/51175/scrum-day-barcelona#main-content)
#  Scrum Day Barcelona
Do we spend too much time deciphering the theory of Scrum? Could we **achieve more** **talking about user outcomes and business impacts?** In the second edition of Scrumday Barcelona we want to bring new ideas and solutions on a keynote track **learning from the experts** and also **working together on an interactive track**! 
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
