---
source_url: https://www.scrum.org/events/76552/agile-azerbaijan-international-summit-2023
date_scraped: 2025-06-29T05:53:16.563069
---

[ Skip to main content ](https://www.scrum.org/events/76552/agile-azerbaijan-international-summit-2023#main-content)
#  Agile Azerbaijan International Summit 2023
Azerbaijan
The Agile Azerbaijan International Summit 2023 will bring people together on November in Baku to share experiences and make new connections. Join passionate Agilists to learn about the latest practices, ideas, and strategies in Agile world from the leading experts, change agents, and innovators. PSTs [John Coleman](https://www.scrum.org/john-coleman), [Sander Dur](https://www.scrum.org/sander-dur) and [Mehmet Yitmen](https://www.scrum.org/mehmet-yitmen) are speaking at the event.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
