---
source_url: https://www.scrum.org/events/31178/agile-camp-new-york-metro
date_scraped: 2025-06-29T05:24:06.052332
---

[ Skip to main content ](https://www.scrum.org/events/31178/agile-camp-new-york-metro#main-content)
#  Agile Camp - New York Metro
This year’s theme for Agile Camp is Business Agility: Platforms for Change. When embraced by the entire company, Agile is a foundation of change that improves strategy, product innovation, and culture. At AgileCamp 2019, we’ll cover all of these angles and more! Scrum.org is sponsoring this event. Eric Naiburg and Professional Scrum Trainer [Ram Srinivasan](https://www.scrum.org/ram-srinivasan) will be speaking!
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
