---
source_url: https://www.scrum.org/events/25457/software-architecture-conference
date_scraped: 2025-06-29T05:12:32.404882
---

[ Skip to main content ](https://www.scrum.org/events/25457/software-architecture-conference#main-content)
#  Software Architecture Conference
Indonesia
Fast-paced and practical, the Software Architecture Conference will aspire software architects, engineers, and senior developers. Professional Scrum Trainer [Joshua Partogi ](https://conference.sarccom.org/speakers/joshua-partogi/)will be presenting at this conference. 
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
