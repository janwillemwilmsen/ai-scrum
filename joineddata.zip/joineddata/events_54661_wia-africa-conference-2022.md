---
source_url: https://www.scrum.org/events/54661/wia-africa-conference-2022
date_scraped: 2025-06-29T05:44:43.816529
---

[ Skip to main content ](https://www.scrum.org/events/54661/wia-africa-conference-2022#main-content)
#  WiA Africa Conference 2022
**WiA Africa 3 Days Conference 27th – 29th January 2022 – in languages English, French, Portuguese**
Women in Agile (WiA) Africa conference is dedicated to creating awareness, exploring innovative opportunities for Africans by advancing Agile values and principles, and creating a safe space for networking, developing new skills, sharing ideas and flourishing together. Attendance to this conference is FREE for this year.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
