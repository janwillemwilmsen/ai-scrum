---
source_url: https://www.scrum.org/events/16336/agile-2018
date_scraped: 2025-06-29T05:08:41.864547
---

[ Skip to main content ](https://www.scrum.org/events/16336/agile-2018#main-content)
#  Agile 2018
The annual North American conference is dedicated to furthering Agile principles and providing a venue for people and ideas to flourish. This is where the Agile tribes meet. Last year we were joined by nearly 2,200 executives, managers, software developers and researchers from over 40 countries who gathered to hear from recognized experts, authors, innovators and practitioners who offer their unique insights. Scrum.org will be exhibiting at booth #404.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
