---
source_url: https://www.scrum.org/events/25757/yow-night-2018-melbourne-dave-west-nov-15
date_scraped: 2025-06-29T05:14:00.994966
---

[ Skip to main content ](https://www.scrum.org/events/25757/yow-night-2018-melbourne-dave-west-nov-15#main-content)
#  YOW! Night 2018 Melbourne - Dave West - Nov 15
Australia
The Software delivery community is famous for creating new initiatives as the next silver bullet. OOP, CMMI, Spiral, Iterative, RUP, RAD are just some of the trends that have challenged how people approach the discipline of delivering software. Now it is agile and DevOps. Or should I say, it was Agile and now it is DevOps? The Agile movement, named February 2001 focused organizations on empowering teams and working in an empirical way. DevOps, started in 2009 and focuses on holistic system thinking and automation to remove waste and better connect development and operations. Both movements focus on delivering an improved delivery capability, but they approach it differently. Automation vs people, process vs empowerment. Are they different? Should organizations focus on one or another in trying to deliver more value to their customers?
In this talk Dave West, Product Owner and CEO Scrum.org discusses how DevOps and Scrum/Agile can work effectively together to deliver improved customer value. It describes the challenges of DevOps or Scrum first, and why it is important to use the Scrum team as the foundation for DevOps maturity, and where traditional operations and IT fit.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
