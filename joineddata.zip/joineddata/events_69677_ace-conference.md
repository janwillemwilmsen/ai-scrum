---
source_url: https://www.scrum.org/events/69677/ace-conference
date_scraped: 2025-06-29T05:51:25.246899
---

[ Skip to main content ](https://www.scrum.org/events/69677/ace-conference#main-content)
#  ACE! Conference
Poland
ACE! is the largest regional conference of its kind in Central Europe, attracting people from all over the region. We're really excited about the next edition which will combine two tracks: Agile Software Development and Product Design & Management into one conference. PST [Magdalena Firlit](https://www.scrum.org/magdalena-firlit) will be speaking at this event. 
[ Visit Event Website ](https://aceconf.com/home)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
