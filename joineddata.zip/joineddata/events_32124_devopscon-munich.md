---
source_url: https://www.scrum.org/events/32124/devopscon-munich
date_scraped: 2025-06-29T05:26:38.077917
---

[ Skip to main content ](https://www.scrum.org/events/32124/devopscon-munich#main-content)
#  DevOpsCon Munich
Germany
DevOps is fundamentally changing the IT world and sets the path for successful business transformation. Join DevOpsCon to learn about the latest tools, technologies, and methodologies for building and maintaining secure, scalable, and resilient software systems. Professional Scrum Trainer Julia Wester will be speaking at the event.
[ visit event website ](https://devopsconference.de/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
