---
source_url: https://www.scrum.org/events/71909/online-scrum-master-summit
date_scraped: 2025-06-29T05:51:58.793729
---

[ Skip to main content ](https://www.scrum.org/events/71909/online-scrum-master-summit#main-content)
#  Online Scrum Master Summit
No matter how experienced you are as Scrum Master, you are in the right place to learn from other agile experts from around Europe. During the Online Scrum Master Summit you can attend several sessions with speakers from all over Europe to get tips, tricks and techniques that will help you expand your role in the world of Agile. Get inspired and level up in your role as Scrum Master. PST [Evelien Roos](https://www.scrum.org/evelien-roos) is speaking at this event.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
