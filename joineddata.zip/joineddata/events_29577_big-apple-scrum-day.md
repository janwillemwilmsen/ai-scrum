---
source_url: https://www.scrum.org/events/29577/big-apple-scrum-day
date_scraped: 2025-06-29T05:20:31.054723
---

[ Skip to main content ](https://www.scrum.org/events/29577/big-apple-scrum-day#main-content)
#  Big Apple Scrum Day
On May 10th 2019, Big Apple Scrum Day (BASD) will celebrate its 5th anniversary with agile enthusiasts from around the world. BASD invites you to explore the learnings (successes AND failures) of others and share your own. There will be talks, workshops and games, about people, product and practices with a high probability of fun! Professional Scrum Trainer [Robb Pieper](https://www.scrum.org/robert-pieper) will present, "Financing Agile Delivery with Forecasts."
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
