---
source_url: https://www.scrum.org/events/15023/agility-today
date_scraped: 2025-06-29T05:05:45.755962
---

[ Skip to main content ](https://www.scrum.org/events/15023/agility-today#main-content)
#  Agility Today
India
AgilityToday is a 2 days UnConference, focused on Delhi-NCR's Agility needs, gathered over past 3 years via meetups, Conferences and Webinar. This UnConference intends to give you best of Agile Psyche (Mindset Culture and Practice) and Geekery (Engineering, Tools and DevOps) via specially crafted 'Hands-on Workshops', 'Case Studies', 'Research Reports' and Solution-driving, Topic-Specific 'Open Space'.
[ Visit Event Website ](https://agilitytoday.com/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
