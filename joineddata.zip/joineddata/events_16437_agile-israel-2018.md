---
source_url: https://www.scrum.org/events/16437/agile-israel-2018
date_scraped: 2025-06-29T05:08:58.354729
---

[ Skip to main content ](https://www.scrum.org/events/16437/agile-israel-2018#main-content)
#  Agile Israel 2018
Agile Israel 2018, the central Agile event in Israel running for the 11th consecutive year, bringing world class agile experts and inspiring case studies to help you learn tips and tricks that can be applied in your organization to expand your Agile/DevOps implementations to reach real business agility.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
