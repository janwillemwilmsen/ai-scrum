---
source_url: https://www.scrum.org/events/12411/agile-dev-east-conference
date_scraped: 2025-06-29T05:03:10.018448
---

[ Skip to main content ](https://www.scrum.org/events/12411/agile-dev-east-conference#main-content)
#  Agile Dev East Conference
United States
Whether you’re new to the agile process and need to get up to speed quickly or you’re experienced and ready to take your team or organization to the next level, our hands-on, in-depth workshops have you covered. Plus, Agile Dev East is held in conjunction with Better Software and DevOps East, allowing you to choose from three distinct programs.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
