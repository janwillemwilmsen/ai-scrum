---
source_url: https://www.scrum.org/community
date_scraped: 2025-06-30T00:23:16.272382
---

[ Skip to main content ](https://www.scrum.org/community#main-content)
#  Connect with the Scrum.org Community
## Learn from the experience of people like you, Scrum practitioners, Professional Scrum Trainers and Scrum.org staff
There are a lot of different ways within the Scrum.org Community to grow and connect with others who are practicing and learning Scrum.
### Scrum Forum
The Scrum Forum provides an interactive space where you can learn how others are solving specific challenges related to Scrum, begin discussions on Scrum related topics with other Scrum Practitioners and Professional Scrum Trainers or simply pose Scrum-related questions you have to our community. [Participate in the Scrum Forum](https://www.scrum.org/forum/scrum-forum)
### Events
There are a variety of events and conferences that members of our community support and participate in. Events are a great place to learn from others and share your experiences. [Attend events](https://www.scrum.org/events)
### Scrum.org Community Meetups
Continue your ongoing learning journey and network with other Scrum practitioners through meetups hosted by Professional Scrum Trainers and Scrum.org training partners. [Join community meetups](https://www.scrum.org/scrumorg-community-meetups "Scrum.org Community Meetups")
### Professional Scrum Trainer Community
Professional Scrum Trainers (PSTs) are professionals licensed by Scrum.org to teach the official Scrum.org curriculum. They also provide coaching, consulting and other services to help people and organizations be improve. Experienced Scrum practitioners make up our PST Community and each bring those experiences to the classroom. We are always looking for more trainers to join us! 
  * [Apply to become a PST](https://www.scrum.org/node/5077)


### Professional Scrum Training Network Partners
The Scrum.org Professional Training Network (PTN) consists of a group of organizations that Scrum.org has officially recognized as training partners. Professional Scrum Trainers (PSTs) work with PTN members to deliver Professional Scrum training and abide by the high quality standards of Scrum.org. 
  * [Find a training partner](https://www.scrum.org/professional-training-network)
  * [Become a training partner](https://www.scrum.org/node/5075)


### University Partners
Scrum.org believes that individuals should have all the tools necessary to join the workforce as productive and valued members of their teams. Therefore Scrum.org and our community of Professional Scrum Trainers are pleased to work with universities to help their students understand and gain the practical skills necessary to work in a fast-paced digital environment that requires a relentless focus on providing customer value by continuously adapting based on learning. [Find university partners](https://www.scrum.org/university-partner-program "University Partner Program")
### Webcasts
Connect with others and grow your knowledge through our two webcast series. ScrumPulse is an educational live webcast series designed to help those new to Scrum and those with experience learn and improve. We also offer an Ask a Professional Scrum Trainer series, which is a live interactive session where you can bring your toughest Scrum questions and challenges! There are also recordings available for all of our webcasts. [Watch recorded and register for scheduled webcasts](https://www.scrum.org/resources?field_resource_tags_target_id=All&type=116)
### Podcasts
Learn from Professional Scrum Trainers and other Scrum practitioners sharing their stories and experiences on the Scrum.org Community Podcast. There are also other podcasts where PSTs and Scrum.org staff participate to share their insights. [Listen to podcasts](https://www.scrum.org/resources?field_resource_tags_target_id=All&type=115)
### Blog
Professional Scrum Trainers and Scrum.org staff share their insights on the Scrum.org blog based on their experiences as Scrum practitioners. Feel free to share your feedback on these blogs in the comments. [Read blog articles](https://www.scrum.org/resources/blog)
### Commitment to Diversity and Social Responsibility
Scrum.org is committed to conducting business in a socially responsible way, and that permeates through our community and activities within it. This means we take deliberate action to align our day-to-day activities with both our mission and the needs of society as a whole. Our staff and Professional Scrum Trainer (PST) Community are accountable for acting with integrity through our Social Responsibility Commitment. [Explore our approach to social responsibility](https://www.scrum.org/about-us/scrumorg-diversity-and-social-responsibility "Diversity and Social Responsibility")
### Stay Up to Date with the Latest from Scrum.org
Scrum.org provides several ways to stay informed about the latest happenings in our community! We invite you to subscribe to our newsletters to receive the latest information about training courses in your area, read the latest blogs and get notified of upcoming webcasts to help continue your learning journey. [Subscribe to newsletters](https://www.scrum.org/node/5074)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
