---
source_url: https://www.scrum.org/events/48946/scrum-day-india-2021
date_scraped: 2025-06-29T05:41:47.462770
---

[ Skip to main content ](https://www.scrum.org/events/48946/scrum-day-india-2021#main-content)
#  Scrum Day India 2021
Scrum Day India is coming up July 17 as a virtual event. PST Gunther Verheyen will be speaking.
[ visit event website ](https://scrumdayindia.org/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
