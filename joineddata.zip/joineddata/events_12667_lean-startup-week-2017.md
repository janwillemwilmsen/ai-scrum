---
source_url: https://www.scrum.org/events/12667/lean-startup-week-2017
date_scraped: 2025-06-29T05:03:48.093124
---

[ Skip to main content ](https://www.scrum.org/events/12667/lean-startup-week-2017#main-content)
#  Lean Startup Week 2017
United States
The 2017[ Lean Startup Week](https://2017.leanstartup.co/) is themed around "The Startup Way," Eric Ries’s upcoming book, which focuses on making entrepreneurship a fundamental discipline of every enterprise. On Oct. 30-Nov. 5, we’re gathering thousands of thought leaders in downtown San Francisco for a week of keynote talks, interactive workshops, speed mentoring, roundtable discussions, industry dinners, innovation bootcamps, and startup tours. You’ll take in the new concepts Eric writes about in "The Startup Way" and learn from seasoned enterprise leaders, founders of high-growth startups, government innovators, and non-profit practitioners who are deep in the trenches. Plus you'll receive a copy of the new book. 
Use Promo Code **scrumdiscount** when you [register](http://2017.leanstartup.co/?promo=scrumdiscount) for a $200 discount.
[ Visit Event Website ](https://2017.leanstartup.co/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
