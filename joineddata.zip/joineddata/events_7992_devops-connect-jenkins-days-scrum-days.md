---
source_url: https://www.scrum.org/events/7992/devops-connect-jenkins-days-scrum-days
date_scraped: 2025-06-29T04:59:30.642203
---

[ Skip to main content ](https://www.scrum.org/events/7992/devops-connect-jenkins-days-scrum-days#main-content)
#  DevOps Connect: Jenkins Days & Scrum Days
United States
Returning for its 3rd year, DevOps.com brings DevOps Connect to Innotech Dallas, April 24th- April 26th,2017 at the Irving Convention Center. This year’s three-day event is themed around the DevOps, DevSecOps, Jenkins and Scrum. The first two days, will feature hands on training classes leading to certification in Scrum, DevOps and more. 
The event will kick off with tandem Scrum classes: [Professional Scrum Master](https://www.scrum.org/courses/professional-scrum-master-dallas-tx-2017-04-24-7910) with [Ty Crockett](https://www.scrum.org/user/163) and [Don McGreal](https://www.scrum.org/user/136), and [Scaled Professional Scrum](https://www.scrum.org/courses/scaled-professional-scrum-dallas-tx-2017-04-24-7912) with [Ravi Verma](https://www.scrum.org/ravi-verma).
The third day of DevOps Connect will feature a morning of keynote speakers by leaders of the Agile/Scrum/DevOps/CD space. Of particular note are a talk and workshop on [ScrumOps](https://devopsconnectdevopsexpresss2017.sched.com/event/A0pF/scrumops?iframe=no&w=100%&sidebar=yes&bg=no) with [Dave West](https://devopsconnectdevopsexpresss2017.sched.com/speaker/davewest2) and a short [Scaling Scrum](https://devopsconnectdevopsexpresss2017.sched.com/event/A0pL/scaling-scrum-workshop?iframe=no&w=100%&sidebar=yes&bg=no) workshop with [Patricia Kong](https://devopsconnectdevopsexpresss2017.sched.com/speaker/patricia.kong) and [Ravi Verma](https://devopsconnectdevopsexpresss2017.sched.com/speaker/raviverma). 
Scrum Days are sponsored by Scrum.org, the “Home of Scrum.” With professional Scrum training, resources and more, Scrum.org brings Scrum and Agile best practices to the market. Their involvement in this DevOps event promises to bring Scrum and Scrum.org to the forefront of the DevOps movement as well.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
