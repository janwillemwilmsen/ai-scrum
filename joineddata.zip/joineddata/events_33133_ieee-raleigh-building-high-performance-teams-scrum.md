---
source_url: https://www.scrum.org/events/33133/ieee-raleigh-building-high-performance-teams-scrum
date_scraped: 2025-06-29T05:29:00.543803
---

[ Skip to main content ](https://www.scrum.org/events/33133/ieee-raleigh-building-high-performance-teams-scrum#main-content)
#  IEEE - Raleigh - Building High Performance Teams with Scrum
Software is created by teams and teams of teams. Thus creating high performance teams is the holy grail of software development process improvement. But what does high performance really mean? In this talk Dave West Product Owner Scrum.org and former Forrester Analyst talks about how Scrum has become the most popular Agile approach and how it can help organizations build high performance teams using Scrum to bring everyone together in a simple, light weight framework. He describes the genesis of Scrum, and how organizations are employing Scrum at the team and product level. He will introduce the idea of professional Scrum and how the mechanics of Scrum combined with technical excellence and pursuit of the Scrum values enables organizations to transform their delivery teams. He will highlight where Scrum makes sense and where it does not.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
