---
source_url: https://www.scrum.org/events/40678/mad-city-agility-conference
date_scraped: 2025-06-29T05:35:20.959608
---

[ Skip to main content ](https://www.scrum.org/events/40678/mad-city-agility-conference#main-content)
#  Mad City Agility Conference
ARE YOU A TRAILBLAZER? REBEL? CHANGE AGENT? BOAT ROCKER? WELCOME!
"Mad" is typically a reference to "mad scientist" which implies outside of the norm thinking and experimentation. That's Mad City Agility 2020 - we are focusing on revolutionary, rebellious, "mad" thinking that is required in 2020 and beyond for organizational agility.
We are about 2 decades into the agile revolution. As we enter the _Roaring ‘20s of Agility_ let’s use the empirical data we have since the creation of the agile manifesto to forecast the future.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
