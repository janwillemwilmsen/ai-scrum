---
source_url: https://www.scrum.org/events/71123/karlsruher-entwicklertag-2023
date_scraped: 2025-06-29T05:51:42.496613
---

[ Skip to main content ](https://www.scrum.org/events/71123/karlsruher-entwicklertag-2023#main-content)
#  Karlsruher Entwicklertag 2023
Germany
The Karlsruher Entwicklertag is a regional conference on the topic of software engineering. In 2005 it took place for the first time, at that time as a one-day grassroots and networking event for the
local IT community from the Karlsruhe region. The format was expanded, but the target group remained.
Traditionally, the networking of software developers from the industry and the universities plays a major role. The special atmosphere - excellent contributions, close contact with the speakers, many interactive - now attracts participants from all over the German-speaking countries. In the meantime the - Karlsruher Entwicklertag, which currently has two days, attracts around 300 participants.
In 2023, the conference will begin with the Conference Day on June 14 and ends with the Agile Day on June 15. You can expect exciting keynote speakers, varied presentations and an interesting entertainment program - everything that the Karlsruher Entwicklertag is known for.
[ Visit Event Website ](https://www.entwicklertag.de/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
