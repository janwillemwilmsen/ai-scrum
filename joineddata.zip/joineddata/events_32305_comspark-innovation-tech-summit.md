---
source_url: https://www.scrum.org/events/32305/comspark-innovation-tech-summit
date_scraped: 2025-06-29T05:26:49.174886
---

[ Skip to main content ](https://www.scrum.org/events/32305/comspark-innovation-tech-summit#main-content)
#  Comspark Innovation Tech Summit
Innovation Tech Summit is a world-class experience designed for the person with a passion for tech and innovation. The goal is simple: to help you grow as a professional, provide opportunities to meet and learn from industry leaders, and celebrate how innovation and technology are impacting our world.
Come and join CIOs, CTOs, and CFOs, executives, developers, entrepreneurs, innovators, and dreamers with a passion for tech for our region's landmark celebration of technology and innovation.
Experience a full day of top-quality tech programs that will inspire your passion for innovation and learning.
The event provides opportunities to build relationships, learn from industry professions, visit with vendors and network with a variety of tech professionals. Your full day experience will include workshops, speakers, dozens of tech providers and demonstrations. 
Professional Scrum Trainer Mark Wavle will be speaking on a panel at the event.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
