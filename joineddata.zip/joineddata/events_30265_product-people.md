---
source_url: https://www.scrum.org/events/30265/product-people
date_scraped: 2025-06-29T05:22:33.367107
---

[ Skip to main content ](https://www.scrum.org/events/30265/product-people#main-content)
#  Product People
Germany
The Product People is a gathering of people in the Product Development space and it is held in Cologne, Germany. Professional Scrum Trainer [Alexander Hardt](https://www.scrum.org/user/53) will be presenting - How to hack the Product Owner Dilemma "Expert consultation": Your individual Product Owner Learning Path (Scrum Competency Framework).
[ visit event website ](http://productpeople.net/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
