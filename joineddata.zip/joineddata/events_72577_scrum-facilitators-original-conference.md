---
source_url: https://www.scrum.org/events/72577/scrum-facilitators-original-conference
date_scraped: 2025-06-29T05:52:10.121782
---

[ Skip to main content ](https://www.scrum.org/events/72577/scrum-facilitators-original-conference#main-content)
#  The Scrum Facilitators Original Conference
Netherlands
Sharing and collaborating on topics about Agility, Scrum and Kanban are in our Scrum Facilitators’ DNA. Usually, the more the merrier, but for this conference we make an exception.
This conference is an original conference and that means that you will see original, never seen before workshops and presentations about agility.
[ Visit Event Website ](https://sfconference.nl/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
