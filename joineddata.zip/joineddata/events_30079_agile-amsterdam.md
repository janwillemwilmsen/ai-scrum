---
source_url: https://www.scrum.org/events/30079/agile-amsterdam
date_scraped: 2025-06-29T05:21:34.923006
---

[ Skip to main content ](https://www.scrum.org/events/30079/agile-amsterdam#main-content)
#  Agile Amsterdam
Netherlands
Companies are committed to become more agile. It allows them to respond more quickly to changing market conditions.
But as the saying goes: getting at the top is easier than staying there. And it is even harder to push yourself beyond the top. The same applies for your agile transformation.
In this event we are going to explore how to protect, sustain and further grow your agile practice. Speakers include Professional Scrum Trainers Christiaan Verwijs and Barry Overeem. Patricia Kong will also be speaking at the event!
[ visit event website ](http://www.agileamsterdam.nl/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
