---
source_url: https://www.scrum.org/events/30671/agile-hartford-may-2019
date_scraped: 2025-06-29T05:23:17.433012
---

[ Skip to main content ](https://www.scrum.org/events/30671/agile-hartford-may-2019#main-content)
#  Agile Hartford May 2019
At the core of Scrum is the empowered self-organized team. However, when organizations scale, if they are not careful, they can dis-empower teams and destroy self-organization. When they do, they don't get what they are looking for, and the teams end up feeling defeated and unmotivated. When organizations impose order and consistency from the top down, they lose the benefits of Scrum. What organizations need is to scale the benefits of Scrum to multiple teams working together to deliver an integrated product, but without destroying transparency and the courage, respect, commitment, focus, and openness that Scrum encourages.
_**Here's your opportunity to learn from one of the authors!**_
**Patricia Kong** of **Scrum.org** , co-author of "The Nexus Framework for Scaling Scrum", will lead this session. She'll take us through an interactive game, based on Nexus, that replicates the challenges of scaling product development across many teams.
We will learn how the Nexus Framework, like Scrum, promotes bottom-up thinking with top down support in order to discover and emerge what works best for your organization.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
