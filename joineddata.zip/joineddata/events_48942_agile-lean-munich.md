---
source_url: https://www.scrum.org/events/48942/agile-lean-munich
date_scraped: 2025-06-29T05:41:30.858222
---

[ Skip to main content ](https://www.scrum.org/events/48942/agile-lean-munich#main-content)
#  Agile Lean Munich
The Agile Lean Munich is an open space conference from the agile community for the agile community and for the people who want to join it. Here you can meet beginners, advanced and experts in the agile working world who take on or want to take on different roles: From Product Owners, Scrum Masters, Developers, HR to executives who want to prepare for digital transformation or who are already in it. PST Simon Flossmann is speaking at the event about Cross Team Refinement!
[ visit event website ](https://agile-lean-munich.de/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
