---
source_url: https://www.scrum.org/events/39846/requisite-agility
date_scraped: 2025-06-29T05:35:03.339948
---

[ Skip to main content ](https://www.scrum.org/events/39846/requisite-agility#main-content)
#  Requisite Agility
The purpose of this RA Discovery Event is for all of us to rally together to envisage the future of organisations and leadership, together. Rather than find ways to avoid or deny turbulence and chaos, RA taps the energy in change and puts it to use in the required or necessary transformation. It is not agility for the sake of agility or being a slave to a particular guru, theory, model, cure for all. It is all of us using the time we have now to create the new future on the day after and beyond!
The online Journey begins with 2 days of Discovery, followed by 12 days of Exploration integrating the insights emerging from the community of participation.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
