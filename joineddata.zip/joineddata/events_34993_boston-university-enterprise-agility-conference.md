---
source_url: https://www.scrum.org/events/34993/boston-university-enterprise-agility-conference
date_scraped: 2025-06-29T05:31:49.574456
---

[ Skip to main content ](https://www.scrum.org/events/34993/boston-university-enterprise-agility-conference#main-content)
#  Boston University Enterprise Agility Conference
United States
This year's theme for the BU Enterprise Agility Conference is Business Agility through Deploying Authentic Agile: A real world and a research view. Dave West will be speaking a the event.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
