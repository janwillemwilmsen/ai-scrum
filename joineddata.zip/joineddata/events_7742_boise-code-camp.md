---
source_url: https://www.scrum.org/events/7742/boise-code-camp
date_scraped: 2025-06-29T04:58:32.037627
---

[ Skip to main content ](https://www.scrum.org/events/7742/boise-code-camp#main-content)
#  Boise Code Camp
United States
his free-to-the-community event has become Boise’s premier software development technical event. Boise Code Camp offers a full day of technology learning for the best price possible: free! Spend a day improving your game, learning the latest technology and networking with your technical peers. 
There are six to eight hour-long sessions on various disciplines: from database fundamentals, requirements creation, cloud computing, agile practices, or networking advances. Attendees can choose which sessions to attend. Boise Code Camp provides relevant content for technology practitioners of all levels and interests.
Code Camp offers open sessions provided by leading technology professionals, including Scrum.org PST [Richard Hundhausen](https://www.scrum.org/user/199).
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
