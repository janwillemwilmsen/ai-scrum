---
source_url: https://www.scrum.org/events/31288/evidence-based-management-workshop-delft
date_scraped: 2025-06-29T05:24:11.747512
---

[ Skip to main content ](https://www.scrum.org/events/31288/evidence-based-management-workshop-delft#main-content)
#  Evidence-Based Management Workshop - Delft
Netherlands
## Evidence-Based Management workshop
Many companies switch their software delivery framework to Agile while still retaining waterfall definitions of value like ''on-scope, on-time, on-budget''. Or worse, the misuse agile metrics like velocity and burn-down charts to micro-manage teams and create un-intended destruction of value. 
In this workshop, we explore what evidence might indicate Business Agility and what indicators might help measure and continuously improve business outcomes. We will introduce the Evidence-Based Management Framework by Scrum.org and in the process, we will explore how to define and improve value and outcomes for your customers. Evidence-based, or  _empirical_ measurement helps organizations to better understand, help, and guide their agile initiatives. This workshop will be taught by Professional Scrum Trainer Wilbert Seele and Patricia Kong.
## Who Should Attend
  * Senior product/LOB executives who need their organizations to engage more frequently and deeply with customers
  * Senior leaders who are sponsoring an agile transformation
  * Organizational change team members who will be helping their organization through an agile transformation
  * Scrum Masters and anyone on a Scrum Team who wants to know more about how to measure and guide a team based on evidence


## Course Objectives
  * Understanding when, where, and why organizations need agility
  * Product health and how to measure it in 4 dimensions 
    * Unrealized value
    * Ability to Innovate
    * Time to Market
    * Current Value
  * How to apply EBM to managing agile initiatives
  * How to get started


By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
