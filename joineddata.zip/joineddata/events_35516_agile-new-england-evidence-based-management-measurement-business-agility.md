---
source_url: https://www.scrum.org/events/35516/agile-new-england-evidence-based-management-measurement-business-agility
date_scraped: 2025-06-29T05:32:32.573680
---

[ Skip to main content ](https://www.scrum.org/events/35516/agile-new-england-evidence-based-management-measurement-business-agility#main-content)
#  Agile New England - Evidence-Based Management - Measurement for Business Agility
United States
In this meeting of Agile New England, Patricia Kong will speak about Evidence-Based Management. 
Scrum helps organizations more effectively deliver value under conditions of uncertainty. However, when organizations forget that Scrum and agility are a means to an end and not the end itself, they often lose sight of their real goal of improving the value they deliver.
Evidence-Based Management (EBM) systemically uses the best available evidence to lead an organization to ever improving customer outcomes and business impacts. The practices of EBM enable organizations to help them manage and relentlessly improve the value they derive from their product delivery. It is developed and sustained by Ken Schwaber and [Scrum.org](https://www.scrum.org/).
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
