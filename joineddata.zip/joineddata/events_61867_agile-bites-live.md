---
source_url: https://www.scrum.org/events/61867/agile-bites-live
date_scraped: 2025-06-29T05:48:44.320295
---

[ Skip to main content ](https://www.scrum.org/events/61867/agile-bites-live#main-content)
#  Agile Bites Live
Netherlands
Agile Bites Live is het flagship event van onze Agile Commun_IT. Leren, doen, netwerken... Alles op een Agile wijze, gepresenteerd door doorgewinterde experts in een inspirerende omgeving. Dit event wordt georganiseerd voor: Scrum Masters, Agile Coaches, Product Owners… iedereen met passie en/of ambitie in de Agile way of working.
Agile Bites Live II: Ignition. Boost jouw manier van Agile werken.
Gunter Verheyen is de sterspreker van de avond. Die ken je van zijn boek: Scrum - A Pocket Guide. Afgelopen jaar verscheen de tweede druk van de Nederlandstalige versie op de markt: “Scrum Wegwijzer”.
Zijn talk gaat over hoe teams en organisaties vaak vastlopen met Scrum. Gunther geeft in zijn keynote mogelijkheden en ideeën om (jouw) Scrum in beweging te krijgen. Daarbij focust hij zich op de organisatiestructuren en management-cultuur binnen organisaties.
Programma
X-wing (over Agile coaching) Boost your Retrospective Keynote speaker Gunter Verheyen over oplossingen voor vastgelopen Scrum Warme maaltijd Workshop “een lopend vuurtje”, bestaande uit: - Lift off (Hoe laat je de vonk overslaan naar het team?) - Star Track (Hoe gebruik je metrics op een goede manier?) - Starchild (Wat bereik je met Serious Play?)
Workshop “best practices” met de LEGO® SERIOUS PLAY® methode Netwerkborrel Plekken zijn beperkt, meld je dus snel aan.
Thema: Ignition Datum: 5 oktober Tijd: 15:00-21:30 uur Locatie: Van Nelle Fabriek, Van Nelleweg 1, Rotterdam Spreker: Gunter Verheyen Facilitators/sprekers: Patricia Verploegh Chassé, Youri Schouten, Arno Balk
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
