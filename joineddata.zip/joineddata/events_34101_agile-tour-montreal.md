---
source_url: https://www.scrum.org/events/34101/agile-tour-montreal
date_scraped: 2025-06-29T05:29:51.779899
---

[ Skip to main content ](https://www.scrum.org/events/34101/agile-tour-montreal#main-content)
#  Agile Tour Montreal
Canada
This year at Agile Tour Montreal, Professional Scrum Trainer David Sabine will be speaking at three sessions presenting the following topics:
- "The Messy Business of Agile at Scale" - "Stop Using Projects to Make Products" - "The Art of Agile Documentation"
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
