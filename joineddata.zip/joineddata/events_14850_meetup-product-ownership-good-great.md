---
source_url: https://www.scrum.org/events/14850/meetup-product-ownership-good-great
date_scraped: 2025-06-29T05:05:24.612053
---

[ Skip to main content ](https://www.scrum.org/events/14850/meetup-product-ownership-good-great#main-content)
#  Meetup - Product Ownership - Good to Great
India
In today's world its not about increasing the productivity but more about reducing the waste. A Product Owner has a critical role to play in reducing the waste so that people are focused on things which really matters. Let's share and learn about how a Product Owner does this.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
