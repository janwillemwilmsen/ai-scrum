---
source_url: https://www.scrum.org/events/27678/practice-agile-community-meetup
date_scraped: 2025-06-29T05:17:18.767005
---

[ Skip to main content ](https://www.scrum.org/events/27678/practice-agile-community-meetup#main-content)
#  Practice Agile Community Meetup
India
Let's welcome 2019 with a fun evening! This meetup at Practice Agile Solutions is an Agile Gamification evening. With years of Agile experience, we have built over 100+ Taboo Cards and the list is still growing. We have used them in our workshops and participants have given us "TWO THUMBS UP"! It's time for us to experiment it with wider audience and we invite everybody to join us in - Community building Understanding Agile, the correct way Empowerment, and more than that ... put your acting skills and your Agile knowledge to test. Practice Agile Taboo cards is an Agile word, guessing, and team building game. The objective of the game is for an Agile team member to have their partners guess the word on the player's card without using the word itself or the additional words listed on the card.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
