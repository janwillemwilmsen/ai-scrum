---
source_url: https://www.scrum.org/events/49786/mad-city-agility
date_scraped: 2025-06-29T05:42:59.301966
---

[ Skip to main content ](https://www.scrum.org/events/49786/mad-city-agility#main-content)
#  Mad City Agility
Rock stars get tired on tours but they always take the stage. Mentally and physically exhausted - they still perform. Change agents are very similar. We keep pushing and challenge our organizations to be better. Are you a boat rocker? Are you a rock star? Join us as we have agile rock stars take the stage this year for Mad City Agility 2021! PSTs Jeff Bubolz and Chad Beier are organizing this event. 
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
