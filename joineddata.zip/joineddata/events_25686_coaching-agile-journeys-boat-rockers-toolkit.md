---
source_url: https://www.scrum.org/events/25686/coaching-agile-journeys-boat-rockers-toolkit
date_scraped: 2025-06-29T05:13:05.953645
---

[ Skip to main content ](https://www.scrum.org/events/25686/coaching-agile-journeys-boat-rockers-toolkit#main-content)
#  Coaching Agile Journeys - The Boat Rocker's Toolkit
Are you tired of the phrase “we’ve always done it this way”? Do you get annoyed by waste? Do you believe there is a difference between efficiency and effectiveness? Me too - I’m a boat rocker. Comfort can lead to complacency. Slight discomfort - like the feeling you have when someone stands up in your canoe and starts rocking back and forth - is a good thing for organizations. Change doesn’t come from complacent people, but from frustrated people who believe there is a better way. This talk by Professional Scrum Trainer Chad Beier highlights skills needed to effectively rock the boat (drive change) within your organization and tactics for doing for so.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
