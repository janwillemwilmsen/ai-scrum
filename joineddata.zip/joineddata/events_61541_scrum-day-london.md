---
source_url: https://www.scrum.org/events/61541/scrum-day-london
date_scraped: 2025-06-29T05:48:38.899890
---

[ Skip to main content ](https://www.scrum.org/events/61541/scrum-day-london#main-content)
#  Scrum Day London
London is one of the most exciting and vibrant cities in the world and a financial capital at the centre of the World Financial market. London is also home to a vast number of companies using Agile practices and the Scrum process. This event provides a unique opportunity where individuals and organizations gather together to share their stories and network as a community. Scrum is all about people. Our speakers have volunteered to share their story to help others achieve success with their Scrum & Agile journey.
Akaditi.com has been organising and running Scrum Day London (Soon to be Scrum Day UK).
Patricia Kong will be speaking at this event.
[ visit event website ](https://scrumdaylondon.com/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
