---
source_url: https://www.scrum.org/events/18390/agile-consortium-annual-conference
date_scraped: 2025-06-29T05:12:04.091920
---

[ Skip to main content ](https://www.scrum.org/events/18390/agile-consortium-annual-conference#main-content)
#  Agile Consortium Annual Conference
Netherlands
Professional Scrum Trainer Evelien Roos will be speaking at this event.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
