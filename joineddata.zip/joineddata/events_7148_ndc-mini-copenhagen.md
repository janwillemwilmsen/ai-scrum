---
source_url: https://www.scrum.org/events/7148/ndc-mini-copenhagen
date_scraped: 2025-06-29T04:58:10.977252
---

[ Skip to main content ](https://www.scrum.org/events/7148/ndc-mini-copenhagen#main-content)
#  NDC Mini Copenhagen
Denmark
Since its start-up in Oslo 2008, the Norwegian Developers Conference (NDC) quickly became one of Europe`s largest conferences for .NET & Agile development. Today NDC Conferences are 5-day events with 2 days of pre-conference workshops and 3 days of conference sessions.
NDC Conferences are run by ProgramUtvikling AS. NDC Mini is a new 3-day event with two days of high quality workshops followed by one day of conference sessions (3 tracks). Although smaller than the 5-day events, NDC Mini has the same high quality you would expect from an NDC Conference.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
