---
source_url: https://www.scrum.org/events/16002/agile-cincinnati
date_scraped: 2025-06-29T05:07:02.934784
---

[ Skip to main content ](https://www.scrum.org/events/16002/agile-cincinnati#main-content)
#  Agile Cincinnati
The annual AgileCincy Conference is tailored to business professionals looking for actionable learnings. Speakers and break-out sessions cover baseline topics like storyboarding and working with Agile principles, core topics like retrospectives and backlog management, and progressive topics like Agile Fluency and OpenSpace Agility. The AgileCincy Conference attendee roster include your peers - motivated to improve their Agile team - and your competition - innovators ready to launch Agile teams at the company next-door. Let’s join together for some entertaining Agile games, thought-provoking discussions, and world-class collaboration!
Speakers include Professional Scrum Trainers [John Coleman](https://www.scrum.org/user/217428), [Chuck Suscheck](https://www.scrum.org/chuck-suscheck) and [Mark Wavle](https://www.scrum.org/user/187). 
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
