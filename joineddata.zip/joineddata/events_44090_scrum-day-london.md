---
source_url: https://www.scrum.org/events/44090/scrum-day-london
date_scraped: 2025-06-29T05:38:22.049680
---

[ Skip to main content ](https://www.scrum.org/events/44090/scrum-day-london#main-content)
#  Scrum Day London
This event provides a unique opportunity where individuals and organizations gather together to share their stories and network as a community. Scrum is all about people. Our speakers have volunteered to share their story to help others achieve success with their Scrum & Agile journey.
[Akaditi.com](http://akaditi.com/) has been organising and running Scrum Day London (Soon to be Scrum Day UK).
Dave West, Martin Hinshelwood, Evelien Roos and Ralph Jocham will be speaking at the event!
[ visit event website ](https://scrumdaylondon.com/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
