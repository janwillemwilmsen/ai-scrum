---
source_url: https://www.scrum.org/events/34057/agile-ne
date_scraped: 2025-06-29T05:29:40.344089
---

[ Skip to main content ](https://www.scrum.org/events/34057/agile-ne#main-content)
#  Agile NE
United Kingdom
At the Agile NE Meetup on November 12, Professional Scrum Trainer Steve Trapps will be presenting the Product Owner Toolkit!
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
