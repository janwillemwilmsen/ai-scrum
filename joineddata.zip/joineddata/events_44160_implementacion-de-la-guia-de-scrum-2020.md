---
source_url: https://www.scrum.org/events/44160/implementacion-de-la-guia-de-scrum-2020
date_scraped: 2025-06-29T05:38:27.658811
---

[ Skip to main content ](https://www.scrum.org/events/44160/implementacion-de-la-guia-de-scrum-2020#main-content)
#  Implementación de la Guía de Scrum 2020
En noviembre de este año tuvimos una gran novedad que afecta la práctica de Scrum en el mundo: El lanzamiento de la Guía de Scrum 2020. Pensando en todos los que practicamos Scrum y estamos estudiando y actualizando nuestros conceptos hemos creado un evento para analizar las implicaciones de la guía en la práctica de Scrum que incluye con ejemplos e incluso los desafíos en la traducción al español de Latinoamérica. Agéndate el 01 de diciembre de 10:00am a 2:00pm (Hora de Colombia) para este evento con la participación del Dave West - CEO de Scrum.org, Fabian Schwartz - CEO de Scrum Network, Lucho Salazar - agilista y traductor del Guía de Scrum y Ralph Jocham - fundador de Effective Agile No te pierdas esta gran oportunidad de tener un análisis de las implicaciones de la guía 2020 por parte de expertos de talla internacional AGENDA: • 10:00am - 10:50am – Dave West: La Esencia de Scrum • 11:00am - 11.50am - Fabian Schwartz - Cambios de la Guia en casos reales • 12:00pm - 12:50pm - Lucho Salazar – Retos en la traducción de la guía y aspectos a tener en cuenta • 1:00pm – 1:50pm - Ralph Jocham y Fabian Schwartz– Discusión de expertos: implicaciones de los cambios en la práctica
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
