---
source_url: https://www.scrum.org/events/25437/tedx-toronto
date_scraped: 2025-06-29T05:12:20.679693
---

[ Skip to main content ](https://www.scrum.org/events/25437/tedx-toronto#main-content)
#  TEDx Toronto
Canada
TEDxToronto is Canada’s largest TEDx event, a platform for exceptional ideas, and a catalyst for profound change. Professional Scrum Trainer, David Dame will be speaking at this event.
[ visit event website ](http://tedxtoronto.com/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
