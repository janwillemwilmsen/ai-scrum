---
source_url: https://www.scrum.org/events/8105/agilia-prague
date_scraped: 2025-06-29T05:00:04.595515
---

[ Skip to main content ](https://www.scrum.org/events/8105/agilia-prague#main-content)
#  Agilia Prague
Czechia
Agilia Prague is a conference about Agile methods in Banking and Finance. This narrow focus on selected topics and private exclusive content makes this event unique.
3 points that makes Agilia Prague so unique.
  1. Narrow focus: Just banking and finance. Specific domain with specific problems.
  2. Leading presenters: no theory, just practical hands-on experience.
  3. Venue at Prague: close to center of financial sector in Czech Republic.


Another important component of the conference is networking: it enables visitors to have in-depth, expert discussions, or to gain business partners.
[Kurt Bittner](http://agiliaprague.com/agilia-prague-conference/speakers/kurt-bittner/) presents: 5 Beliefs that Predict an Enterprise's Success with Agile
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
