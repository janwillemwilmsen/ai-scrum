---
source_url: https://www.scrum.org/events/27225/scrum-day-germany-2019
date_scraped: 2025-06-29T05:15:37.748305
---

[ Skip to main content ](https://www.scrum.org/events/27225/scrum-day-germany-2019#main-content)
#  Scrum Day Germany 2019
Germany
Scrum Day has become the largest community conference over the years. The focus is of course Scrum and everything related to the popular agile framework. So we also address topics such as agile organizational development, agile strategies, agile management, Scrum and agility on a large scale (scaling) and much more.
The aim of the event is to offer the participants a broad communication platform around agility and Scrum in practice.
Professional Scrum Trainers [Evelien Roos](https://www.scrum.org/evelien-roos), [Thomas Schissler](https://www.scrum.org/thomas-schissler), [Daniel Ziegler](https://www.scrum.org/daniel-ziegler), [Peter Gfader ](https://www.scrum.org/index.php/peter-gfader)and [Ralph Jocham](https://www.scrum.org/ralph-jocham) will be speaking at the event. 
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
