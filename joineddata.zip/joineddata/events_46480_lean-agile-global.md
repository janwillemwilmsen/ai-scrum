---
source_url: https://www.scrum.org/events/46480/lean-agile-global
date_scraped: 2025-06-29T05:39:55.227590
---

[ Skip to main content ](https://www.scrum.org/events/46480/lean-agile-global#main-content)
#  Lean Agile Global
Lean Agile Global is a Live Virtual event May 24-25 and will feature talks by PSTs Julia Wester and Daniel Vacanti.
[ visit event website ](https://leanagile.global/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
