---
source_url: https://www.scrum.org/events/32349/unh-paul-college-agile-summit
date_scraped: 2025-06-29T05:27:00.230693
---

[ Skip to main content ](https://www.scrum.org/events/32349/unh-paul-college-agile-summit#main-content)
#  UNH Paul College Agile Summit
The explosive growth of “Agile Movement” is having a profound transformational impact across the global economy. Increasingly organizations are realizing the necessity and importance of adopting an Agile Mindset. Nevertheless, important challenges remain in this endeavor. The Peter T. Paul College of Business and Economics recognizes the essential role Adopting an Agile Mindset and Agile core principles plays in raising and maintaining an organizations operational and innovative edge.
The goal of the 2019 Agile Summit is to provide an opportunity for organizations and individuals to take a day and explore three facets that will further their understanding of Agility. Patricia Kong is speaking at this event about the Nexus framework for scaling Scrum and Betty Zakheim will be on a panel about agile certifications.
Specifically, the Summit is a full-day event comprised of multiple tracks and sessions that will provide individuals and organizations the opportunity to address three significant facets in their personal and corporate growth:
  * What are the best educational investments individuals and organizations can take to advance their value within the Agile Movement?
  * What are the options for organizations to further the benefits of Agile within their organization?
  * How can individuals transition their careers within the Agile Movement?


By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
