---
source_url: https://www.scrum.org/events/36986/scrum-day-ukraine
date_scraped: 2025-06-29T05:34:11.866117
---

[ Skip to main content ](https://www.scrum.org/events/36986/scrum-day-ukraine#main-content)
#  Scrum Day Ukraine
Ukraine
Scrum Day Ukraine is coming up March 21! Professional Scrum Trainers [Magdalena Firlit](https://www.scrum.org/magdalena-firlit), [Oded Tamir](https://www.scrum.org/oded-tamir), [Gunther Verheyen](https://www.scrum.org/gunther-verheyen), [Ahmet Akdag](https://www.scrum.org/user/51) and [Slava Moskalenk](https://www.scrum.org/user/75)o will be speaking!
[ visit event website ](https://scrumday.com.ua/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
