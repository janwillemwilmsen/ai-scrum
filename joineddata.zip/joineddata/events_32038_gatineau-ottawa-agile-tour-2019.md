---
source_url: https://www.scrum.org/events/32038/gatineau-ottawa-agile-tour-2019
date_scraped: 2025-06-29T05:26:06.622571
---

[ Skip to main content ](https://www.scrum.org/events/32038/gatineau-ottawa-agile-tour-2019#main-content)
#  Gatineau Ottawa Agile Tour 2019
Canada
GOAT has run since 2010 and is part of the Agile Tour that takes place in 90 cities worldwide. GOAT19 is an awesome full day conference happening on Friday November 22nd, 2019 at the Shaw Centre, centrally located in downtown Ottawa. Professional Scrum Trainer David Sabine willbe presenting - Phoenix Payroll Catastrophe and why Canada is Destined to Repeat it
[ visit event website ](https://goagiletour.ca/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
