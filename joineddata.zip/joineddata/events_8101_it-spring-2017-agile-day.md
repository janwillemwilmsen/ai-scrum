---
source_url: https://www.scrum.org/events/8101/it-spring-2017-agile-day
date_scraped: 2025-06-29T04:59:47.131843
---

[ Skip to main content ](https://www.scrum.org/events/8101/it-spring-2017-agile-day#main-content)
#  IT Spring 2017 - Agile Day
Belarus
IT Spring 2017 – the largest international conference about IT-business. Since 2012 the event has been gathering project/product managers, CTO/COO, team leaders, department heads, IT business owners, prospective developers, HRM and other professionals.
The aim of the conference is to create environment to exchange successful business experiences, construct optimal product development process using both traditional project management and Agile.
Agile Day will have three tracks: Business Agility, Team Coaching & Facilitation, and Scaled Agile.
PST [Konstantin Razumovsky](https://www.scrum.org/user/85) delivers a talk on Nexus: How We Do Scrum with 150+ People.
[ View Event Website ](http://itspring.by/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
