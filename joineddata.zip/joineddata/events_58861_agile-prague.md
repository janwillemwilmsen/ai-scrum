---
source_url: https://www.scrum.org/events/58861/agile-prague
date_scraped: 2025-06-29T05:46:42.712688
---

[ Skip to main content ](https://www.scrum.org/events/58861/agile-prague#main-content)
#  Agile Prague
Czechia
**The theme of the AgilePrague Conference 2022 is "Sustainable Agility".**
The program is not only about talks, workshops, and games, we are going to **present several practical case-studies** on Agile adoption. 
Agile Prague Conference is building a **unique collaborative environment** where participants not only listen to the speakers but are encouraged to approach them and have a conversation together. Professional Scrum Trainer Roland Flemm will be speaking at the event.
[ Visit Event Website ](https://agileprague.com/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
