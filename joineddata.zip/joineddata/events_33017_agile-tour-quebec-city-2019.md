---
source_url: https://www.scrum.org/events/33017/agile-tour-quebec-city-2019
date_scraped: 2025-06-29T05:28:37.649758
---

[ Skip to main content ](https://www.scrum.org/events/33017/agile-tour-quebec-city-2019#main-content)
#  Agile Tour Quebec City 2019
Canada
Agile Tour Quebec city takes place on October 29. Patricia Kong will be keynoting the event!
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
