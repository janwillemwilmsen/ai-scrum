---
source_url: https://www.scrum.org/events/42461/agile-example
date_scraped: 2025-06-29T05:37:02.571190
---

[ Skip to main content ](https://www.scrum.org/events/42461/agile-example#main-content)
#  Agile by Example
**This year we decided to reimagine ABE20 so that it will happen online.**
We managed to invite amazing speakers and trainers and we planned two full days of talks happening on two virtual stages with live Q&A sessions. To allow more contact with the speakers we decided to leave at least 15 minutes for the Q&A after each talk. 
Moreover we have AskTheExpert sessions on the agenda – we give you the chance to talk 1:1 with the chosen speaker. Ask your questions, network and get advice from the top-notch agile experts.
There will be many networking opportunities, as well as thematic chat discussions.
Patricia Kong and Professional Scrum Trainers Ralph Jocham and Andrii Glushchenko will be speaking at the event. 
[ visit event website ](https://agilebyexample.com/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
