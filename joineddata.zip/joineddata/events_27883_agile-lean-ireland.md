---
source_url: https://www.scrum.org/events/27883/agile-lean-ireland
date_scraped: 2025-06-29T05:17:39.573992
---

[ Skip to main content ](https://www.scrum.org/events/27883/agile-lean-ireland#main-content)
#  Agile-Lean Ireland
Ireland
On April 23rd-26th 2019, we will return to Croke Park, Dublin’s most historic venue, for our 3rd annual conference. This event will feature the cream of International and Irish speakers, with a mix of talks, workshops, coaches clinic and lightning talks. Scrum.org is sponsoring this event
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
