---
source_url: https://www.scrum.org/events/31356/agile-wow-meetup-zombie-scrum
date_scraped: 2025-06-29T05:25:24.398779
---

[ Skip to main content ](https://www.scrum.org/events/31356/agile-wow-meetup-zombie-scrum#main-content)
#  Agile WoW Meetup - Zombie Scrum
India
Scrum (n): A framework within which people can address complex adaptive problems, while productively and creatively delivering products of the highest possible value. However following the rules of Scrum in an organization becomes a challenge. People start changing the rules of the game as per their need while still calling it as Scrum. As expected it doesn't give the expected benefits and we start blaming Scrum. This meetup is to share the anti-patterns to Scrum adopted by the organization and their success and failure experience. The event is co-organized by Xebia and AgileWoW and Scrum.org - The Home of Scrum - [https://scrum.org](https://scrum.org/ "https://scrum.org"). One lucky participant is going to get a FREE ticket to the upcoming training workshop.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
