---
source_url: https://www.scrum.org/events/57761/lean-agile-london
date_scraped: 2025-06-29T05:46:21.785771
---

[ Skip to main content ](https://www.scrum.org/events/57761/lean-agile-london#main-content)
#  Lean Agile London
United Kingdom
We are delighted to announce that Lean Agile London in-person conference is back this year. The conference is confirmed for 23-24 May 2022 and will be held in London at the historic Glaziers Hall. This venue is next to London Bridge overlooking the River Thames. Lean Agile London (#LALDN22) is an affordable not-for-profit conference which focuses on supporting our community in a friendly, safe, diverse and inclusive way. Professional Scrum Trainers Andy Hiles, Andrii Glushchenko, John Coleman, Wilbert Seele, Dan Vacanti, Julia Wester and Sahin Guvenilir will be speaking at the event.
[ visit event website ](https://leanagile.london/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
