---
source_url: https://www.scrum.org/events/37238/agile-lean-europe-riga
date_scraped: 2025-06-29T05:34:28.022657
---

[ Skip to main content ](https://www.scrum.org/events/37238/agile-lean-europe-riga#main-content)
#  Agile Lean Europe Riga
Latvia
ALE is an unconference held around Europe and this year it is coming to Riga! Riga, the capital of Latvia, is an Eastern European gem, steeped in history Latvians take pride in their traditions and culture while converting into open-minded, global citizens. Thus, we welcome travellers and make them feel at home. Professional Scrum Trainer John Coleman will be speaking at the event.
[ visit event website ](https://agilelean.eu/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
