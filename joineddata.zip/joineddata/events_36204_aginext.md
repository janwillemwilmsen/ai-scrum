---
source_url: https://www.scrum.org/events/36204/aginext
date_scraped: 2025-06-29T05:32:53.613339
---

[ Skip to main content ](https://www.scrum.org/events/36204/aginext#main-content)
#  Aginext
United Kingdom
Join us 19-20 March 2020 at London's best agile event to figure out what really takes things to the next level in your organisation. Professional Scrum Trainer [Glaudia Califano](https://www.scrum.org/glaudia-califano) will be speaking at the event at a workshop - Design Thinking with Lego Serious Play. 
[ visit event website ](https://2020.aginext.io/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
