---
source_url: https://www.scrum.org/events/57923/womentech-global-conference
date_scraped: 2025-06-29T05:46:32.322446
---

[ Skip to main content ](https://www.scrum.org/events/57923/womentech-global-conference#main-content)
#  WomenTech Global Conference
​​​​​​The hybrid conference will bring women in tech and allies from all over the world together through an interactive platform featuring live ceremonies, keynotes, engaging panels, breakout rooms, country & chapter leader sessions, technical workshops, and networking with virtual and in-person sessions. Professional Scrum Trainer Evelien Roos is speaking at the event. 
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
