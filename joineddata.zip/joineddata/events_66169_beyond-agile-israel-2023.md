---
source_url: https://www.scrum.org/events/66169/beyond-agile-israel-2023
date_scraped: 2025-06-29T05:50:33.095150
---

[ Skip to main content ](https://www.scrum.org/events/66169/beyond-agile-israel-2023#main-content)
#  Beyond Agile Israel 2023
Israel
Beyond Agile Israel is a hybrid conference that brings Agile practices to light with concrete case studies. Patricia Kong, Scrum.org and PSTs Michel Epstein and Evelien Roos will be speaking at the event!
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
