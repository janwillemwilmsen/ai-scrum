---
source_url: https://www.scrum.org/events/42876/agile-lean-munich
date_scraped: 2025-06-29T05:37:24.541801
---

[ Skip to main content ](https://www.scrum.org/events/42876/agile-lean-munich#main-content)
#  Agile Lean Munich
Professional Scrum Trainer Simon Flossmann will be speaking at Agile Lean Munich. 
[ visit event website ](https://agile-lean-munich.de/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
