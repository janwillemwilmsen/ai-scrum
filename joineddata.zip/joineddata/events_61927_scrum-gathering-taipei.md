---
source_url: https://www.scrum.org/events/61927/scrum-gathering-taipei
date_scraped: 2025-06-29T05:48:54.165713
---

[ Skip to main content ](https://www.scrum.org/events/61927/scrum-gathering-taipei#main-content)
#  Scrum Gathering Taipei
The Taipei regional Scrum Gathering will be a 3 day online event. Dave West will be speaking.
[ Visit Event Website ](https://rsg.taipei/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
