---
source_url: https://www.scrum.org/events/49545/agile-turkey-summit
date_scraped: 2025-06-29T05:42:53.744299
---

[ Skip to main content ](https://www.scrum.org/events/49545/agile-turkey-summit#main-content)
#  Agile Turkey Summit
The Agile Turkey Summit will take place online on November 5.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
