---
source_url: https://www.scrum.org/events/28001/good-mate-workshop
date_scraped: 2025-06-29T05:17:56.762143
---

[ Skip to main content ](https://www.scrum.org/events/28001/good-mate-workshop#main-content)
#  Good Mate Workshop
Want to be more influential with your work mates and help make team projects more successful? Come to our Good Mate Workshop on April 5, 2019. It will be held in Burlington, MA (USA), at the [Scrum.org](http://scrum.org/) classroom and will run from 9AM to 2PM. [Evan Sorensen](http://www.chaostuesday.com/index.php?r=author/view&id=16) and [Jim Johnson](http://www.chaostuesday.com/index.php?r=author/view&id=1) will present an overview of over 65 years of research from The [Standish](https://www.standishgroup.com/) Group (on project team performance) as well as the [Gottman](https://www.gottman.com/) Institute (on personal relationships). The workshop will highlight our new book  _The Good Mate: How Understanding Team Relationships Can Make You Happier and More Productive._ This workshop is neither a team-building exercise nor a technical workshop. It is focused only on how individual team mates can develop better relationship skills for cohesive, productive, and happier teams. 
In this interactive session we will explore:
· 10 Relationship Principles
· 50 Mechanical Relationship Skills & Habits
· Benchmarking Your Relationship Skills
· 3 Skills You Should Improve
· Charts from the CHAOS Database
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
