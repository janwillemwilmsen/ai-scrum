---
source_url: https://www.scrum.org/events/15063/scrum-day-ukraine
date_scraped: 2025-06-29T05:05:50.184411
---

[ Skip to main content ](https://www.scrum.org/events/15063/scrum-day-ukraine#main-content)
#  Scrum Day Ukraine
Ukraine
The best Ukraine’s Scrum open space sponsored by Scrum.org Meetup and communication with Agile Transformation Professionals and the legends of Product Management. Going to offer four concurrent presentations following own rules and available for all attendees. A unique chance to make a selfie with the European Agile Management celebs
[ Visit Event Website ](https://scrumday.com.ua/en/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
