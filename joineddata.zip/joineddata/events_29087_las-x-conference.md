---
source_url: https://www.scrum.org/events/29087/las-x-conference
date_scraped: 2025-06-29T05:20:10.357686
---

[ Skip to main content ](https://www.scrum.org/events/29087/las-x-conference#main-content)
#  LAS X Conference
Switzerland
The Lean Agile Scrum conference will take place May 21-22 in Zurich. Presenters include Professional Scrum Trainer [Ari Byland](https://www.scrum.org/ari-byland).
[ visit event website ](https://lean-agile-scrum.ch)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
