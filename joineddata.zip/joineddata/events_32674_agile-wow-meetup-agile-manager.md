---
source_url: https://www.scrum.org/events/32674/agile-wow-meetup-agile-manager
date_scraped: 2025-06-29T05:28:21.581132
---

[ Skip to main content ](https://www.scrum.org/events/32674/agile-wow-meetup-agile-manager#main-content)
#  Agile WoW meetup - The Agile Manager
India
The next meeting of the Agile WoW Meetup will focus on the role of the Agile Manager. It will be held and Sangam AIC. 
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
