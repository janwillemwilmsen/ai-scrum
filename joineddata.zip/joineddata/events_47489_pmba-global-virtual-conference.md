---
source_url: https://www.scrum.org/events/47489/pmba-global-virtual-conference
date_scraped: 2025-06-29T05:40:18.043997
---

[ Skip to main content ](https://www.scrum.org/events/47489/pmba-global-virtual-conference#main-content)
#  PMBA Global Virtual Conference
ProjectWorld*ProjectSummit*BusinessAnalystWorld is the largest series of conferences for Project Managers and Business Analysts in North America. These industry leading events feature expert speakers representing every sector, from all reaches of the globe.
From the opening Keynote to the close, ProjectWorld*ProjectSummit*BusinessAnalystWorld events offer tangible education and non-stop opportunities to learn. You will leave feeling invigorated and motivated, armed with new skills, tools, and techniques that can be immediately applied in your workplace - not to mention an arsenal of new contacts. PW*PS*BAW places great importance on connecting you with others in your community.
Scrum.org COO Eric Naiburg will be speaking at the event. 
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
