---
source_url: https://www.scrum.org/events/37379/scrum-day-germany
date_scraped: 2025-06-29T05:34:45.310239
---

[ Skip to main content ](https://www.scrum.org/events/37379/scrum-day-germany#main-content)
#  Scrum Day Germany
Germany
At Scrum Day Germany can expect innovation and inspiration, outstanding keynote speakers and, as always, the opportunity to meet lots of interesting people. We want to keep it that way in 2020. The event will take place in Stuttgart on September 21 and 22, 2020 with a limited number of tickets.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
