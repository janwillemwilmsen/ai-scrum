---
source_url: https://www.scrum.org/events/26231/agile-africa
date_scraped: 2025-06-29T05:14:23.455171
---

[ Skip to main content ](https://www.scrum.org/events/26231/agile-africa#main-content)
#  Agile in Africa
Ghana
Agile In Africa 2018 is the premier Agile & Scrum conference in Africa.
[ visit event website ](https://agileinafrica.com/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
