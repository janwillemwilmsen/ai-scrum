---
source_url: https://www.scrum.org/agile-product-operating-model
date_scraped: 2025-06-29T23:52:50.150596
---

[ Skip to main content ](https://www.scrum.org/agile-product-operating-model/#main-content)
# The Agile Product Operating Model
An Evidence-Based Approach
Open Menu 
Content Navigation 
[1. The Agile Product Operating Model](https://www.scrum.org/agile-product-operating-model/the-agile-product-operating-model)
[2. Product Mindset](https://www.scrum.org/agile-product-operating-model/product-mindset)
[2.1. What is a Product?](https://www.scrum.org/agile-product-operating-model/product-mindset/what-is-a-product-)
[2.2. Defining a Product](https://www.scrum.org/agile-product-operating-model/product-mindset/defining-a-product)
[7. Agile Product Portfolio Management](https://www.scrum.org/agile-product-operating-model/portfolio-management)
[8. Change Management](https://www.scrum.org/agile-product-operating-model/change-management)
[9. Evidence-Based Management](https://www.scrum.org/agile-product-operating-model/evidence-based-management)
Content navigation
Content Navigation 
[1. The Agile Product Operating Model](https://www.scrum.org/agile-product-operating-model/the-agile-product-operating-model)
[2. Product Mindset](https://www.scrum.org/agile-product-operating-model/product-mindset)
[2.1. What is a Product?](https://www.scrum.org/agile-product-operating-model/product-mindset/what-is-a-product-)
[2.2. Defining a Product](https://www.scrum.org/agile-product-operating-model/product-mindset/defining-a-product)
[7. Agile Product Portfolio Management](https://www.scrum.org/agile-product-operating-model/portfolio-management)
[8. Change Management](https://www.scrum.org/agile-product-operating-model/change-management)
[9. Evidence-Based Management](https://www.scrum.org/agile-product-operating-model/evidence-based-management)
Loading
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
