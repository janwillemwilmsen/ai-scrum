---
source_url: https://www.scrum.org/events/25603/super-woman-summit
date_scraped: 2025-06-29T05:12:43.397601
---

[ Skip to main content ](https://www.scrum.org/events/25603/super-woman-summit#main-content)
#  Super Woman Summit
Join for a three-day incredible experience of inspiration, conversation, play and activation to support the professional development of strong, successful women leaders. Professional Scrum Trainer Stephanie Ockerman will be speaking at the event.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
