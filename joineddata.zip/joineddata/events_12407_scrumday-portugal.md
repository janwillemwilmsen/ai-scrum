---
source_url: https://www.scrum.org/events/12407/scrumday-portugal
date_scraped: 2025-06-29T05:02:48.132601
---

[ Skip to main content ](https://www.scrum.org/events/12407/scrumday-portugal#main-content)
#  ScrumDay Portugal
Portugal
Discover the SCRUMDAY PORTUGAL® 2017 Edition and all about Agile, Lean, DevOps, Scrum, Sense-Making, High-Performance Teams and much more.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
