---
source_url: https://www.scrum.org/events/44483/witi-virtual-summit
date_scraped: 2025-06-29T05:38:38.667339
---

[ Skip to main content ](https://www.scrum.org/events/44483/witi-virtual-summit#main-content)
#  WITI Virtual Summit
**WITI’s Digital Inclusivity Virtual Summit will be held December 8-10** , where we will marshall our forces and prepare to emerge stronger than ever in 2021.
Because in spite of – or perhaps because of – the inconceivable challenges we’ve had to face, necessity has forced us to **think differently** – to **be resilient** , and to find new ways of getting things done – to dig deeper into our creative mentalities and **create workarounds** – to **integrate technology** into our everyday lives more than we ever imagined.
Professional Scrum Trainer Mica Syjuco will be holding a workshop - Developing Women as DevOps and Agile Leaders on December 8.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
