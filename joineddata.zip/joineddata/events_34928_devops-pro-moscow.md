---
source_url: https://www.scrum.org/events/34928/devops-pro-moscow
date_scraped: 2025-06-29T05:31:33.341031
---

[ Skip to main content ](https://www.scrum.org/events/34928/devops-pro-moscow#main-content)
#  DevOps Pro Moscow
Russia
The DevOps Pro Moscow conference is the leading event where DevOps mindset, skills and tools of development, IT operations and quality assurance (QA) converge. The conference covers the core principles and concepts of the DevOps methodology and demonstrates how to use the most common DevOps patterns to develop, deploy and maintain applications on-premises and in the cloud. Professional Scrum Trainer Martin Hinshelwood will be speaking at the event.
[ visit event website ](https://www.devopspro.ru/en/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
