---
source_url: https://www.scrum.org/events/31994/agile-day-nyc
date_scraped: 2025-06-29T05:25:56.234010
---

[ Skip to main content ](https://www.scrum.org/events/31994/agile-day-nyc#main-content)
#  Agile Day NYC
_10 Years! It’s been a journey and look how far we’ve come in the Agile space. Come celebrate with us as we look back at an incredible 10 years from being the first Agile conference in NYC to becoming an annual tradition for many of our attendees._
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
