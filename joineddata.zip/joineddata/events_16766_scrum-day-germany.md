---
source_url: https://www.scrum.org/events/16766/scrum-day-germany
date_scraped: 2025-06-29T05:09:10.519644
---

[ Skip to main content ](https://www.scrum.org/events/16766/scrum-day-germany#main-content)
#  Scrum Day Germany
Germany
Willkommen zum Scrum Day 2018. Sie erwartet Innovation und Inspiration, herausragende Keynote Speaker und wie immer die Möglichkeit jede Menge interessanter Leute kennenzulernen.
So wollen wir es auch in 2018 halten. Darum laden wir Sie recht herzlich zum Scrum-Day am 12. und 13. Juni 2018 nach Stuttgart ein und freuen uns auf eine rege Beteiligung.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
