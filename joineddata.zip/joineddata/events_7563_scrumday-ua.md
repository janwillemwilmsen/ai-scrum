---
source_url: https://www.scrum.org/events/7563/scrumday-ua
date_scraped: 2025-06-29T04:58:16.478966
---

[ Skip to main content ](https://www.scrum.org/events/7563/scrumday-ua#main-content)
#  ScrumDay UA
Ukraine
The first conference in the Ukraine dedicated to the professional growth of Scrum practitioners. Scrum is the most popular framework for managing the development of complex software products and projects. The main topic of this event is Scaling and Management.
ScrumDay UA is a unique platform for exchanging experience and knowledge. Their goal is to help attendees grow professional skills. The event will be dedicated to workshops and direct communication with Scrum experts from around the world. This conference is for business executives, Scrum professionals, project managers, Product Owners, and employees from IT, finance, and industry sectors.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
