---
source_url: https://www.scrum.org/events/26670/scrum-master-studio-chapter-9-all-about-leadership
date_scraped: 2025-06-29T05:14:49.278207
---

[ Skip to main content ](https://www.scrum.org/events/26670/scrum-master-studio-chapter-9-all-about-leadership#main-content)
#  Scrum Master Studio - Chapter 9 - All about Leadership
India
This Chapter of the Scrum Master Studio Meetup - Chennai will focus on Leadership.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
