---
source_url: https://www.scrum.org/events/32446/ieee-northern-virginia-washington-computer-society-joint-chapter-meeting
date_scraped: 2025-06-29T05:27:11.539769
---

[ Skip to main content ](https://www.scrum.org/events/32446/ieee-northern-virginia-washington-computer-society-joint-chapter-meeting#main-content)
#  IEEE Northern Virginia-Washington Computer Society Joint Chapter Meeting
The Northern Virginia/Washington Chapter of Computer Society welcomes you to its upcoming meeting.
**September 2019 Chapter Meeting:**
**Topic:** Who is the Product Owner Anyway?
**When:** Thursday 26 September 2019 06:30 PM
**Speaker:** Dave West of Scrum.Org
**Abstract:** As Agile become mainstream increasingly organizations are looking to double down on the role of the Product Owner encouraging them to manage the intersection between technology and the business. But Product Ownership is a difficult role as it tries to balance the needs of the business with the reality of software delivery. Also, for many organizations there is some ‘confusion’ with existing roles of business analyst, product manager or even project manager. What does the product owner do anyway? In this talk Dave West, Product Owner and CEO Scrum.org, the home of Scrum, describes the genesis of the Product Owner role and how many organizations are dealing with the challenges of slotting this key role into existing product, project and release roles. He will introduce some techniques such as user-centric design, and hypophysis based development and describe how approaches such as Lean Startup and pragmatic marketing are providing product owners with a tool box to do their job.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
