---
source_url: https://www.scrum.org/events/74932/agile-turkey-summit
date_scraped: 2025-06-29T05:52:42.607076
---

[ Skip to main content ](https://www.scrum.org/events/74932/agile-turkey-summit#main-content)
#  Agile Turkey Summit
Türkiye
The Agile Turkey Summit will take place in Istanbul on November 30. The theme of this year's event is "Navigating Change - Building Resilience".
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
