---
source_url: https://www.scrum.org/events/42621/give-thanks-scrum-2020-virtual
date_scraped: 2025-06-29T05:37:18.843053
---

[ Skip to main content ](https://www.scrum.org/events/42621/give-thanks-scrum-2020-virtual#main-content)
#  Give Thanks for Scrum 2020 (Virtual)
AGILE BOSTON is producing the 12th annual GIVE THANKS FOR SCRUM event, featuring Dave West & Jeff Sutherland, **ONLINE** on November 24th. 
Two from our community Yuval Yeret and Patricia Kong, are also presenting important sessions!
2020 has been quite a *turbulent* year for the world. And for Scrum as many of you know! And interest in Scrum is growing very, very fast, as businesses of all kinds try to cope with this uncertain world. 
In addition to keynotes from Dave West and Jeff Sutherland in the AM, there is a Q&A Panel event with Dave & Jeff in the afternoon. There are also ten (10) other GREAT speakers. All sessions will have group exercises, with small groups in Zoom breakout rooms. You'll meet lots of new people and learn many new things. Lunch provides an opportunity to "sit at a table" with others to meet and converse. 
The event runs 9AM to 4PM on Tuesday, November 24th. AGILE BOSTON is providing a 10% discount to the Scrum.Org community. The discount code is: SCRUMORG-GTFS-DISCOUNT
#GTFS2020
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
