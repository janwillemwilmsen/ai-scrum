---
source_url: https://www.scrum.org/events/31923/testcon-europe
date_scraped: 2025-06-29T05:25:51.039339
---

[ Skip to main content ](https://www.scrum.org/events/31923/testcon-europe#main-content)
#  TestCon Europe
Lithuania
TestCon Europe is the leading conference for everyone willing to learn testing trends, best practices and make their contribution to the smoother software development cycle and quality.
The event provides an excellent platform to keep up-to-date with the latest industry trends, exchange experiences, discuss and deliberate ideas and benefit from networking opportunities.
The event features the hottest topics in industry covering: Test Management, Testing Techniques and Methodologies, Test Automation, Performance Testing, Testing the Internet of Things (IoT), Testing Metrics, Agile Testing, Test Team Leadership and Soft Skills.
Professional Scrum Trainer Peter Gfader will be speaking at this event. Learn more about his talk [here](https://www.testcon.lt/peter-gfader/).
[ visit event website ](https://www.testcon.lt/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
