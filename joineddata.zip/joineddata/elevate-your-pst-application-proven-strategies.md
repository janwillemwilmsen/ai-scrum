---
source_url: https://www.scrum.org/elevate-your-pst-application-proven-strategies
date_scraped: 2025-06-30T00:24:00.949955
---

[ Skip to main content ](https://www.scrum.org/elevate-your-pst-application-proven-strategies#main-content)
#  Elevate Your PST Application with Proven Strategies
##### **Currently Pausing the application process for New PST candidates outside of Japan, China, Mexico, and Other Parts of Latin America**
_To support learners in underserved markets, Scrum.org will continue to actively seek PST candidates from**Japan, China, Mexico, and other parts of Latin America who train in Japanese, Chinese, or Spanish.**_
Para apoyar a los estudiantes en mercados desatendidos, Scrum.org busca activamente candidatos a PST de Japón, China, México y otras partes de América Latina que capaciten en japonés, chino o español. 
過小評価されている市場の学習者をサポートするため、Scrum.org は、日本語、中国語、またはスペイン語で研修を行う、日本、中国、メキシコ、およびラテンアメリカの他の地域からのPST候補者を積極的に募集しています。
为了支持服务不足市场的学习者，Scrum.org 正在积极寻找来自日本、中国、墨西哥和拉丁美洲其他地区，并使用日语、中文或西班牙语授课的 PST 候选人。
**Are you ready to stand out in your Professional Scrum Trainer (PST) application?** Unleash your potential by highlighting critical competencies that will give you a strong foundation as a PST Candidate.
##### **Mission and Values Alignment**
Demonstrate alignment and commitment to the [Scrum.org mission and values](https://www.scrum.org/about "About Scrum.org") as well as the Scrum values.
##### **Professional Scrum Knowledge**
Show throughout that you have a comprehensive understanding of Scrum by frequently connecting to Professional Scrum in action and highlighting outcomes and impact (the ‘why’).
##### **Practical Experience with Professional Scrum and Complementary Practices***
Use stories to show you have deep proficiency in effectively capturing the value Scrum and empiricism have to offer. Here are tips to showcase your excellence across key areas where experience is needed. For all of them, remember to connect directly to Scrum in action and to also highlight complementary practices you have used.
  * **Championing Scrum Principles and values** : Demonstrate your commitment to promoting and supporting Scrum as defined in the Scrum Guide. Showcase how you have fostered an environment that embraces self-management, an empirical mindset, and continuous improvement.
  * **Impact at Different Levels** : Illustrate your experience serving at multiple levels – this should include working with individuals and Scrum Teams, and also working outside of Scrum Teams steering organizational change. Share real-world examples that show your impact at each level.
  * **Depth and Breadth** : Showcase your expertise applying Professional Scrum in diverse settings, environments, and/or contexts. Highlight specific instances where you've successfully implemented Professional Scrum to meet unique challenges and fostered positive outcomes. 
  * **Measurable Business Impact** : Provide concrete evidence of delivering measurable business outcomes. Illustrate your track record of creating tangible value through your application of Professional Scrum. (This is key in the Greatest Scrum Success Story section of the application, however it is also something to include in all stories.)


* For tips on evaluating your experience, check out [FAQ: Understanding Your Professional Scrum Experience](https://www.scrum.org/faq-understanding-your-professional-scrum-experience "FAQ: Understanding Your Professional Scrum Experience").
##### **Communication Skills**
Show that you are a clear, concise, and passionate communicator who can bring Scrum to life through the use of your own lived stories. To do this well, include just enough context and details to come across specific and authentic without going so deep that people lose track or lose interest in what you’re saying. 
  * For example, include a few words to describe the product, and a specific issue that was addressed in a Sprint Retrospective, or the specific feedback that was so important in a Sprint Review. Include what happened in both the shorter and longer term as a result of what you describe.


##### **5-Training Skills**
While two or three of your stories might include leveraging a training stance, limit talking about your classroom training experience to the short section at the end of the application. In that section, include a list of topics you have delivered training on as well as some techniques you typically use to create effective learning environments that unlock new ways of thinking where learners are inspired, motivated and challenged. Note that the Training Skills competency is mostly evaluated later in the PST candidate journey. 
##### **In Summary**
Remember that your PST application is your chance to show what Scrum has done for the organizations you’ve been part of as well as your own effectiveness as a Scrum practitioner. Crafting a compelling PST application is about showcasing your passion, expertise, and real-world impact. Let your experience shine and elevate your career by becoming a standout Professional Scrum Trainer!
### We’re Here For You
If you’re wondering if you’ve got the experience needed to be successful as a PST Candidate, or are looking for tips on how to expand your range of experience with Professional Scrum, [please contact us](https://www.scrum.org/become-professional-scrum-trainer/contact-us-about-becoming-a-trainer "Contact Us About Becoming a Trainer"). 
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
