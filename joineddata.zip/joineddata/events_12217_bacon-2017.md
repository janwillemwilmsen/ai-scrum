---
source_url: https://www.scrum.org/events/12217/bacon-2017
date_scraped: 2025-06-29T05:01:42.620805
---

[ Skip to main content ](https://www.scrum.org/events/12217/bacon-2017#main-content)
#  BACON 2017
United States
BAConference 2017 is excited to bring you easy access to high quality training by industry leaders at an affordable cost as part of your conference package. We will be offering you a choice of 4 different full day sessions to bring your career to a new level. Featured speakers include [Mark Wavle](https://www.scrum.org/user/187).
Sponsored by Professional Training Network providers [Improving](https://www.scrum.org/partners/improving) and [Cardinal Solutions](https://www.scrum.org/partners/cardinal-solutions).
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
