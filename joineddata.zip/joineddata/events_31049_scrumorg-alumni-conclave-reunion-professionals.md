---
source_url: https://www.scrum.org/events/31049/scrumorg-alumni-conclave-reunion-professionals
date_scraped: 2025-06-29T05:23:55.190886
---

[ Skip to main content ](https://www.scrum.org/events/31049/scrumorg-alumni-conclave-reunion-professionals#main-content)
#  Scrum.org Alumni Conclave - A Reunion of Professionals
India
This meetup hosted by Agile Ways of Working and Professional Scrum Trainer Sanjay Saini, is exclusively for Professionals who have gained any certification or had attended a training workshop organized by Scrum.org. In this reunion they will talk about - What are the different challenges do we face as a Professional? What is holding us back as a Professional? What changes would drive us forward in our Professional life? How are we contributing in "Improving the Profession of Software Delivery"
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
