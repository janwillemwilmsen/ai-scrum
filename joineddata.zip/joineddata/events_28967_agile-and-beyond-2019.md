---
source_url: https://www.scrum.org/events/28967/agile-and-beyond-2019
date_scraped: 2025-06-29T05:19:53.885374
---

[ Skip to main content ](https://www.scrum.org/events/28967/agile-and-beyond-2019#main-content)
#  Agile and Beyond 2019
Now entering its 10th year, this annual conference attracts over 800 agile enthusiasts and consistently sells out every year by drawing premier speakers and the highest caliber technologists in the industry. Dave West will be speaking at this event.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
