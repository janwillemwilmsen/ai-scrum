---
source_url: https://www.scrum.org/events/7899/techorama-deep-knowledge-it-conference
date_scraped: 2025-06-29T04:58:54.107850
---

[ Skip to main content ](https://www.scrum.org/events/7899/techorama-deep-knowledge-it-conference#main-content)
#  Techorama: Deep Knowledge IT Conference
Belgium
Techorama is a yearly international technology conference which takes place at Metropolis Antwerp. The attendees are a healthy mix of software developers, IT Professionals, Data Professionals and SharePoint professionals. Techorama offers a unique conference experience with quality content and the best speaker line-up, including [Kurt Bittner](https://techorama2017.sched.com/speaker/kurt_bittner.1w6u5ypv?iframe=no&w=100%&sidebar=yes&bg=no), who will be delivering sessions on [Enterprise Agile Transformation](https://techorama2017.sched.com/event/9M8P/freeze-the-pond-versus-take-the-hill-two-metaphors-for-enterprise-agile-transformation) and [Funding Agile Projects and Products](https://techorama2017.sched.com/event/9M9j/an-outcome-oriented-approach-to-funding-agile-projects-and-products).
[ View Event Website ](http://techorama.be/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
