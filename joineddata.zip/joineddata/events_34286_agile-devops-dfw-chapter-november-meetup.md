---
source_url: https://www.scrum.org/events/34286/agile-devops-dfw-chapter-november-meetup
date_scraped: 2025-06-29T05:30:04.375388
---

[ Skip to main content ](https://www.scrum.org/events/34286/agile-devops-dfw-chapter-november-meetup#main-content)
#  Agile-DevOps: DFW Chapter - November Meetup
United States
The topic for the Agile-DevOps: DFW Chapter - November Meetup is 8 Dimensions of Business Agility: A Structured Approach to Agile Enablement. 
Agility is a buzz word that can be interpreted to mean different things to different people. In this session, we will explore some of these questions together... 1. How might we create alignment and clarity around what agility means to our business? 2. How might we start quantifying and measuring it? 3. What approach might guide our enablement? 4. Where do we get started? 5. How do we measure, learn and course correct as we go along? SCHEDULE: 6:00 - 6:30: Networking, snacks 6:30 - 7:45: Presentation 7:45 - 8:30: Optional Networking In ground floor business lobby ABOUT YOUR SPEAKER: RAVI VERMA Ravi is the founder and Org Whisperer at SmoothApps and a Scrum.org Professional Scrum Trainer. He has 21+ year of Software Delivery and consulting Experience with 10+ years of experience in Agile Enablement for companies ranging from 10 people to 10,000 people. Ravi is the creator of the Sabotagile Manifesto and Principles, co-creator of the Software Code of Ethics, and co-creator of the Scrum.org Scrum Pulse Webcast and Scrum Tapas video series. He has a long and glorious track record of making cringe-worthy mistakes and doesn't seem to be showing any signs of slowing down in with advancing age. Sometimes he learns and course corrects, sometimes he doesn't.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
