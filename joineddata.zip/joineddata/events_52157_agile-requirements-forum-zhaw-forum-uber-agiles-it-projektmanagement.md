---
source_url: https://www.scrum.org/events/52157/agile-requirements-forum-zhaw-forum-uber-agiles-it-projektmanagement
date_scraped: 2025-06-29T05:43:48.101243
---

[ Skip to main content ](https://www.scrum.org/events/52157/agile-requirements-forum-zhaw-forum-uber-agiles-it-projektmanagement#main-content)
#  Agile Requirements Forum (ZHAW Forum über Agiles IT-Projektmanagement)
Anlässliches des Abschlusses das CAS Agiles IT-Projektmanagement der ZHAW in Winterthur möchten wir dich zum ZHAW Forum einladen. 
Das ZHAW Forum reflektiert das im CAS Erlernte und bietet einen Ausblick, wie Agiles IT-Projektmanagement angewendet werden kann.
Experten der Praxis berichten von ihren Geschichten und Erfahrungen. 
Eingeladen sind alle aktuellen und ehemaligen Absolventen des CAS Agiles IT-Projektmanagement sowie CAS Agile Requirements Engineering - überdies Freunde, Familien und Kollegen.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
