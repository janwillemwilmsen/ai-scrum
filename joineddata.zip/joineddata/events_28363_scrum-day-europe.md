---
source_url: https://www.scrum.org/events/28363/scrum-day-europe
date_scraped: 2025-06-29T05:18:41.421111
---

[ Skip to main content ](https://www.scrum.org/events/28363/scrum-day-europe#main-content)
#  Scrum Day Europe
Netherlands
Scrum Day Europe is a great and lively journey for and by the Agile community and friends of Scrum. The event is a perfect place to be for change agents, Product Owners, and management. Take the opportunity to interact with presenters and like-minded peers who can share their experiences and lessons learned. atricia Kong, Dave West, Ryan Ripley, Jeff Gothelf, Magda Firlit, Chris Lukassen, Joshua Partogi and Matthijs De Booij will be speaking at the event!
[ visit event website ](https://scrumdayeurope.com/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
