---
source_url: https://www.scrum.org/events/17989/agile-leadership-series-agile-vitamins-boost-your-goals-vitamin-g
date_scraped: 2025-06-29T05:11:25.152365
---

[ Skip to main content ](https://www.scrum.org/events/17989/agile-leadership-series-agile-vitamins-boost-your-goals-vitamin-g#main-content)
#  Agile Leadership Series - Agile Vitamins: Boost Your Goals with Vitamin G
Is your team having a hard time focusing on priorities during a Sprint? Have your Sprint Goals gone from a tool to a task? Are you skipping your Sprint Goals all together? Take a dose of our Agile Vitamins to help get you back on track. Join us in our Vitamin G discussion as we…
  * Explore the ways Sprint Goals can benefit your team
  * Absorb the maximum value from Sprint Goals 


You will learn how effective Sprint Goals are critical to the health of your Sprint, as well as walk away being able to diagnose ineffective Sprint Goals and prescribe practices to create quality Sprint Goals.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
