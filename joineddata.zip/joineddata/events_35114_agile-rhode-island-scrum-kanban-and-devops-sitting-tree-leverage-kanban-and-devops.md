---
source_url: https://www.scrum.org/events/35114/agile-rhode-island-scrum-kanban-and-devops-sitting-tree-leverage-kanban-and-devops
date_scraped: 2025-06-29T05:32:05.458587
---

[ Skip to main content ](https://www.scrum.org/events/35114/agile-rhode-island-scrum-kanban-and-devops-sitting-tree-leverage-kanban-and-devops#main-content)
#  Agile Rhode Island - Scrum, Kanban, and DevOps Sitting in a Tree: Leverage Kanban and DevOps to improve Scrum
United States
Should you use Scrum, Kanban, or DevOps? You don’t have to choose: Scrum teams improve when they look at flows inside and outside their Sprints from a Lean/Kanban perspective. In this session we will talk about Kanban-related myths prevalent in the Scrum world and identify common ground between them. We will look at ways to bring Kanban flow into your Scrum: the Kanban-based Sprint/Product Backlog, flow-based daily Scrum, visualizing aging work, and flow-based Sprint Planning .We will describe ways to wrap Scrum with a Kanban flow system, and at the higher-level picture of a DevOps culture and process.
You’ll leave with a better understanding of how Scrum, Kanban, and DevOps relate to each other and with ideas for experiments to try when back at work.
**Speakers:**
Dave West is the Product Owner and CEO at Scrum.org. He is a frequent keynote speaker and is a widely published author of articles. He also is the co-author of two books, The Nexus Framework for Scaling Scrum and Head First Object-Oriented Analysis and Design. He led the development of the Rational Unified Process (RUP) and then worked with Ivar Jacobson running the North American business for IJI. Then managed the software delivery practice at Forrester research where he was VP and research director. Prior to joining Scrum.org he was Chief Product Officer at Tasktop where he was responsible for product management, engineering and architecture.
Yuval Yeret is the head of AgileSparks in the United States. He leads enterprise-level Agile implementations, and is the steward of The AgileSparks Way and the firm's SAFe, Flow/Kanban, and Agile Marketing Yuval is a SAFe Program Consultant Trainer (SPCT4), a Professional Scrum.org Trainer (PST), an internationally recognized Kanban Trainer, a thought leader, recipient of the Lean/Kanban Brickell Key Award, and a frequent speaker at industry conferences.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
