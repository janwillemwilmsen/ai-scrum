---
source_url: https://www.scrum.org/events/18389/scotsoft
date_scraped: 2025-06-29T05:11:57.598680
---

[ Skip to main content ](https://www.scrum.org/events/18389/scotsoft#main-content)
#  ScotSoft
United Kingdom
ScotSoft is the leading tech conference in Scotland. It’s an annual festival of ideas and innovation that showcases the best of the Scottish technology sector and brings you sought after speakers from far flung locations. 
Running for more than 20 years the event includes a full day Developer Conference, a half day Forum and a chance to meet the next generation of talent at the Young Software Engineer of the Year Awards Dinner in the evening. 
[ visit event website ](https://scotsoft.scot/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
