---
source_url: https://www.scrum.org/events/7896/agile-lean-summit
date_scraped: 2025-06-29T04:58:42.925074
---

[ Skip to main content ](https://www.scrum.org/events/7896/agile-lean-summit#main-content)
#  Agile Lean Summit
United States
This summit will bring together industry leaders from around North America to close the gap between Agile and traditional project management. The summit will provide challenging technology sessions that will cause Traditional project managers and executives in attendance to pause and consider Agile and cause Agile leaders to understand and build the bridge to the Traditional approaches. Three tracks will be held in addition to keynotes and a panel discussion addressing agile teams, projects, organizational transformations, and portfolio and enterprise agile.
[Dave West](https://www.scrum.org/user/252) keynotes with his talk about "[Managing Software Delivery in the Super Nova - A Story of Practical Agile Scaling](http://agilesummit.harrisburgu.edu/sessions/keynote-speaker/)." This talk addresses how Scrum is being used at scale and how organizations are managing the friction between the needs of Agile and the traditional needs of the organization.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
