---
source_url: https://www.scrum.org/events/30568/spark-change-toronto
date_scraped: 2025-06-29T05:22:56.090173
---

[ Skip to main content ](https://www.scrum.org/events/30568/spark-change-toronto#main-content)
#  Spark The Change Toronto
Canada
**2 days, 13 speakers, AMAZING coffee and food and no more than 100 people to keep things nice and intimate**. Oh, and we’re at the coolest venue on earth, the Ontario Science Centre! This is the 5th annual Spark the Change Toronto, an experience dedicated to helping you build a resilient organization.
This year’s theme is Nudging Change Forward. Professional Scrum Trainer [Dave Dame](https://www.scrum.org/david-dame) will be presenting at the event - Amplify Yourself and Those Around You. 
[ visit event website ](http://sparkthechange.ca/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
