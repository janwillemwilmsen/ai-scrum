---
source_url: https://www.scrum.org/events/17552/scrum-deutschland-2018
date_scraped: 2025-06-29T05:10:10.990603
---

[ Skip to main content ](https://www.scrum.org/events/17552/scrum-deutschland-2018#main-content)
#  Scrum Deutschland 2018
Germany
Scrum Deutschland ist auch in diesem Jahr wieder zurück und führt die Erfolgsgeschichte weiter fort! Eine neue Location, größere Vortragsslots, Top-Speaker aus aller Welt und ein Motto, das den Zeitgeist trifft – Scrum Deutschland erreicht dieses Jahr eine neue Stufe, von der Sie noch mehr profitieren! 
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
