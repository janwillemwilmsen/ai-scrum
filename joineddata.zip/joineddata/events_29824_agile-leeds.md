---
source_url: https://www.scrum.org/events/29824/agile-leeds
date_scraped: 2025-06-29T05:20:53.534992
---

[ Skip to main content ](https://www.scrum.org/events/29824/agile-leeds#main-content)
#  Agile in Leeds
United Kingdom
The June 18 meeting of the Agile in Leeds meetup will focus on Product Ownership and feature Professional Scrum Trainer Steve Trapps. 
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
