---
source_url: https://www.scrum.org/events/34418/agile-tour-lausanne
date_scraped: 2025-06-29T05:30:15.817297
---

[ Skip to main content ](https://www.scrum.org/events/34418/agile-tour-lausanne#main-content)
#  Agile Tour Lausanne
Switzerland
The Agile Tour is a series of Agility Conferences that take place every year across 93 cities in 35 countries, making it the world's largest event in Agility. This year will mark the 7th edition of the event in Lausanne. Professional Scrum Trainer [Nedjma Saidani](https://www.scrum.org/nedjma-saidani) will be speaking at the event. 
[ visit event website ](https://www.agilesuisse.ch/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
