---
source_url: https://www.scrum.org/events/72591/scrum-day-germany
date_scraped: 2025-06-29T05:52:15.896726
---

[ Skip to main content ](https://www.scrum.org/events/72591/scrum-day-germany#main-content)
#  Scrum Day Germany
Germany
Since 2007, Scrum Day has brought people together around one idea: using Scrum to make an impact.
The theme for the 16th Scrum Day is "Great Products - Great Systems, sustainable". 
You can expect innovation and inspiration, outstanding keynote speakers and, as always, the opportunity to meet lots of interesting people.
We want to keep it that way in 2023.[Filderstadt near Stuttgart](https://www.scrum-day.de/veranstaltungsort.html)
Speakers include PSTs - Simon Flossmann, Glenn Lamming, Boris Steiner, Stefan Mieth, Evelien Roos, Marc Kaufmann and Peter Goetz.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
