---
source_url: https://www.scrum.org/events/30885/scrum-day-vietnam
date_scraped: 2025-06-29T05:23:39.020035
---

[ Skip to main content ](https://www.scrum.org/events/30885/scrum-day-vietnam#main-content)
#  Scrum Day Vietnam
Vietnam
Scrum Day Vietnam is a great and exclusive occasion contributed by and for the Vietnam Scrum/ Agile community and friends. The event is a perfect place to be for people who are interested in Scrum/ Agile. This is a good opportunity to meet and interact with presenters as Professional Scrum Trainers and like-minded peers who can share their experiences and lessons learned. The Professional Scrum Trainers speaking at the event include Khoa Doan Tien, Shirley Santiago, Lorenz Cheung and Chee Hong Hsia.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
