---
source_url: https://www.scrum.org/events/41526/agile-coach-conference-2020
date_scraped: 2025-06-29T05:35:38.631198
---

[ Skip to main content ](https://www.scrum.org/events/41526/agile-coach-conference-2020#main-content)
#  Agile Coach Conference 2020
The role of ‘Agile Coach’ grows more popular as organizations grow their Agile ambitions. A blend of internal consultants, personal coaches, and team-level fire-fighters, we are a diverse population, facing different challenges at the team, program, and enterprise levels. Supporting the advance of Agility and quality of teamwork, Gladwell Academy’s Agile Coach Trainer Renate Cremer hosts a virtual Conference for knowledge exchange at Agile Coach Conference on October 28, 2020. Dave West and Leslie Morse from Scrum.org will be speaking at the event.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
