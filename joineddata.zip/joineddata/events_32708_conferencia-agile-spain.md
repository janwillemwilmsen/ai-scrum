---
source_url: https://www.scrum.org/events/32708/conferencia-agile-spain
date_scraped: 2025-06-29T05:28:32.299000
---

[ Skip to main content ](https://www.scrum.org/events/32708/conferencia-agile-spain#main-content)
#  Conferencia Agile Spain
Spain
La CAS es la conferencia de referencia sobre metodologías  _agile_ en España, que este año va a celebrarse en Barcelona a finales de noviembre. Hellen Keller dijo “Alone, we can do so little; together, we can do so much”. Desde la organización para la CAS2019, queremos quedarnos con la parte más positiva y potenciar esta idea: “**Together, we can do so much** ”, porque la comunidad Agile Spain, unida, puede aportar muchísimo valor a su entorno.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
