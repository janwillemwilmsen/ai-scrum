---
source_url: https://www.scrum.org/events/47203/pm-summit
date_scraped: 2025-06-29T05:40:06.798142
---

[ Skip to main content ](https://www.scrum.org/events/47203/pm-summit#main-content)
#  PM Summit
PM Summit is designed to onboard PMs in the region to a platform & community where they will find the needed resources to accelerate their career development. Dave West will be delivering a keynote at the event!
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
