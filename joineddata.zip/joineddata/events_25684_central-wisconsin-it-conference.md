---
source_url: https://www.scrum.org/events/25684/central-wisconsin-it-conference
date_scraped: 2025-06-29T05:12:54.516861
---

[ Skip to main content ](https://www.scrum.org/events/25684/central-wisconsin-it-conference#main-content)
#  Central Wisconsin IT Conference
The Central Wisconsin IT Conference is a one-day conference designed to bring together IT professionals from the Midwest, from entry-level technologists to senior level managers to explore new ideas, share knowledge, and build community. Professional Scrum Trainer Chad Beier will be speaking at this event. 
[ visit event website ](https://www.cwitc.org/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
