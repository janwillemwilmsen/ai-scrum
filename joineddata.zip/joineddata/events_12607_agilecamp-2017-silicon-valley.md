---
source_url: https://www.scrum.org/events/12607/agilecamp-2017-silicon-valley
date_scraped: 2025-06-29T05:03:31.734359
---

[ Skip to main content ](https://www.scrum.org/events/12607/agilecamp-2017-silicon-valley#main-content)
#  AgileCamp 2017 Silicon Valley
United States
Hear Scrum.org VP of Enterprise Solutions, Kurt Bittner speak on November 6th, 2017 for AgileCamp Silicon Valley in the heart of technology innovation! Agilists from across the West Coast will converge for a career changing day. Join hundreds of professionals in igniting a path of an Agile enterprise. This year we are excited for keynote presentations from [Barry O’Reilly](http://agilecamp.org/), best-selling author of Lean Enterprise, and [Doug Kirkpatrick](http://agilecamp.org/), TEDx speaker and author of Beyond Empowerment: The Age of the Self-Managed Organization. You’ll also choose from 20 of workshops on Leadership, Product, Leadership, Innovation, Agility and much more.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
