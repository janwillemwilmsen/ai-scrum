---
source_url: https://www.scrum.org/events/75552/agile-tour-vilnius
date_scraped: 2025-06-29T05:53:10.605507
---

[ Skip to main content ](https://www.scrum.org/events/75552/agile-tour-vilnius#main-content)
#  Agile Tour Vilnius
Lithuania
For the 14th time, the Agile Lithuania Association is organizing the internationally recognized Agile Tour Vilnius, the largest conference in the Baltic States, highly valued by Agile professionals. This year, we will invite participants to listen to inspiring Agile professionals who not only work but also live according to Agile principles. Speakers will share their practical experience at the conference! 
PST [Evelien Roos](https://www.scrum.org/evelien-roos) is speaking at the event about the 5P's of Personal Engagements.
[ Visit Event Website ](https://2023.agileturas.lt/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
