---
source_url: https://www.scrum.org/events/32306/hands-agile-meetup-liberating-structures-scrum-sprint-review
date_scraped: 2025-06-29T05:26:54.511612
---

[ Skip to main content ](https://www.scrum.org/events/32306/hands-agile-meetup-liberating-structures-scrum-sprint-review#main-content)
#  Hands-On Agile Meetup - Liberating Structures for Scrum: The Sprint Review
Germany
The 16th Hands-on Agile meetup continues exploring Liberating Structures for Scrum events. This time, we address the Sprint Review. Liberating Structures cover a set of easy to learn, yet powerful ways to collaborate as a team—even as a large team—, overcoming traditional communications approaches like presentations, managed discussions, or another disorganized brainstorming at which the loudest participants tend to prevail. Throughout the coming months, we will create exciting new ways how to improve classic Scrum events like the Daily Scrum, the Sprint Review, ​or the Sprint Retrospective. Moreover, we will use Liberating Structures for difficult challenges that agile coaches, Scrum Masters, and Product Owners face, for example, reviewing the existing product design process.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
