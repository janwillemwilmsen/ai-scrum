---
source_url: https://www.scrum.org/events/16875/agile-leadership-day
date_scraped: 2025-06-29T05:09:26.846893
---

[ Skip to main content ](https://www.scrum.org/events/16875/agile-leadership-day#main-content)
#  Agile Leadership Day
Switzerland
People with a leadership role in modern companies come together to share experiences and exchange information. Join us if you have a modern understanding of leadership and management and want to bring more agility and flexibility into your organization. Patricia Kong will be speaking at this event.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
