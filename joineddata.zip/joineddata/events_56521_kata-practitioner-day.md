---
source_url: https://www.scrum.org/events/56521/kata-practitioner-day
date_scraped: 2025-06-29T05:45:26.031936
---

[ Skip to main content ](https://www.scrum.org/events/56521/kata-practitioner-day#main-content)
#  Kata Practitioner Day
Join this one of a kind Kata Practitioner Day where Kata and Agile communities are brought together to learn and build synergies. Professional Scrum Trainer [Joe Krebs](https://www.scrum.org/joe-krebs) will be speaking at the event. 
[ visit event website ](http://katapractitionerday.com)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
