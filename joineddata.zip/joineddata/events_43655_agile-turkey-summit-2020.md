---
source_url: https://www.scrum.org/events/43655/agile-turkey-summit-2020
date_scraped: 2025-06-29T05:38:10.270429
---

[ Skip to main content ](https://www.scrum.org/events/43655/agile-turkey-summit-2020#main-content)
#  Agile Turkey Summit 2020
Agile Turkey is a not-for-profit organization founded in 2008 with the purpose of increasing the adoption of Agile methods that have been proven effective around the world in Turkey. Since then, it’s been gaining attraction by organizing free public events and widely-accepted seminars, meetups and conferences.
Since 2013, Agile Turkey has been bringing Agile leaders and practitioners from leading companies around the world together to the biggest Agile event of the year for Turkey and for the region: Agile Turkey Summit. In 2020, the event will be organized for the 8th time in a row and it will be on November 20th - 21th, 2020.
In 2019, the Summit had huge interest of delegates frlom 20+ countries around the world (especially from Europe). The event hosted 1100+ attendees from 150+ companies including the world's leading companies.
Agile Turkey Summit 2020 is a two day, international online event gathering Agile enthusiasts together. We would like you to take part in the 8th Agile Turkey Summit to discuss the hot topics in Agile world.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
