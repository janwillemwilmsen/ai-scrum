---
source_url: https://www.scrum.org/events/36496/agile-india-2020
date_scraped: 2025-06-29T05:33:10.936222
---

[ Skip to main content ](https://www.scrum.org/events/36496/agile-india-2020#main-content)
#  Agile India 2020
India
Scrum.org is sponsoring Agile India, Asia's largest conference on leading edge software development methods. The conference runs from October 11-18.There is a 10% discount available if you register using the discount code: **Scrum.org.** Visit the event website for more details. 
Patricia Kong will be presenting - The Future of Work: What does success look like for an agile organization? How do we measure it? at the event.
[ visit event website ](https://2020.agileindia.org/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
