---
source_url: https://www.scrum.org/events/64021/scrum-day-usa-wisconsin
date_scraped: 2025-06-29T05:50:22.859098
---

[ Skip to main content ](https://www.scrum.org/events/64021/scrum-day-usa-wisconsin#main-content)
#  Scrum Day USA - Wisconsin
United States
Get ready for Scrum Day USA, featuring thoughtful discussions and short, interactive training on the Scrum framework. Whether you're a Product Owner, Developer, Scrum Master, or leader supporting a Scrum Team, attending Scrum Day will give you the insights and practical tools you need to level up your practice. Several Professional Scrum Trainers will be speaking and Dave West will deliver a Keynote.
[ Visit Event Website ](https://www.scrumday.org/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
