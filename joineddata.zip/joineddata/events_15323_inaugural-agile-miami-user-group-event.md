---
source_url: https://www.scrum.org/events/15323/inaugural-agile-miami-user-group-event
date_scraped: 2025-06-29T05:06:25.374588
---

[ Skip to main content ](https://www.scrum.org/events/15323/inaugural-agile-miami-user-group-event#main-content)
#  Inaugural Agile Miami User Group Event
The Inaugural Agile Miami User Group MeetUp, hosted by Professional Scrum Trainer, [Jochen Krebs](https://www.scrum.org/joe-krebs), will feature networking and a speaking session featuring Andres Borque, agile transformation lead at Florida Power and Light.
What we'll do We will hear from Andres Borque, agile transformation lead at Florida Power and Light. ------- 6.00pm Drinks and Snacks, Mingle 6.30pm Andres 7.15pm Mingle ------- • What to bring just a good and friendly mood. We are releasing more information, pictures on [http://www.agilemiami.org](http://www.agilemiami.org/ "http://www.agilemiami.org")
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
