---
source_url: https://www.scrum.org/events/27394/star-east
date_scraped: 2025-06-29T05:16:09.713253
---

[ Skip to main content ](https://www.scrum.org/events/27394/star-east#main-content)
#  STAR East
STAR _EAST_ —one of the longest-running and most respected conferences on software testing and quality assurance. The event week features over 100 learning and networking opportunities and covers a wide variety of some of the most in-demand topics and testing innovations.
[ visit event website ](https://well.tc/iisa)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
