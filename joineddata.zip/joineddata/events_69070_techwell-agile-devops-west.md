---
source_url: https://www.scrum.org/events/69070/techwell-agile-devops-west
date_scraped: 2025-06-29T05:51:14.423995
---

[ Skip to main content ](https://www.scrum.org/events/69070/techwell-agile-devops-west#main-content)
#  Techwell Agile DevOps West
United States
Agile + DevOps West brings together practitioners seeking to accelerate the delivery of reliable, secure software applications. Find out how the practice of agile & DevOps brings cross-functional stakeholders together to deliver software with greater speed and agility while meeting quality and security demands.
Eveliens Roos will be[ speaking at this event](https://agiledevopswest.techwell.com/program/using-neuroscience-boost-your-scrum-events-agile-devops-west-2023). 
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
