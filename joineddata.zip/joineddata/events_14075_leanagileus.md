---
source_url: https://www.scrum.org/events/14075/leanagileus
date_scraped: 2025-06-29T05:04:33.355664
---

[ Skip to main content ](https://www.scrum.org/events/14075/leanagileus#main-content)
#  LeanAgileUS
United States
Hear Scrum.org Professional Scrum Trainers: Steve Porter, Yuval Yeret and Evelien Roos as they discuss how Scrum helps lean organizations and much more.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
