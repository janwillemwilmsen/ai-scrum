---
source_url: https://www.scrum.org/events/15377/scrum-day-india
date_scraped: 2025-06-29T05:06:36.498256
---

[ Skip to main content ](https://www.scrum.org/events/15377/scrum-day-india#main-content)
#  Scrum Day India
India
Scrum has become the de-facto working standard for professionals and it is not limited to just IT Software. Professionals are using it as a way of living.
Come and join us for the Scrum Day – Delhi NCR event on Friday, 20th April 2018. The event offers an opportunity to join and learn from the practitioners, like-minded peers and leaders who are living the new ways of working and will be sharing their experience and learning. Its a One day event which will support, inspire, guide and help you in achieving the skills and knowledge needed for the new ways of working.
[ Visit Event Website ](https://scrumdayindia.org/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
