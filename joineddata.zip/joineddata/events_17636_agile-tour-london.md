---
source_url: https://www.scrum.org/events/17636/agile-tour-london
date_scraped: 2025-06-29T05:11:04.127462
---

[ Skip to main content ](https://www.scrum.org/events/17636/agile-tour-london#main-content)
#  Agile Tour London
United Kingdom
Agile Tour London is a conference about Agile in its general approach, where agilists of all background can meet to exchange ideas, refresh their minds, evaluate issues and renew their own approach to Execute Everyday Agile. Professional Scrum Traner Wim Heemskerk will be presenting at the event. 
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
