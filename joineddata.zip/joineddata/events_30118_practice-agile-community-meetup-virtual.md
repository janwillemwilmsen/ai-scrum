---
source_url: https://www.scrum.org/events/30118/practice-agile-community-meetup-virtual
date_scraped: 2025-06-29T05:21:46.487313
---

[ Skip to main content ](https://www.scrum.org/events/30118/practice-agile-community-meetup-virtual#main-content)
#  Practice Agile Community Meetup (Virtual)
This meeting of the Practice Agile Community Meetup will be Virtual and will feature a presentation on Distributed Agile Teams.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
