---
source_url: https://www.scrum.org/events/57762/scrum-day-germany-2022
date_scraped: 2025-06-29T05:46:26.330797
---

[ Skip to main content ](https://www.scrum.org/events/57762/scrum-day-germany-2022#main-content)
#  Scrum Day Germany 2022
Germany
Scrum Day has been gathering people since 2007 around one idea: using Scrum to make an impact. Better products, faster delivery, happier customers, happier people and businesses. This year, PSTs [Evelien Roos](https://www.scrum.org/evelien-roos), [Uta Kapp](https://www.scrum.org/uta-kapp), [Ralph Jocham](https://www.scrum.org/ralph-jocham), [Dominik Maximini](https://www.scrum.org/dominik-maximini), [Marc Kaufmann](https://www.scrum.org/marc-kaufmann), [Peter Götz](https://www.scrum.org/peter-goetz), [Oliver Hankeln](https://www.scrum.org/oliver-hankeln), [Andrii Glushchenko](https://www.scrum.org/Andrii-Glushchenko), [Glenn Lamming](https://www.scrum.org/glenn-lamming), [Boris Steiner](https://www.scrum.org/boris.steiner), [Stefan Mieth](https://www.scrum.org/stefan-mieth), [Simon Flossmann](https://www.scrum.org/simon-flossmann) and [Jean Pierre Berchez](https://www.scrum.org/jean-pierre-berchez) will be speaking at this event.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
