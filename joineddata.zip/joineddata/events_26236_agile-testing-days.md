---
source_url: https://www.scrum.org/events/26236/agile-testing-days
date_scraped: 2025-06-29T05:14:28.942295
---

[ Skip to main content ](https://www.scrum.org/events/26236/agile-testing-days#main-content)
#  Agile Testing Days
Germany
The Agile Testing Days is the conference to attend, where agile testing professionals, like-minded people from the agile software development, and internationally recognized speakers will gather to collaborate and grow. Professional Scrum Trainer WIm Heemskerk will be speaking at this event.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
