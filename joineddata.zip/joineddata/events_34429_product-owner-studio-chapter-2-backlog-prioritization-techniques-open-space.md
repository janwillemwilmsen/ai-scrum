---
source_url: https://www.scrum.org/events/34429/product-owner-studio-chapter-2-backlog-prioritization-techniques-open-space
date_scraped: 2025-06-29T05:31:10.916079
---

[ Skip to main content ](https://www.scrum.org/events/34429/product-owner-studio-chapter-2-backlog-prioritization-techniques-open-space#main-content)
#  Product Owner Studio Chapter 2 - Backlog Prioritization Techniques + Open Space
India
We will explore the Prioritisation Techniques to help manage the Product Backlog followed by an Open Space to discuss the state of Product Owner role in today's organisations. This is hosted by Professional Scrum Trainer Venkatesh Rajamani.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
