---
source_url: https://www.scrum.org/events/26774/projectcon-indianapolis
date_scraped: 2025-06-29T05:15:06.501512
---

[ Skip to main content ](https://www.scrum.org/events/26774/projectcon-indianapolis#main-content)
#  ProjectCon Indianapolis
A multi-day EPIC educational conference offering multiple Keynotes, over 40 breakout sessions, expert panel discussions, OpenSpace, Agile Coaches Corner, Career
Development Clinics, vendor expo, networking, and deep dive 1/2 to full day workshops centered around the theme **AGILITY. INNOVATION. TRANSFORMATION.**
[ visit event website ](https://projectconevent.com/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
