---
source_url: https://www.scrum.org/events/36203/simplicity-day-2020
date_scraped: 2025-06-29T05:32:48.173305
---

[ Skip to main content ](https://www.scrum.org/events/36203/simplicity-day-2020#main-content)
#  Simplicity Day 2020
Ukraine
The concept of the “Simplicity day” conference series was born as an answer to the community request, which strives to learn in a straightforward, “simple” way about complex concepts, principles, approaches and tools. Professional Scrum Trainer [Roland Flemm](https://www.scrum.org/roland-flemm) will be keynoting this event with a talk titled - Your Scrum Failed - Now What?.
[ visit event website ](https://smplday.com/en)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
