---
source_url: https://www.scrum.org/events/16215/agile-cymru
date_scraped: 2025-06-29T05:08:35.954343
---

[ Skip to main content ](https://www.scrum.org/events/16215/agile-cymru#main-content)
#  Agile Cymru
United Kingdom
Agile Cymru is back! We have a great new venue at Newport City Campus and we’re still on a mission to empower and support the agile community in Wales. Previous years have included talks from comedians, policemen that employed wizards, to psychology professionals. An eclectic mix you might say! This year we hope to maintain that same originality and inspirational concepts for looking at agility.
Professional Scrum Trainer John Coleman will be presenting. 
[ visit event website ](http://www.agile.cymru/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
