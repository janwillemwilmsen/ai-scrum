---
source_url: https://www.scrum.org/events/27335/agile-munich-2019
date_scraped: 2025-06-29T05:15:48.794980
---

[ Skip to main content ](https://www.scrum.org/events/27335/agile-munich-2019#main-content)
#  Agile Munich 2019
Germany
Agility at Scale is about your company's ability to adapt in today's fast changing economy. The challenge is of course, that your company exists of many different functions, like Sales, Marketing, IT, who are all on a different level of Agile maturity. And this means that your company's Agility is only as effective as its weakest function! It is therefore to no surprise, that true Agile companies develop Agility across all of its functions. And preferably in alignment. Let's explore together Agility throughout the company and learn from one another. Let's explore Agility at Scale. For this event, speakers and companies are invited who have truly raised the Agility bar in functions like IT, HR, Finance, Sales & Marketing and Management. We also look strategically; how do we prepare our next generation to flourish in the Agile company. Arrive the evening before and join on May 08 the warm-up evening with Niels Pflaeging or extend your trip with Friday on May 10 and join one of the Master Classes. The conference itself is jam-packed with a Keynotes by Eelco Rustenburg and Jeff Gothelf (Author of Lean UX and Sense & Respond) and speakers from companies like Bose, Zalando and many more. They offer a visionary track and a company track, an optional short Open Space and plenty of opportunities to meet likeminded agile experts. Gamification and lightning talks are included as well. 
[ visit event website ](https://www.agilemunich.com/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
