---
source_url: https://www.scrum.org/events/5277/devops-pro-vilnius
date_scraped: 2025-06-29T04:57:38.039771
---

[ Skip to main content ](https://www.scrum.org/events/5277/devops-pro-vilnius#main-content)
#  DevOps Pro Vilnius
Lithuania
Join Professional Scrum Trainer, [Martin Hinshelwood](https://www.scrum.org/user/184) as he presents at this DevOps event. DevOps Pro Vilnius conference covers the core principles and concepts of the DevOps methodology and demonstrates how to use the most common DevOps patterns to develop, deploy and maintain applications on-premises and in the cloud. DevOps Pro Conference puts the spotlight on entire software delivery pipeline.
[ Visit Event Website ](http://devopspro.lt/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
