---
source_url: https://www.scrum.org/events/55386/agile-leadership-india
date_scraped: 2025-06-29T05:45:00.573688
---

[ Skip to main content ](https://www.scrum.org/events/55386/agile-leadership-india#main-content)
#  Agile Leadership India
Agile ways of working help in increasing value delivery, customer satisfaction and employee happiness. Similarly, agile mind set changes the leader’s ability to increase self-awareness and brings a think differently attitude which is the first step towards a transforming leader.
This event is for all leaders who would like to share their Agile adoption challenges, experience and learning with the wider audience and for those who would like to learn from others. Patricia Kong is speaking at this event.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
