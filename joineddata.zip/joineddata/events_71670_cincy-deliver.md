---
source_url: https://www.scrum.org/events/71670/cincy-deliver
date_scraped: 2025-06-29T05:51:53.566427
---

[ Skip to main content ](https://www.scrum.org/events/71670/cincy-deliver#main-content)
#  Cincy Deliver
United States
Agile Conferences, Inc., and the Cincinnati .NET User Group (www.cinnug.org), both Ohio non-profit organizations, are pleased to announce its thirteenth conference!
The CincyDeliver conference (formerly the Cincinnati Day of Agile) is Cincinnati's largest and longest-running non-profit (and community-run) conference dedicated to software development teams. Since the founding of our conference in 2010, we have seen incredible speakers, attendees, and sponsors. 2022 saw our largest conference, with over 500 attendees, 40 speakers, 38 Sessions + 2 Keynotes, and 11 sponsors. Our selected sessions covered agile processes and scaling, development, quality, dev-ops, and soft skills. Hence the new name, CincyDeliver!
[ Visit Event Website ](https://www.cincydeliver.org/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
