---
source_url: https://www.scrum.org/events/33387/scrum-studio-16-ask-me-anything-about-scrum-mastery
date_scraped: 2025-06-29T05:29:17.844281
---

[ Skip to main content ](https://www.scrum.org/events/33387/scrum-studio-16-ask-me-anything-about-scrum-mastery#main-content)
#  Scrum Studio #16 - Ask me anything about Scrum Mastery
India
This meeting of the Scrum Studio meetup will feature a live Q&A session with Professional Scrum Trainer Venkatesh Rajamani.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
