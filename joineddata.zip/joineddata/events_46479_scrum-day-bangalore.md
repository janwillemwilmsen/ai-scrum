---
source_url: https://www.scrum.org/events/46479/scrum-day-bangalore
date_scraped: 2025-06-29T05:39:49.503904
---

[ Skip to main content ](https://www.scrum.org/events/46479/scrum-day-bangalore#main-content)
#  Scrum Day Bangalore
Bengaluru or Bangalore is the IT Capital and Silicon Valley of India. Scrum is the most popular Agile Framework. Xebia is the leading Agile Consulting and Training firm. When these three come together – Its festival of knowledge and networking. Xebia proudly presents Scrum Day Bangalore 2021 – the festival of knowledge and networking. Its time for Agile Enthusiasts, Agile Practitioners all over the world to visit namma Bengaluru virtually to come together, share the knowledge and network. With an awesome, most pressing need of the hour theme “Metrics and Measurements – Mirrors of Enterprise Mental Models” discover, explore, deep dive into the madness behind metrics – the good, bad and ugly of number crunching. Patricia Kong and PSTs Gunther Verheyen, Nagesh Sharma, Chris Lukassen and Stefan Wolpers will be speaking.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
