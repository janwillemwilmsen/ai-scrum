---
source_url: https://www.scrum.org/events/16414/agile-methods
date_scraped: 2025-06-29T05:08:52.785578
---

[ Skip to main content ](https://www.scrum.org/events/16414/agile-methods#main-content)
#  Agile Methods
United Kingdom
The event originates from the idea that learning about Agile methods is important; BUT understanding HOW they apply to your specific context is critical.
The programme favours case studies over theory-focused presentations and aims to connect subject experts with the audience via round table discussions, Q&A sessions and networking.
This conference looks at issues specifically relevant to Agile and the entrepreneurship. There will be mix of agile stories and subject experts from different backgrounds will promote the values and principles for software development and disciplined processes for project management. This coupled with networking has the scope for open-mindedness and sharing throughout the day.
There is also an exhibition alongside featuring leading service providers, consultants and vendors.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
