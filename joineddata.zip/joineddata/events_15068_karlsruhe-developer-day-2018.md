---
source_url: https://www.scrum.org/events/15068/karlsruhe-developer-day-2018
date_scraped: 2025-06-29T05:05:55.109678
---

[ Skip to main content ](https://www.scrum.org/events/15068/karlsruhe-developer-day-2018#main-content)
#  Karlsruhe Developer Day 2018
Germany
**IHK Karlsruhe** Lammstraße 13 - 17 76133 Karlsruhe
The Software Engineering Conference - Community - Conversations - Cookies
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
