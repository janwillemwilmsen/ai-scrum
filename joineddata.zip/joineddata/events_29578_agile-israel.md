---
source_url: https://www.scrum.org/events/29578/agile-israel
date_scraped: 2025-06-29T05:20:36.579469
---

[ Skip to main content ](https://www.scrum.org/events/29578/agile-israel#main-content)
#  Agile Israel
Agile Israel 2019 is the central Agile event in Israel running for the 12th consecutive year, bringing world class agile experts and inspiring case studies to help you learn tips and tricks that can be applied in your organization. Professional Scrum Trainer [Oded Tamir](https://www.scrum.org/oded-tamir) and Kurt Bittner will be speaking at this event. 
[ visit event website ](https://www.agileisrael.co/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
