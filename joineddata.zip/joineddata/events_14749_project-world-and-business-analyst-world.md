---
source_url: https://www.scrum.org/events/14749/project-world-and-business-analyst-world
date_scraped: 2025-06-29T05:04:48.707246
---

[ Skip to main content ](https://www.scrum.org/events/14749/project-world-and-business-analyst-world#main-content)
#  Project World and Business Analyst World
Canada
ProjectWorld*BAWorld Toronto is largest educational conference for Project Professionals. 2017 was a banner year, attracting over 1000 delegates from across Toronto and the GTA. Eric Naiburg will be presenting: What is Scrum? An Introduction to the Scrum Framework on June 4 and 5. 
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
