---
source_url: https://www.scrum.org/events/48561/agile-israel-2021
date_scraped: 2025-06-29T05:41:19.783462
---

[ Skip to main content ](https://www.scrum.org/events/48561/agile-israel-2021#main-content)
#  Agile Israel 2021
This year’s theme is “Resilience”, to emphasize how Agile and DevOps enables organizations to respond fast to the waves of change.
Agile Israel 2021 is the central Agile event in Israel, running for the 14th consecutive year, bringing world-class Agile experts and inspiring case studies to help you learn tips and tricks that can be applied in your organization. PST Oded Tamir will be speaking at the event!
[ visit event website ](https://www.agileisrael.co/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
