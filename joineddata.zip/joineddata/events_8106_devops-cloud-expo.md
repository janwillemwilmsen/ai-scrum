---
source_url: https://www.scrum.org/events/8106/devops-cloud-expo
date_scraped: 2025-06-29T05:00:10.175325
---

[ Skip to main content ](https://www.scrum.org/events/8106/devops-cloud-expo#main-content)
#  DevOps at Cloud Expo
United States
Every Global 2000 enterprise in the world is now integrating cloud computing in some form into its IT development and operations. Midsize and small businesses are also migrating to the cloud in increasing numbers. 
Companies are each developing their unique mix of cloud technologies and services, forming multi-cloud and hybrid cloud architectures and deployments across all major industries. Cloud-driven thinking has become the norm in financial services, manufacturing, telco, healthcare, transportation, energy, media, entertainment, retail and other consumer industries, and the public sector. 
Cloud Expo is the single show where technology buyers and vendors can meet to experience and discus cloud computing and all that it entails. 
Kurt Bittner presents:[ Freeze the Pond Versus Take the Hill: Two Metaphors for Enterprise Agile Transformation](http://www.cloudcomputingexpo.com/event/session/3468)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
