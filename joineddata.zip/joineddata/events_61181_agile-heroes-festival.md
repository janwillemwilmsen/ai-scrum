---
source_url: https://www.scrum.org/events/61181/agile-heroes-festival
date_scraped: 2025-06-29T05:48:33.333949
---

[ Skip to main content ](https://www.scrum.org/events/61181/agile-heroes-festival#main-content)
#  Agile Heroes Festival
Über zwei Tage hinweg zeigen dir unsere Top-Speaker Schritt für Schritt, wie du eine agile Transformation meisterst. Dabei gehen sie konkret auf zwei Aspekte ein: den Start und die Skalierung.
Das alles erlebst du per Livestream von unserer professionellen Festival-Bühne aus! Zusätzlich wird es die Möglichkeit geben mit anderen Teilnehmenden sowie den Speakern selbst zu interagieren.
Zudem ist jeder Tag gespickt mit aufregenden Highlights wie zum Beispiel Coachings, Fitness-Sessions, Musik, einer Award-Verleihung und noch vielem mehr…
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
