---
source_url: https://www.scrum.org/events/32489/scrum-day-greater-philadelphia
date_scraped: 2025-06-29T05:27:59.215351
---

[ Skip to main content ](https://www.scrum.org/events/32489/scrum-day-greater-philadelphia#main-content)
#  Scrum Day - Greater Philadelphia
Scrum Day is coming to Greater Philadelphia
  * Product Owners, Scrum Masters, and Agile practitioners are all invited to learn from and engage with certified Scrum Professionals and Trainers as they lead a full day of focused discussions on a variety of Scrum topics. The keynote will center on the Future of Work, and supporting sessions will tackle topics like Evidence-Based Management, Scrum with UX, Fixing Scrum, Scrum with Kanban, Agile Metrics, Effective Backlog Refinement, and the Psychology of Influence.
  * Scrum Day, hosted by Springhouse Education & Consulting Services, is a one-day conference for 100 Scrum practitioners in the Philadelphia and surrounding suburbs to learn more about the future of work from Scrum.org leaders and experienced Professional Scrum Trainers (PSTs).
  * Dave West will be keynoting the event.


By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
