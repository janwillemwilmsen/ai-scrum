---
source_url: https://www.scrum.org/events/46316/2021-agile-summit-spring-agile
date_scraped: 2025-06-29T05:39:43.884422
---

[ Skip to main content ](https://www.scrum.org/events/46316/2021-agile-summit-spring-agile#main-content)
#  2021 Agile Summit - Spring into Agile
We welcome you to join the University of New Hampshire Agile Summit, a virtual event to be held on Friday April 9, 2021 from 9 AM to 12 PM, where they consider the future of Agile with thought leaders from across the industry. Leslie Morse and Patricia Kong at Scrum.org will both be speaking at the event. Patricia will be on a panel discussing the Future of Work and Leslie will be moderating a session titled, Agile, Iterative Coordination and Innovation.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
