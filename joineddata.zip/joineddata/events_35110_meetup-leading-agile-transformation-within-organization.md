---
source_url: https://www.scrum.org/events/35110/meetup-leading-agile-transformation-within-organization
date_scraped: 2025-06-29T05:32:00.505043
---

[ Skip to main content ](https://www.scrum.org/events/35110/meetup-leading-agile-transformation-within-organization#main-content)
#  Meetup - Leading Agile Transformation within the Organization
Malaysia
The goal of organizational transformation is to structure organization so that it gets the most amount of benefits by transitioning to agile way of working. This meetup hosted by Professional Scrum Trainer Naveen Kumar Singh will focus on this topic.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
