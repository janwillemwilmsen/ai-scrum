---
source_url: https://www.scrum.org/events/4281/agile-devops-meetup-dfw-chapter
date_scraped: 2025-06-29T04:57:05.654332
---

[ Skip to main content ](https://www.scrum.org/events/4281/agile-devops-meetup-dfw-chapter#main-content)
#  Agile-DevOps Meetup: DFW Chapter
United States
This is a group of passionate Agile & DevOps Enthusiasts in the DFW area who are looking to share inspiring and pragmatic techniques to promote effective use of Agile Software Development & DevOps. We will meet monthly to hear an inspiring speaker and exchange best practices to make the journey of Agile Software Development / DevOps fulfilling and rewarding for our organizations.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
