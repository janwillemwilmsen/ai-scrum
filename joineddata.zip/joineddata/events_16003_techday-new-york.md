---
source_url: https://www.scrum.org/events/16003/techday-new-york
date_scraped: 2025-06-29T05:07:08.307638
---

[ Skip to main content ](https://www.scrum.org/events/16003/techday-new-york#main-content)
#  TechDay New York
TechDay brings together the entire tech community. Industry leaders, new startups, investors and tons of press. Scrum.org will be exhibiting at the event. Please stop by our booth and say hello! 
[ visit event website ](https://techdayhq.com/new-york)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
