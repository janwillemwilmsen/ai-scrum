---
source_url: https://www.scrum.org/events/18308/lean-agile-scotland
date_scraped: 2025-06-29T05:11:52.162793
---

[ Skip to main content ](https://www.scrum.org/events/18308/lean-agile-scotland#main-content)
#  Lean Agile Scotland
Lean Agile Scotland brings together some of the most engaging minds in the community, to share ideas and help generate new ones. Scrum.org will be sponsoring and exhibiting at this event.
[ visit event website ](http://leanagile.scot/2018/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
