---
source_url: https://www.scrum.org/events/18116/agile-central-pa-meetup
date_scraped: 2025-06-29T05:11:35.692812
---

[ Skip to main content ](https://www.scrum.org/events/18116/agile-central-pa-meetup#main-content)
#  Agile Central PA Meetup
**Using liberating structures to facilitate learning and problem solving workshops**
Are you ready to have some fun after work while learning ways to facilitate engaging workshops with people you work with? This presentation will demonstrate a number of liberating structures techniques by teaching several intermediate level scrum topics. Liberating Structures is a collection of group exercises that actively engage teams of people to collaboratively identify and solve problems. Liberating structures are used by a number of European organizations to teach highly interactive classes and conduct workshops for group problem solving. If you have to work with groups and get many minds actively involved in solving issues, you should come to this session. You’ll definitely get new facilitation ideas. Presentation by Professional Scrum Trainers Dr. Charles Suscheck and Todd Miller.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
