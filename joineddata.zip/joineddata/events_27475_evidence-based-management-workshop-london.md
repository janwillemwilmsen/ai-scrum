---
source_url: https://www.scrum.org/events/27475/evidence-based-management-workshop-london
date_scraped: 2025-06-29T05:16:56.680425
---

[ Skip to main content ](https://www.scrum.org/events/27475/evidence-based-management-workshop-london#main-content)
#  Evidence-Based Management Workshop - London
United Kingdom
This one day practical workshop will enable you to understand your organization and how to successfully influence wider adoption of agile ways of working. The workshop will be delivered by Patricia Kong, Product Owner, Enterprise Solutions, Scrum.org and Professional Scrum Trainer Simon Reindl, Advanced Product Delivery.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
