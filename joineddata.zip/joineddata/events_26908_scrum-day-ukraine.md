---
source_url: https://www.scrum.org/events/26908/scrum-day-ukraine
date_scraped: 2025-06-29T05:15:21.845694
---

[ Skip to main content ](https://www.scrum.org/events/26908/scrum-day-ukraine#main-content)
#  Scrum Day Ukraine
Ukraine
Scrum Day Ukraine is full of meetings and conversation with the brightest Agile professionals about self-organization, the future of Agile and much more! There are 6 tracks of presentations and speakers include Professional Scrum Trainers [Magdalena Firlit](https://www.scrum.org/user/217876), [Oded Tamir](https://www.scrum.org/oded-tamir), [Gunther Verheyen](https://www.scrum.org/gunther-verheyen), [Laurens Bonnema](https://www.scrum.org/user/217755), [John Coleman](https://www.scrum.org/john-coleman), [Mehmet Yitmen](https://www.scrum.org/user/98) and [Pawel Kmiotek](https://www.scrum.org/pawel-kmiotek).
[ visit event website ](https://scrumday.com.ua/en/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
