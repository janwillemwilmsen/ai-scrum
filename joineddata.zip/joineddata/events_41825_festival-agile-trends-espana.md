---
source_url: https://www.scrum.org/events/41825/festival-agile-trends-espana
date_scraped: 2025-06-29T05:35:49.835817
---

[ Skip to main content ](https://www.scrum.org/events/41825/festival-agile-trends-espana#main-content)
#  Festival Agile Trends España
Festival Agile Trends España is an online and free event with dozens of sessions presented by experienced agilists and professionals. All of them, like us, are contributing by sharing their time and knowledge to help the Spanish Agile Community when they need the most. Dave West will be speaking at the event presenting, "The Future of Agility as Scrum Turns 25".
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
