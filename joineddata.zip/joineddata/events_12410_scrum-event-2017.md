---
source_url: https://www.scrum.org/events/12410/scrum-event-2017
date_scraped: 2025-06-29T05:03:04.444432
---

[ Skip to main content ](https://www.scrum.org/events/12410/scrum-event-2017#main-content)
#  Scrum Event 2017
Netherlands
In an innovation-driven society, the world of tomorrow is hard to predict. How do you work as an organization with unpredictable and constantly changing circumstances? For an increasing number of organizations, an agile way of working is the way to deal with continuous change.
But what does Agile really do? And how is the increasing popularity of Agile and Scrum explained? How does Scrum work? And how do you implement an agile way of working in your organization?
The Scrum Event, like last year, offers a full day program with useful workshops, interactive scrums and inspirational lectures from skilled Agile Coaches and visionaries in the field of Agile, Scrum and change management.
[ Visit Event Website ](http://scrumevent.nl/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
