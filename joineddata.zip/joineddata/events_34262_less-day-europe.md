---
source_url: https://www.scrum.org/events/34262/less-day-europe
date_scraped: 2025-06-29T05:29:57.629586
---

[ Skip to main content ](https://www.scrum.org/events/34262/less-day-europe#main-content)
#  LeSS Day Europe
Russia
LeSS Day Europe brings together professionals from Europe.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
