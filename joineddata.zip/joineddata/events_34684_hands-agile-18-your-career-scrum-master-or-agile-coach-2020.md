---
source_url: https://www.scrum.org/events/34684/hands-agile-18-your-career-scrum-master-or-agile-coach-2020
date_scraped: 2025-06-29T05:31:22.615363
---

[ Skip to main content ](https://www.scrum.org/events/34684/hands-agile-18-your-career-scrum-master-or-agile-coach-2020#main-content)
#  Hands-on Agile #18: Your Career as a Scrum Master or Agile Coach in 2020
Germany
Let’s face it — 2020 is lurking around the corner, and maybe that is an excellent opportunity to inspect and adapt our career-related plans, ambitions, or nascent New Year resolutions. The 18th Hands-on Agile meetup will hence focus on crowd-sourcing tips, tricks, and good practices to further your future career as a Scrum Master or Agile Coach. Once again, we will use one of our beloved Liberating Structures for this purpose — Ecocycle Planning.Professional Scrum Trainer Stefan Wolpers will be speaking at the event. 
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
