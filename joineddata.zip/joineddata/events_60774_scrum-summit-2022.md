---
source_url: https://www.scrum.org/events/60774/scrum-summit-2022
date_scraped: 2025-06-29T05:47:32.711773
---

[ Skip to main content ](https://www.scrum.org/events/60774/scrum-summit-2022#main-content)
#  Scrum Summit 2022
Organizations need to innovate constantly to sustain in the marketplace. It requires a culture of radical innovation and awareness of external factors affecting the business.
Our mission is to address the challenges of the current business environment to innovate, and guide the industry to lead through the volatility by bringing the best knowledge and information from the pioneers and leaders of Scrum, and advance the conversation to actionable ideas.
'Rethinking' is the need of the hour. Our goal is to discover new skills, tools and norms in the current situation to improve the ways of working and life of people.
Join us in exploring ways for Innovation in Scrum.
[ visit event website ](https://scrumsummit.org/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
