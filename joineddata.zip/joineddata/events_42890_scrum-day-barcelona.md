---
source_url: https://www.scrum.org/events/42890/scrum-day-barcelona
date_scraped: 2025-06-29T05:37:30.102800
---

[ Skip to main content ](https://www.scrum.org/events/42890/scrum-day-barcelona#main-content)
#  Scrum Day Barcelona
Scrum Day Barcelona is coming up December 3, 2020. The first Virtual Scrumday Barcelona adapts to the COVID times as an inexpensive virtual event and donates to medical research. Scrum.org has 25 free tickets available. Please use the code: **SD20_SDO-GP** to redeem!
[ visit event website ](https://scrumday.barcelona/en/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
