---
source_url: https://www.scrum.org/events/63766/agile-africa
date_scraped: 2025-06-29T05:50:01.777976
---

[ Skip to main content ](https://www.scrum.org/events/63766/agile-africa#main-content)
#  Agile in Africa
The theme this year for Agile in Africa is Leveraging Agility in Turbulent Times. Patricia Kong and PST Martin Hinshelwood will be speaking at this year's event.
[ Visit Event Website ](https://agileinafrica.com/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
