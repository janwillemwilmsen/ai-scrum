---
source_url: https://www.scrum.org/events/28244/agile-automotive-summit
date_scraped: 2025-06-29T05:18:19.674908
---

[ Skip to main content ](https://www.scrum.org/events/28244/agile-automotive-summit#main-content)
#  Agile for Automotive Summit
Agile for Automotive is bringing together automotive and mobility leaders with expertise in Agile and Lean Development Methodologies in automotive OEMs, mobility and the auto supply chain. This will be a forum in which clear questions of how OEM and mobility companies can remain competitive in an increasingly digital world with growing and diversifying customer demands, ambitious governmental regulations, and intensifying competition requires the most efficient and customer responsive processes available! Dave West and Nigel Thurlow will be delivering the opening keynote for this event. **A 20% registration discount is available if you use this code: AA19_SPEAKER.**
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
