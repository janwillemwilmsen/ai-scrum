---
source_url: https://www.scrum.org/events/4279/agile-turkey-summit-2016
date_scraped: 2025-06-29T04:56:54.336385
---

[ Skip to main content ](https://www.scrum.org/events/4279/agile-turkey-summit-2016#main-content)
#  Agile Turkey Summit 2016
The biggest Agile event in Turkey and in the region, Agile Turkey Summit 2016 Istanbul will be held on 6th of October, 2016. This year the main theme of the conference “End to End Agile Mind Shift”. We will have 4 sub-themes organized in parallel tracks. These are “DevOps”, “Agile in a Nutshell”, “The Mind Shift” and “Software Craftsmanship”.
Agile Turkey is a not-for-profit organization founded in 2008 with the purpose of increasing the adoption of Agile methods that have been proven effective around the world in Turkey. Since then, it’s been gaining attraction by organizing free public events and widely-accepted seminars,meetups and conferences.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
