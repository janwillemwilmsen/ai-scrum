---
source_url: https://www.scrum.org/events/12409/agile-africa
date_scraped: 2025-06-29T05:02:58.676770
---

[ Skip to main content ](https://www.scrum.org/events/12409/agile-africa#main-content)
#  Agile in Africa
Ghana
Our Vision is to “Accelerate the Transformation of Africa and make Life better for all by 2030″ by Investing in Agile ways of working for students, start ups, SME’s, large corporations, non-profit and public sector organisations.
[ Visit Event Website ](https://agileinafrica.com/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
