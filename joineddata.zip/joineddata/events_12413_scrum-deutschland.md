---
source_url: https://www.scrum.org/events/12413/scrum-deutschland
date_scraped: 2025-06-29T05:03:21.127981
---

[ Skip to main content ](https://www.scrum.org/events/12413/scrum-deutschland#main-content)
#  Scrum Deutschland
Germany
The date for the largest Scrum Community Event in North Rhine-Westphalia has been fixed! On 17 November 2017, under the motto "From good to great", all interested agilists from Germany meet in the heart of NRW - in Düsseldorf. This year, the Scrum Germany Event also includes the topics of the DvOn Summits, which will make it the largest trade event in NRW ever made! We are looking forward to exciting and interesting lectures with the focus on Scaling, Product Ownership and War Stories held by renowned personalities from the German and international Scrum community. Make sure you get your ticket at the right time in order to be present at this unique event!
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
