---
source_url: https://www.scrum.org/events/33018/emerce-update-6-digital-teams
date_scraped: 2025-06-29T05:28:43.072632
---

[ Skip to main content ](https://www.scrum.org/events/33018/emerce-update-6-digital-teams#main-content)
#  Emerce Update #6 Digital Teams
Netherlands
Emerce Update #6 Digital Teams will focus on digital transformation and will feature Professional Scrum Trainers [David Spinks](https://www.scrum.org/david-spinks) and [Glaudia Califano](https://www.scrum.org/glaudia-califano).
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
