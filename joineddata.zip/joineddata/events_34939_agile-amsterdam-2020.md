---
source_url: https://www.scrum.org/events/34939/agile-amsterdam-2020
date_scraped: 2025-06-29T05:31:38.661889
---

[ Skip to main content ](https://www.scrum.org/events/34939/agile-amsterdam-2020#main-content)
#  Agile Amsterdam 2020
Netherlands
Our fourth edition of Agile Amsterdam is on! Join us on the Wednesday warm-up evening with a keynote speaker and drinks, followed by the Thursday conference day with keynote speakers, company speakers, several workshops and a short concluding Open Space. Then top it off with a choice of several Master Classes on the Friday. Lots of learning, lots of networking opportunities and lots of fun! Dave West and Professional Scrum Trainer Joe Krebs will be speaking at the event.
[ visit event website ](https://www.agileamsterdam.nl/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
