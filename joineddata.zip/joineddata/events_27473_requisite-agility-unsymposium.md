---
source_url: https://www.scrum.org/events/27473/requisite-agility-unsymposium
date_scraped: 2025-06-29T05:16:51.482825
---

[ Skip to main content ](https://www.scrum.org/events/27473/requisite-agility-unsymposium#main-content)
#  Requisite Agility UnSymposium
Requisite Agility UnSymposium is an intense 2-day inaugural meeting aimed at exploring and comparing antecedent organizational and management systems, co-creating the conceptual foundations of Requisite Agility (RA). Together, as a community of practice, we will study the "anatomy of agile enterprise" and co-create the conceptual foundations of Requisite Agility.
We bring together system thinkers, holistic organizational anatomists, enterprise pathologists and engineers, agile coaches, and other practitioners to share their experiences, expertise and insights and to learn from each other. You’ll will have a chance of connecting with and learning from your peers – the meeting is attended by highly motivated and knowledgeable practitioners and experts – like yourself.
Come join us for this small yet epic event.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
