---
source_url: https://www.scrum.org/events/39659/agile-nyc-open-space-keynote
date_scraped: 2025-06-29T05:34:57.060222
---

[ Skip to main content ](https://www.scrum.org/events/39659/agile-nyc-open-space-keynote#main-content)
#  Agile NYC: Open Space with Keynote
In unprecedented times, we are trying something unprecedented as well. Join us Friday JUN 19 to our first 100% virtual event ever! And because this event is virtual, this event might be also interesting to a global audience. Cristina DeGiacomo will deliver the opening keynote from 10.30am to 11am ET
[ Visit Event Website ](http://www.agilenyc.org/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
