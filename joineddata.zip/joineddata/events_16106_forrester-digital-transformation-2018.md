---
source_url: https://www.scrum.org/events/16106/forrester-digital-transformation-2018
date_scraped: 2025-06-29T05:08:19.561364
---

[ Skip to main content ](https://www.scrum.org/events/16106/forrester-digital-transformation-2018#main-content)
#  Forrester Digital Transformation 2018
Digital transformation now dominates many C-suite and boardroom agendas. But it remains unclear what “digital transformation” means. Most definitions are shallow, even while expectations for success are optimistic. Faced with these disparate viewpoints and demands, CIOs, CTOs, and CDOs struggle to define cohesive digital strategies — resulting in (at best) tinkering at the margins or (at worst) chaos and inefficiency. 
Join us as business leaders and technology innovators come together to escape this trap by focusing less on the capabilities of specific technologies, and learning how to embrace the strategic business transformations that new digital technologies make possible. Kurt Bittner, VP of Enterprise Solutions will be speaking in a Lightning Talk on May 8. 
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
