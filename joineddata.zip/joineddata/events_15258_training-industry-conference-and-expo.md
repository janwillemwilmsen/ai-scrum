---
source_url: https://www.scrum.org/events/15258/training-industry-conference-and-expo
date_scraped: 2025-06-29T05:06:10.337833
---

[ Skip to main content ](https://www.scrum.org/events/15258/training-industry-conference-and-expo#main-content)
#  Training Industry Conference and Expo
United States
The 2018 Training Industry Conference & Expo (TICE) is a learning event that is unmatched in the corporate learning world. TICE is focused on building effective leaders of corporate learning and development. By design, TICE is a highly interactive experience, helping you meet new people while developing ideas and discovering solutions to address your challenges as a L&D leader. When you attend TICE, you will meet professionals who are dedicated to developing learning programs that make a difference. Over the course of three days, you will gather with your peers to discuss how you can overcome organizational obstacles and create strategic alignment through learning technologies, content, delivery and reporting. 
Scrum.org will be exhibiting at Booth # 105.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
