---
source_url: https://www.scrum.org/events/63767/agile-azerbaijan-first-international-summit
date_scraped: 2025-06-29T05:50:06.841078
---

[ Skip to main content ](https://www.scrum.org/events/63767/agile-azerbaijan-first-international-summit#main-content)
#  Agile Azerbaijan First International Summit
Azerbaijan
Agile Azerbaijan Summit is a one day event to deep dive into philosophy of being Agile.
Exchange of ideas, understanding the essence of Agility, networking and more will be at the heart of the Summit.
Guided by Agile Gurus, we’ll be active, engaged, and involved in shaping our own event with interactive sessions focused on the interesting topics. PST Martin Hinshelwood will be speaking at the event.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
