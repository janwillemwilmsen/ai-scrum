---
source_url: https://www.scrum.org/events/44562/beyond-agile-israel
date_scraped: 2025-06-29T05:38:54.406934
---

[ Skip to main content ](https://www.scrum.org/events/44562/beyond-agile-israel#main-content)
#  Beyond Agile Israel
A virtual conference with active networking, great vibes, small groups and international Agile leaders' talks
Dave West, [Ralph Jocham](https://www.scrum.org/ralph-jocham), [Jose Casal](https://www.scrum.org/jose-casal) and [Evelien Roos](https://www.scrum.org/evelien-roos) will be speaking at this event. 
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
