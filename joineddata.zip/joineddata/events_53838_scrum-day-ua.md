---
source_url: https://www.scrum.org/events/53838/scrum-day-ua
date_scraped: 2025-06-29T05:44:32.718019
---

[ Skip to main content ](https://www.scrum.org/events/53838/scrum-day-ua#main-content)
#  Scrum Day UA
ScrumDay UA consists of workshops, facilitations and live communication with agile professionals about the future of the industry in the context of the post-pandemic situation, changes due to remotes and much more. Professional Scrum Trainers [Magdalena Firlit](https://www.scrum.org/magdalena-firlit), [Itopa Sule](https://www.scrum.org/stefan-wolpers), [Stefan Wolpers](https://www.scrum.org/stefan-wolpers), [Bogdan Onyshchenko](https://www.scrum.org/Bogdan-Onyshchenko) and [Slava Moskalenko](https://www.scrum.org/slava-moskalenko) are all speaking!
[ visit event website ](https://scrumday.com.ua/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
