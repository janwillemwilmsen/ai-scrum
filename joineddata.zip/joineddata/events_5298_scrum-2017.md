---
source_url: https://www.scrum.org/events/5298/scrum-2017
date_scraped: 2025-06-29T04:57:54.399705
---

[ Skip to main content ](https://www.scrum.org/events/5298/scrum-2017#main-content)
#  Scrum 2017
Netherlands
On March 23, 2017 will ultimate Scrum event of the year. This day will acquire the character of knowledge and knowledge sharing, culminating in a very special session: KenSchwaber, one of the creators of Scrum, will appear as a hologram and share his vision about Scrum. There is also room for a Q & A with Ken!
As a trained Scrum Master or Product Owner is important to keep your knowledge up to date and to follow the latest trends around Agility. But if you're interested in working in an Agile environment and if you want to know more about Scrum, the event is valuable to you. The Agile philosophy revolves around providing fast and efficient value for customers.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
