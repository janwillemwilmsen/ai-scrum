---
source_url: https://www.scrum.org/events/16442/professional-scrum-chile-agile-value-delivery-metrics
date_scraped: 2025-06-29T05:09:04.470572
---

[ Skip to main content ](https://www.scrum.org/events/16442/professional-scrum-chile-agile-value-delivery-metrics#main-content)
#  Professional Scrum Chile - Agile Value Delivery with Metrics
Chile
Estimados. Los invitamos a un taller donde desarrollaremos en forma práctica métricas ágiles usando algunas técnicas. Facilitador: [Joel Francia](https://www.scrum.org/user/77), Trainer de Scrum.org. 
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
