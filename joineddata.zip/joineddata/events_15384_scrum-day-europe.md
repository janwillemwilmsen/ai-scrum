---
source_url: https://www.scrum.org/events/15384/scrum-day-europe
date_scraped: 2025-06-29T05:06:41.126035
---

[ Skip to main content ](https://www.scrum.org/events/15384/scrum-day-europe#main-content)
#  Scrum Day Europe
Scrum Day Europe is a great and lively journey for and by the Agile community and friends of Scrum. The event is a perfect place to be for change agents, Product Owners, and management. Take the opportunity to interact with presenters and like-minded peers who can share their experiences and lessons learned.
[ visit event website ](https://scrumdayeurope.com/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
