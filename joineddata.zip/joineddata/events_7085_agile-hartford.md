---
source_url: https://www.scrum.org/events/7085/agile-hartford
date_scraped: 2025-06-29T04:58:05.407742
---

[ Skip to main content ](https://www.scrum.org/events/7085/agile-hartford#main-content)
#  Agile Hartford
United States
## Where Do Good Product Owners Come From?
### _Resolving the conflict between Product Managers and Product Owners to deliver great software_
Scrum has become the de-facto standard for organizing Agile development teams with its focus on feedback, frequent delivery of working software, and simplicity. A key role in Scrum is the Product Owner, but as organizations transition to Scrum -  _who plays this role_? Business Analyst, Project Manager, Product Manager, or Other? The Product Owner seems to take from many of these existing disciplines, but applies them differently. Does the move to Scrum require the Product Owner to be master of everything…?
In this talk, Dave West, Product Owner (and CEO) of Scrum.org, will discuss how to resolve the tension of the Product Owner role, and who should perform the role. The talk provides very practical advice on resolving the conflict and how to make the Product Owner role deliver on its promise.
Key Concepts:
• Introducing the challenge of the Product Owner Role
• Requirements vs Ownership
• Who plays the Role
• Making it Work - Measurements, and 7 characteristics of Success
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
