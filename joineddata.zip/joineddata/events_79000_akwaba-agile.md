---
source_url: https://www.scrum.org/events/79000/akwaba-agile
date_scraped: 2025-06-29T05:54:34.619404
---

[ Skip to main content ](https://www.scrum.org/events/79000/akwaba-agile#main-content)
#  Akwaba Agile
Akwaba Agile, un événement co-organisé par Agilemind Africa et YooAgility qui réunit les professionnels de l’agilité et du digital à Abidjan, le 09 Décembre 2023. Managers, professionnels et étudiants vont se rencontrer pour partager les percepts des méthodes Agiles, mettant l’accent sur la flexibilité, la communication et l’adaptation aux changements dans les entreprises.
[ Visit Event Website ](https://www.akwaba-agile.com/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
