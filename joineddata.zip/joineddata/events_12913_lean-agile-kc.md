---
source_url: https://www.scrum.org/events/12913/lean-agile-kc
date_scraped: 2025-06-29T05:04:11.349899
---

[ Skip to main content ](https://www.scrum.org/events/12913/lean-agile-kc#main-content)
#  Lean Agile KC
United States
Learn from the best local and regional Lean-Agile practitioners and companies. Lean, Agile, DevOps, Lean UX, Lean Startup and more! Open KC offers a casual way for any attendee to contribute content. Bring your experiences, ideas, and questions!
Featured sessions include:
  * [Automating Your Test Suite: Incrementally Eating the Elephant](http://2017.leanagilekc.com/sessions/automating-your-test-suite-incrementally-eating-the-elephant/) with [Gary Pedretti](https://www.scrum.org/user/147): Building and maintaining test automation is a daunting task for many organizations. Companies with legacy applications often have a significant amount of technical debt around quality and testing, but even startups struggle once they scale beyond a few coders. The promise of Agile frameworks – and now DevOps – has always included cross-functional teams, incremental rollout, and a focus on highest-value deliverables first. This session will focus on how we can leverage these ideas and practices with a traditionally big bang, highly-specialized team area like test automation.
  * [Create Brainstorming Commandos for Creative Problem Solving](http://2017.leanagilekc.com/sessions/create-brainstorming-commandos-for-creative-problem-solving/) with [Pradeepa Narayanaswamy](https://www.scrum.org/pradeepa-narayanaswamy): Learn and practice various practical techniques for effective collaboration by “Using the brain to storm a creative problem…in commando fashion where each stormer attacks on the same objective.” In this highly practical workshop, Pradeepa Narayanaswamy will introduce the audience to a variety of brainstorming games. Attendees will practice and take back variety of ideas and concepts to facilitate a fun and effective brainstorming session. This session is targeted towards Scrum Masters, Agile Coaches, Managers or any team members who are looking to add more facilitation tools to their tool belt and put them to immediate use in their teams and meetings.


By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
