---
source_url: https://www.scrum.org/events/57567/agile-day-atlanta
date_scraped: 2025-06-29T05:45:59.373541
---

[ Skip to main content ](https://www.scrum.org/events/57567/agile-day-atlanta#main-content)
#  Agile Day Atlanta
United States
Agile Day Atlanta's sole purpose is to bring a diverse range of Agilists together in the spirit of community in an effort to share our knowledge and success with each other for the betterment of all.
Entering its ninth year, its mission continues to connect the community during these enduring times and provide conduits that allowing learning through experimentation to continue. Scrum.org and Scrum Simple will have a booth at the event. You can meet [Russell Miller](https://www.scrum.org/russell-miller) at the event to learn more about Professional Scrum.
[ visit event website ](https://agiledayatlanta.com/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
