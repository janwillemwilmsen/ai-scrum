---
source_url: https://www.scrum.org/events/30041/25th-annual-women-technology-summit
date_scraped: 2025-06-29T05:21:23.806383
---

[ Skip to main content ](https://www.scrum.org/events/30041/25th-annual-women-technology-summit#main-content)
#  25th Annual Women in Technology Summit
For 25 years running, the Women in Technology Summit has served as the premier gathering for more than 1,500 women and men from around the world, who converge in the Silicon Valley for three special days to build relationships, collaborate, and update their technical and leadership skills. Professional Scrum Trainer [Mica Syjuco ](https://www.scrum.org/user/95)will be presenting - Empowering Women as Agile and DevOps Thought Leaders at 1:15 pm PDT on June 9. 
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
