---
source_url: https://www.scrum.org/events/5280/scrum-day-bandung-2017
date_scraped: 2025-06-29T04:57:48.955085
---

[ Skip to main content ](https://www.scrum.org/events/5280/scrum-day-bandung-2017#main-content)
#  Scrum Day Bandung 2017
Indonesia
Join Professional Scrum Trainer [Joshua Partogi](https://www.scrum.org/user/168) as he speaks about Scrum in this inaugural event. Scrum.org will be a sponsor of this event. 
Scrum Day Bandung 2017 is an intense 1-day business agility & management conference with Scrum as its framework. But we think Scrum Day Bandung is more than just a conference. We think it is a community movement towards software development ecosystem that emphasizes agility and professionalism. We think software is a business need for companies to be competitive in 21st century. We think agility should be extended beyond IT because agility is a business requirement not a software development methodology.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
