---
source_url: https://www.scrum.org/events/28245/agile-2019
date_scraped: 2025-06-29T05:18:24.981149
---

[ Skip to main content ](https://www.scrum.org/events/28245/agile-2019#main-content)
#  Agile 2019
This annual North American conference is dedicated to furthering Agile principles and providing a venue for people and ideas to flourish. This is where the Agile tribes meet! Professional Scrum Trainers Gary Pedretti, David Sabine, Laurens Bonnema and Stephan van Rooden. will be speaking at the event. Please be sure to stop by the Scrum.org booth!
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
