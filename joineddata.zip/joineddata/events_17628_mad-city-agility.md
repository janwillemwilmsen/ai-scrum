---
source_url: https://www.scrum.org/events/17628/mad-city-agility
date_scraped: 2025-06-29T05:10:22.154114
---

[ Skip to main content ](https://www.scrum.org/events/17628/mad-city-agility#main-content)
#  Mad City Agility
The theme of this meetup is A Boat Rocker's Toolkit: Navigating Organizational Change presented by Professional Scrum Trainer Chad Beier.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
