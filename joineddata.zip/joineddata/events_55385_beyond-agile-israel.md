---
source_url: https://www.scrum.org/events/55385/beyond-agile-israel
date_scraped: 2025-06-29T05:44:54.972492
---

[ Skip to main content ](https://www.scrum.org/events/55385/beyond-agile-israel#main-content)
#  Beyond Agile Israel
Israel
BEYOND AGILE ISRAEL 2022 will take place as a hybrid conference ​ Along the entire day we will broadcast live & f2f: Talks from key international speakers and thought leaders Case studies from industry leaders Inspirational talks Introduce Agile implementations beyond software (i.e in research, health, social organizations)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
