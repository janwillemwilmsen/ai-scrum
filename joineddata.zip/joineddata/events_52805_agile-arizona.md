---
source_url: https://www.scrum.org/events/52805/agile-arizona
date_scraped: 2025-06-29T05:44:10.281762
---

[ Skip to main content ](https://www.scrum.org/events/52805/agile-arizona#main-content)
#  Agile Arizona
Agile Arizona is the Southwest's regional conference for Scrum and Agile practitioners, coaches, trainers and enthusiasts. Agile Arizona is in its sixth year, having sold out at 400+ attendees annually. This affordable event is a two-day experience mixing passionate people, great ideas, and industry best practices in a unique and creative setting.
Due to the uncertainty caused by the COVID-19 pandemic and the positive reception of last year's virtual event, we have decided to continue the virtual format for this year. For the health, safety, and sanity of all of us in our community, as well as due to the continued uncertainties, we feel that postponing our in-person activities is the correct choice. The good news is that we've been teleconferencing hard to put together an on-line event that will fulfill our mission to bring the best national and regional (possibly even global!) speakers, sessions, workshops and courses to you, the Agile community.
PSTs [Mark Wavle](https://www.scrum.org/mark-wavle) and [Julee Everett](https://www.scrum.org/julee-bellomo) will be speaking at this event!
[ visit event website ](https://agilearizona.org)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
