---
source_url: https://www.scrum.org/events/41950/bosnia-agile-week
date_scraped: 2025-06-29T05:35:55.356046
---

[ Skip to main content ](https://www.scrum.org/events/41950/bosnia-agile-week#main-content)
#  Bosnia Agile Week
Bosnia Agile Week is coming up October 19-23 and will be virtual event featuring many great speakers including Dave West.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
