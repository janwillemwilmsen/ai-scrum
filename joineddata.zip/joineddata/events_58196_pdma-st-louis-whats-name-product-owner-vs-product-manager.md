---
source_url: https://www.scrum.org/events/58196/pdma-st-louis-whats-name-product-owner-vs-product-manager
date_scraped: 2025-06-29T05:46:37.818691
---

[ Skip to main content ](https://www.scrum.org/events/58196/pdma-st-louis-whats-name-product-owner-vs-product-manager#main-content)
#  PDMA St. Louis: What’s in a name? Product Owner vs Product Manager
This is a FREE event hosted by PDMA St. Louis. 
**Description** Over the last 25+ years, Scrum has become very popular. As a result, organizations are increasingly looking to how the Scrum accountabilities interface with existing or new job titles. And Scrum Master and Product Owner have become job titles themselves. But is a Product Owner a Product Manager? And who is accountable for the Product Ownership in your team or organization?
In this session, Eric Naiburg COO of Scrum.org and recovering Product Owner discusses the role, its genesis, and how successful organizations have injected these accountabilities into their organizational structure. He also talks about how the ideas of agility are transforming the role of Product Manager to a key change agent in the digital age.
Learning Objectives:
  * Provide a clear description and genesis of the Product Owner Accountabilities.
  * Understand the boundaries between Product Ownership and Product management
  * Identify clear areas for focus on whatever the job title is


By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
