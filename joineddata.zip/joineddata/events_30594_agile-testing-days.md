---
source_url: https://www.scrum.org/events/30594/agile-testing-days
date_scraped: 2025-06-29T05:23:06.302945
---

[ Skip to main content ](https://www.scrum.org/events/30594/agile-testing-days#main-content)
#  Agile Testing Days
Germany
At Agile Testing Days there are 10+ tracks providing you lots of different input from talks, workshops and other sessions on all things agile testing. Professional Scrum Trainers Jose Casal and Wim Heemskerk will be speaking at this event. 
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
