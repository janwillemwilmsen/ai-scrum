---
source_url: https://www.scrum.org/events/77684/give-thanks-scrum-2023
date_scraped: 2025-06-29T05:54:17.677713
---

[ Skip to main content ](https://www.scrum.org/events/77684/give-thanks-scrum-2023#main-content)
#  Give Thanks for Scrum 2023
United States
Give Thanks for Scrum 2023: Empiricism in the Modern World
Join us on Tuesday November 21, 2023 Live at Microsoft in Burlington, MA for Agile Boston’s 15th Annual Give Thanks For Scrum event.
That’s right … for 2023, the GIVE THANKS FOR SCRUM event is once again LIVE!!
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
