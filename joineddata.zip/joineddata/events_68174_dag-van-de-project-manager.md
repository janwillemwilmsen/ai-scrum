---
source_url: https://www.scrum.org/events/68174/dag-van-de-project-manager
date_scraped: 2025-06-29T05:50:37.968761
---

[ Skip to main content ](https://www.scrum.org/events/68174/dag-van-de-project-manager#main-content)
#  Dag van de Project Manager
Belgium
Ready, set, go!
Every year, the Day of the Project Manager brings together the largest community of starting and experienced project professionals. More than 200 project managers attend each year. It is the place to be if you want to improve your project management skills or gain inspiration. You just can't miss this signature event of the year!
Appointment on June 15, 2023 in Bluepoint Antwerp (Berchem). PST [Steven Deneir](https://www.scrum.org/steven-deneir) will be speaking at the event.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
