---
source_url: https://www.scrum.org/events/77822/agile-leadership-day-india
date_scraped: 2025-06-29T05:54:29.102006
---

[ Skip to main content ](https://www.scrum.org/events/77822/agile-leadership-day-india#main-content)
#  Agile Leadership Day India
India
Agile approaches in modern business demand a paradigm shift in leadership. It is not about typical top-down control; rather, it is about encouraging team collaboration, adaptation, and empowerment. 
We haven't met in a year, therefore it's time to get ready for Agile Leadership Day India on 20th Jan 2024 to get ready and meet people face to face. Reconnection in person has an undeniable energy, as the warmth of physical presence and the interchange of genuine emotions create an atmosphere of shared experiences and fresh relationships.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
