---
source_url: https://www.scrum.org/events/49803/redefining-it-risk-post-pandemic-world
date_scraped: 2025-06-29T05:43:10.484591
---

[ Skip to main content ](https://www.scrum.org/events/49803/redefining-it-risk-post-pandemic-world#main-content)
#  Redefining IT Risk in Post-Pandemic world
With technology ever more critical to enterprise success and survival, IT leaders are taking a larger, more strategic role in assessing business challenges and opportunities.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
