---
source_url: https://www.scrum.org/events/14939/international-conference-data-science-e-learning-and-information-systems-2018
date_scraped: 2025-06-29T05:05:34.929401
---

[ Skip to main content ](https://www.scrum.org/events/14939/international-conference-data-science-e-learning-and-information-systems-2018#main-content)
#  International Conference on Data Science, E-learning and Information Systems 2018
Spain
The International Conference on Data Science, E-learning and Information Systems 2018 (Data'18) will take place in [Ayre Gran Hotel Colón](http://www.ayrehoteles.com/en/hotels/ayre-gran-hotel-colon/) Madrid, Spain, 1-2 October, 2018. Data'18 conference is co-sponsored by the [UDIMA Universidad a Distancia de Madrid](https://www.udima.es/). The conference is technically co-sponsored by Springer LNCS (Pending).
The conference has the focus on the frontier topics in the theoretical and applied data science and engineering, e-learning and information systems' subjects. Data'18 conference serves as good platforms for our members and the entire data engineering and IS community to meet with each other and to exchange ideas. 
Don't miss Scrum.org CEO Dave West as he is a keynote speaker for this event. 
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
