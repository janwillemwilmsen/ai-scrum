---
source_url: https://www.scrum.org/events/34431/scrum-master-studio-case-study-scaling-agility-open-space-challenges-agile
date_scraped: 2025-06-29T05:31:16.635472
---

[ Skip to main content ](https://www.scrum.org/events/34431/scrum-master-studio-case-study-scaling-agility-open-space-challenges-agile#main-content)
#  Scrum Master Studio - Case Study on Scaling Agility & Open Space - Challenges in Agile Transformation
India
This chapter will talk about challenges in Agile Transformation. This meetup is organized by Professional Scrum Trainer Venkatesh Rajamani.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
