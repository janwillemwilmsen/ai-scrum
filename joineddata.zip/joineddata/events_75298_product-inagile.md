---
source_url: https://www.scrum.org/events/75298/product-inagile
date_scraped: 2025-06-29T05:52:48.313289
---

[ Skip to main content ](https://www.scrum.org/events/75298/product-inagile#main-content)
#  Product inAgile
Czechia
Product inAgile is the biggest Czecho-Slovak conference specifically focused on modern product management and business innovations, providing room for active discussions of hot product as well as organizational topics. PST [Jochen Krebs ](https://www.scrum.org/joe-krebs)will be speaking at the event!
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
