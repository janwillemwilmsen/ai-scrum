---
source_url: https://www.scrum.org/events/75514/agile-day-malaysia
date_scraped: 2025-06-29T05:53:05.084605
---

[ Skip to main content ](https://www.scrum.org/events/75514/agile-day-malaysia#main-content)
#  Agile Day Malaysia
Malaysia
Agile Day Malaysia 2023 is a highly anticipated conference that aims to explore agility as a means to maximize efficiency and collaboration in product development and project delivery.
The conference will bring together industry experts, thought leaders, and practitioners from various sectors to share their knowledge, experiences, and success stories in Agile implementation.
Attendees can expect a wide range of informative sessions, interactive workshops, and engaging panel discussions that delve deep into the world of Agile.
We have 12 amazing agile specialist speakers from various industry eg Oil & Gas, Telecommunication, Banking & Insurance etc. lined up for this event! ️ 
Save the date 1st of November and join us for this epic gathering of agile professionals!
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
