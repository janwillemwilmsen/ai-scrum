---
source_url: https://www.scrum.org/events/36560/brewing-agile
date_scraped: 2025-06-29T05:33:21.740072
---

[ Skip to main content ](https://www.scrum.org/events/36560/brewing-agile#main-content)
#  Brewing Agile
Sweden
This will of course most easily relate to the digital industry, but we hope to broaden the focus to other areas. We want our speakers and attendees to share tools across our fields, both for improving your own flow but also for understanding other area of expertise in the product process.
We want to invite not only developers but, project managers, marketing professionals, sales people, and many others. Anyone with passion about their products! Professional Scrum Trainers Ron Eringa and Cesario Ramos will be speaking at the event.
[ visit event website ](https://brewingagile.org/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
