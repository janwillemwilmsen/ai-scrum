---
source_url: https://www.scrum.org/events/16876/music-city-tech
date_scraped: 2025-06-29T05:09:32.168820
---

[ Skip to main content ](https://www.scrum.org/events/16876/music-city-tech#main-content)
#  Music City Tech
Music City Tech is a three-day event consisting of simultaneous conferences, each focused on a particular community of technology professionals, held at Vanderbilt University. Professional Scrum Trainer Robb Pieper will be speaking at the event on June 1.
[ visit event website ](http://www.musiccitycode.com/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
