---
source_url: https://www.scrum.org/events/30644/scrum-day-india
date_scraped: 2025-06-29T05:23:11.943745
---

[ Skip to main content ](https://www.scrum.org/events/30644/scrum-day-india#main-content)
#  Scrum Day India
India
The purpose of Scrum Day India is to understand and explore the real essence of Agility and moving away from the deception of Agile transformation. Professional Scrum Trainer Gunther Verheyen will be speaking at the event.
[ visit event website ](https://scrumdayindia.org/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
