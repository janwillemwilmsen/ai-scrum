---
source_url: https://www.scrum.org/events/18222/agile-midwest
date_scraped: 2025-06-29T05:11:46.500464
---

[ Skip to main content ](https://www.scrum.org/events/18222/agile-midwest#main-content)
#  Agile Midwest
_Agile Week_ comes back to St. Louis from August 27-30th at the St. Charles Convention Center! Join us again for a week of classes, certifications, open space unconference, and wrapping up with the tracked Agile Midwest conference on Thursday, August 30th. 2017 brought together over 450 agilists from the Midwest region to join in informal networking, educational experience, and shared innovative ideas. Scrum.org will be at a booth with Cardinal Solutions. Stop by and say hello!
[ visit event website ](https://www.agilemidwest.org/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
