---
source_url: https://www.scrum.org/events/27399/star-west
date_scraped: 2025-06-29T05:16:45.890088
---

[ Skip to main content ](https://www.scrum.org/events/27399/star-west#main-content)
#  STAR West
STAR _WEST_ is one of the longest-running, and most respected conferences on software testing and quality assurance. The event week features over 100 learning and networking opportunities and covers a wide variety of some of the most in-demand topics and innovations.
[ visit event website ](https://starwest.techwell.com/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
