---
source_url: https://www.scrum.org/events/16185/agile-testing-days-2018
date_scraped: 2025-06-29T05:08:30.410818
---

[ Skip to main content ](https://www.scrum.org/events/16185/agile-testing-days-2018#main-content)
#  Agile Testing Days 2018
The Agile Testing Days USA reach out to all software engineers and testing professionals.The conference provides a fun platform to connect & network in the agile community. Equip your team with new methods & a mindset to take your projects to a new level! Patricia Kong, Product Owner - Enterprise Solutions, Scrum.org will be presenting on June 27: "Scale" The Most Hyped Term Today.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
