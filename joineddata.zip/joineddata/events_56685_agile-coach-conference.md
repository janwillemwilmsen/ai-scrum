---
source_url: https://www.scrum.org/events/56685/agile-coach-conference
date_scraped: 2025-06-29T05:45:43.536894
---

[ Skip to main content ](https://www.scrum.org/events/56685/agile-coach-conference#main-content)
#  Agile Coach Conference
Netherlands
This year’s Agile Coach Conference centers around the intrinsic values, what an Agile Coach’s DNA looks like. We will apply these values to all lines of work that Agile Coaches operate in: from IT to Marketing HR and to the public sector. Dave West and Leslie Morse will be speaking at this event as the closing Keynote - Professionalism in Agile Coaching.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
