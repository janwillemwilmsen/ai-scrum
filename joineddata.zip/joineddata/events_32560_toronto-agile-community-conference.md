---
source_url: https://www.scrum.org/events/32560/toronto-agile-community-conference
date_scraped: 2025-06-29T05:28:16.238131
---

[ Skip to main content ](https://www.scrum.org/events/32560/toronto-agile-community-conference#main-content)
#  Toronto Agile Community Conference
Canada
Toronto Agile Community brings you the Toronto Agile Conference in Toronto, Canada on November 05, 2019.
They are expecting ~1000 people for this year's event at the Beanfield Centre (formerly the Allstream Centre) at Exhibition Place. This, is its 11th annual conference, promises to be its biggest and best ever!
Professional Scrum Trainer [Dave Dame](https://confengine.com/toronto-agile-conference-2019/proposal/13309/is-your-agile-inclusive) will be speaking about inclusion and diversity. 
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
