---
source_url: https://www.scrum.org/become-professional-scrum-trainer/supporting-world
date_scraped: 2025-06-30T00:19:06.681069
---

[ Skip to main content ](https://www.scrum.org/become-professional-scrum-trainer/supporting-world#main-content)
#  Supporting the World
## Helping The World Solve Complex Problems
### Our global support efforts
The Scrum.org mission is to help people and teams solve complex problems. We aim to do so with professionalism, reliability, quality and value.
We believe [diversity and inclusion](https://www.scrum.org/about-us/scrumorg-diversity-and-social-responsibility "Diversity and Social Responsibility") are essential components of teams that deliver value. Enabling learners to engage with experts like them and who speak their native languages creates opportunities to forge deeper connections and enables the ongoing learning and development often needed to sustain effectiveness with Professional Scrum. 
If you [browse the list of people who are part of our global PST community](https://www.scrum.org/find-trainers), you will notice we have opportunities to enrich our own diversity and create greater representation in many ways. As a result, we have a deliberate growth strategy to help better match the diverse profiles of our current and emerging learners with the profiles of those who lead our Professional Scrum training events.
We are prioritizing highly-qualified trainer candidates who: 
  * Are from Japan, China, Mexico and other parts of Latin America who train in Japanese, Chinese, or Spanish America 


We welcome PST applications from [qualified trainers](https://www.scrum.org/become-professional-scrum-trainer/the-pst-candidate-journey "PST Candidate Journey") in these locations. 
[Learn more](https://www.scrum.org/about-us/scrumorg-diversity-and-social-responsibility "Diversity and Social Responsibility") about the Scrum.org commitment to diversity and social responsibility.
### Pricing Structure to Support the World
We categorize the countries in which our trainers operate as either primary, secondary or tertiary markets, basing our assignment of a country to one of these markets on many factors. We have designed our programs so that training in non-primary markets can be offered at lower prices.
##### Primary Markets
Austria, Belgium, Canada, Denmark, Finland, France, Germany, Ireland, Italy, Japan, Luxembourg, Netherlands, Norway, Sweden, Switzerland, United Kingdom, United States
##### Secondary Markets
All countries not listed as primary or tertiary
##### Tertiary Markets
India and African nations
**Note market designations are subject to change**
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
