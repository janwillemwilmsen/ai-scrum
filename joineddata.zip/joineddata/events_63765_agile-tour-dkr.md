---
source_url: https://www.scrum.org/events/63765/agile-tour-dkr
date_scraped: 2025-06-29T05:49:55.797792
---

[ Skip to main content ](https://www.scrum.org/events/63765/agile-tour-dkr#main-content)
#  Agile Tour DKR
Le mot des organisateurs. Les pratiques Agiles telles que Scrum ou Kanban ont une popularité grandissante sur le continent Africain. De plus en plus d’entreprises innovantes incorporent de l’agilité dans leurs processus de transformation digitale. Une transformation, devenue nécessaire à la suite des épreuves et défis imposés par la pandémie du COVID-19.
Certains professionnels de la gestion de projets se reconvertissent en Scrum Master, Product Owner ou même Coach Agile. Les gouvernements commencent à les intégrer progressivement ces nouvelles fonctions dans leurs plans stratégiques d’émergence. Il est désormais plus que nécessaire de vulgariser ces pratiques, populariser ce mindset, et accompagner les leaders et leurs organisations tout au long de leur transition vers l’agilité.
Depuis 15 ans, les conférences Agile Tour ont eu lieux dans plus d’une soixantaine de villes à travers le monde. Après Osaka, Bruxelles, Montréal et Sydney, Dakar sera la première ville en Afrique de l’Ouest à accueillir cet événement dédié à l’Agilité sous toutes ses formes. Venez découvrir, apprendre, et vous exercer avec nos experts Agiles locaux et internationaux. Ne manquez pas cette conférence atypique!
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
