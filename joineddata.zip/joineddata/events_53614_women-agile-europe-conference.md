---
source_url: https://www.scrum.org/events/53614/women-agile-europe-conference
date_scraped: 2025-06-29T05:44:26.975252
---

[ Skip to main content ](https://www.scrum.org/events/53614/women-agile-europe-conference#main-content)
#  Women in Agile Europe Conference
The Women in Agile Europe conference is coming up November 19! Professional Scrum Trainers Evelien Roos and Michal Epstein will be speaking at the event! Please use this family and friends coupon code to buy a ticket at the price of 29 Euro: the coupon code is FF29.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
