---
source_url: https://www.scrum.org/events/16164/agile-central-pa-meetup
date_scraped: 2025-06-29T05:08:24.877008
---

[ Skip to main content ](https://www.scrum.org/events/16164/agile-central-pa-meetup#main-content)
#  Agile Central PA Meetup
Join the Agile Central PA Meetup for a presentation from Matthew Christen on Agile memes and the important points they make in relation to your own experiences, along with discussing what we can do to improve.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
