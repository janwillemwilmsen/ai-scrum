---
source_url: https://www.scrum.org/events/34770/agile-munich-2020
date_scraped: 2025-06-29T05:31:27.938421
---

[ Skip to main content ](https://www.scrum.org/events/34770/agile-munich-2020#main-content)
#  Agile Munich 2020
Germany
Agile Munich 2020 | 3 Days of Conference, Workshops, Open Space and Certified Trainings
**This conference has been cancelled, but training is available online.**
Our 'Conference & Certified Training Week' is a one of its kind training event for organizations and individuals alike. We are organizing numerous certification trainings in parallel on March 31 - April 1, followed by our well known, third edition, Agile Munich 2020 Conference on April 2.
The Conference & Certified Trainings are targeted towards any Agile stakeholder in the organization, e.g. Directors, Managers, Product Owners, Scrum masters, Agile coaches and entire Development teams that are looking for a variety of agile training courses at the same time.
During breaks, and especially during our Conference on day 3, attendees from the various trainings can put their learning experiences back together. Our theme for this year is: Agile Learning, with focus on Agile Transformation!
[ visit event website ](https://www.agilemunich.com/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
