---
source_url: https://www.scrum.org/events/38873/nexus-framework-scaled-scrum-still-scrum
date_scraped: 2025-06-29T05:34:51.333119
---

[ Skip to main content ](https://www.scrum.org/events/38873/nexus-framework-scaled-scrum-still-scrum#main-content)
#  The Nexus Framework - Is Scaled Scrum Still Scrum
Germany
Ludwig Harsch will be a guest coach of Scrum.org: Scrum is the most frequently used framework in software development. Scrum is also increasingly being used in scaled environments, i.e. when several teams work together on a product.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
