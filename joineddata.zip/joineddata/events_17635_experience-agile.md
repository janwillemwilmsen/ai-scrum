---
source_url: https://www.scrum.org/events/17635/experience-agile
date_scraped: 2025-06-29T05:10:58.287069
---

[ Skip to main content ](https://www.scrum.org/events/17635/experience-agile#main-content)
#  eXperience Agile
Portugal
Scrum.org is a proud sponsor of eXperience Agile. 
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
