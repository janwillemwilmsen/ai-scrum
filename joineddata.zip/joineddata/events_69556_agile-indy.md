---
source_url: https://www.scrum.org/events/69556/agile-indy
date_scraped: 2025-06-29T05:51:19.969945
---

[ Skip to main content ](https://www.scrum.org/events/69556/agile-indy#main-content)
#  Agile Indy
United States
Join us on Friday, September 22, 2023 for our eighth annual AgileIndy Conference! At AgileIndy, we focus on bringing thought leaders and practitioners from around the country to Indianapolis for an intense learning and networking experience. There are a variety of sessions planned, with topics that range from Agile basics to leadership and technical practices. Whether you are completely new to Agile or have been practicing for many years, make this the next stop on your Agile journey!
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
