---
source_url: https://www.scrum.org/events/28242/star-canada-2019
date_scraped: 2025-06-29T05:18:08.890761
---

[ Skip to main content ](https://www.scrum.org/events/28242/star-canada-2019#main-content)
#  STAR Canada 2019
Canada
The conference week features over 50 learning and networking opportunities and covers a wide variety of some of the most in-demand topics—API testing, DevOps, agile testing, test automation, DevOps, test techniques, leadership, and more.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
