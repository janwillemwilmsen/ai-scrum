---
source_url: https://www.scrum.org/events/14470/agile-warrior-series-dallas
date_scraped: 2025-06-29T05:04:38.679972
---

[ Skip to main content ](https://www.scrum.org/events/14470/agile-warrior-series-dallas#main-content)
#  Agile Warrior Series: Dallas
United States
Agile Warrior Series: Dallas is an event featuring presentations from some of the best and brightest minds in the Agile space.[Patricia Kong](https://www.scrum.org/team/patricia-kong "Patricia Kong") and Professional Scrum Trainer [Ravi Verma](https://www.scrum.org/ravi-verma) are divided into three tracks - Leadership, High Performing Teams and Scaling & Adoption. This is one event you won’t want to miss. Seating is limited and this event is almost sold out so register today! 
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
