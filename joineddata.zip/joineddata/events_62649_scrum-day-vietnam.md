---
source_url: https://www.scrum.org/events/62649/scrum-day-vietnam
date_scraped: 2025-06-29T05:49:03.763166
---

[ Skip to main content ](https://www.scrum.org/events/62649/scrum-day-vietnam#main-content)
#  Scrum Day Vietnam
Vietnam
Scrum Day Vietnam is a great and exclusive occasion contributed by and for Vietnam Scrum/ Agile community and friends. The event is a perfect place to be for the people who interested in Scrum/ Agile. This is the good opportunity to meet and interact with presenters as Professional Scrum Trainers and like-minded peers who can share their experiences and lessons learned.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
