---
source_url: https://www.scrum.org/events/36797/agile-israel-2020
date_scraped: 2025-06-29T05:34:02.700102
---

[ Skip to main content ](https://www.scrum.org/events/36797/agile-israel-2020#main-content)
#  Agile Israel 2020
Israel
Agile Israel 2020 is the central Agile & DevOps event in Israel running for the 13th consecutive year, bringing world class experts and inspiring case studies to help you learn tips and tricks that can be applied in your organization.
This year’s theme is “Vision 2020”, to emphasize Agility’s ability to provide clear and direct insight about our processes. Transparency, visibility and empiricism, which are the foundations of Agility, allow this type of clarity that in turn induces openness, communication, collaboration and accountability.
[ visit event website ](https://www.agileisrael.co/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
