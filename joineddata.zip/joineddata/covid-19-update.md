---
source_url: https://www.scrum.org/covid-19-update
date_scraped: 2025-06-30T00:21:44.974278
---

[ Skip to main content ](https://www.scrum.org/covid-19-update#main-content)
#  COVID-19 Update
Scrum.org values the safety and health of our community, students, trainers and staff above all else. We continue to monitor public health guidance provided by global health safety organizations and adapt how we can support you based on that guidance.
### Alternative to in-person classes
  * During this crisis, we have added the ability for our [Professional Scrum Trainers](https://www.scrum.org/find-trainers) (PST) to hold any of their classes (public or private) in a Live Virtual delivery mode.
  * Scrum.org, our course stewards and PST community have worked together based on our experience to uniquely address today’s complex training requirements without sacrificing the quality of instruction.
  * Our Live Virtual format delivers the same benefits as our face-to-face training: expert instruction, hands-on labs and exercises, peer-to-peer collaboration, and high-quality instructional material.


### Free online learning resources
As always, Scrum.org continues to create and support our mission which includes providing free resources to help with your ongoing learning. 
  * [Learning Paths](https://www.scrum.org/resources/scrum-digital-learning-paths "Scrum Digital Learning Paths") for all roles: 
    * [Development Team Members](https://www.scrum.org/pathway/software-developer-learning-path "Software Developer Learning Path")
  * [Blogs](https://www.scrum.org/resources/blog) written by our PST Community
  * [Search](https://www.scrum.org/resources) all Resources


### Caring for our extended team
  * We maintain a cross-functional team focused on continuing standard business processes and to develop response scenarios as required.
  * We are managing employee work locations, based on guidance from global health organizations and local government agencies, and with consideration for local market conditions. At this time all Scrum.org staff members are working remotely.


Scrum.org is actively managing these items as an extension of our commitment to deliver value to our students, community, trainers, partners and employees. We expect that you will experience consistent service, without impacts to quality or costs.
[Read blog](https://www.scrum.org/resources/blog/how-our-pst-community-rallies-response-covid-19 "How our PST community rallies in response to COVID-19") by Scrum.org CEO Dave West about how the PST Team has rallied together.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
