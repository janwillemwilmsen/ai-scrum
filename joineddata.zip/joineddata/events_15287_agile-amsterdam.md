---
source_url: https://www.scrum.org/events/15287/agile-amsterdam
date_scraped: 2025-06-29T05:06:20.144179
---

[ Skip to main content ](https://www.scrum.org/events/15287/agile-amsterdam#main-content)
#  Agile Amsterdam
Netherlands
### **The theme: Agility at Scale**
Agility at Scale is about your company's ability to adapt in today's fast changing economy. The challenge is of course, that your company exists of many different functions, like Sales, Marketing, IT, who are all on a different level of Agile maturity. And this means that your company's Agility is only as effective as its weakest function! It is therefore to no surprise, that true Agile companies develop Agility across all of its functions. And preferably in alignment. Let's explore together Agility throughout the company and learn from one another. Let's explore Agility at Scale.
For this event, speakers and companies are invited who have truly raised the Agility bar in functions like IT, HR, Finance, Sales & Marketing and Management. We also look strategically; how do we prepare our next generation to flourish in the Agile company.
The event starts with talks, followed by an Open Space in which all speakers participate (so that you can interact with them) and finishes with an optional Master Class.
**The outline:**
  * September 19 | Warm-Up evening (optional)
  * September 20 | The Conference & Open Space
  * September 21 | Master Class (optional)


**Speakers and Companies:**
  * Jochen Krebs | Jeff Gothelf | Richard Sheridan | Kelly Waters | Jurriaan Kamer | And more
  * MAERSK | PICNIC | 101WAYS | The list keeps growing


[ Visit Event Website ](http://www.agileamsterdam.nl/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
