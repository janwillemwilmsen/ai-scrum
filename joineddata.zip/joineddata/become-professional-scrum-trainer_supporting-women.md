---
source_url: https://www.scrum.org/become-professional-scrum-trainer/supporting-women
date_scraped: 2025-06-30T00:23:01.396110
---

[ Skip to main content ](https://www.scrum.org/become-professional-scrum-trainer/supporting-women#main-content)
#  Supporting Women on their PST Journey
##### **Currently Pausing the application process for New PST candidates outside of Japan, China, Mexico, and Other Parts of Latin America**
_To support learners in underserved markets, Scrum.org will continue to actively seek PST candidates from**Japan, China, Mexico, and other parts of Latin America who train in Japanese, Chinese, or Spanish.**_
Para apoyar a los estudiantes en mercados desatendidos, Scrum.org busca activamente candidatos a PST de Japón, China, México y otras partes de América Latina que capaciten en japonés, chino o español. 
過小評価されている市場の学習者をサポートするため、Scrum.org は、日本語、中国語、またはスペイン語で研修を行う、日本、中国、メキシコ、およびラテンアメリカの他の地域からのPST候補者を積極的に募集しています。
为了支持服务不足市场的学习者，Scrum.org 正在积极寻找来自日本、中国、墨西哥和拉丁美洲其他地区，并使用日语、中文或西班牙语授课的 PST 候选人。
In support of the [Scrum.org commitment to diversity and social responsibility](https://www.scrum.org/about-us/scrumorg-diversity-and-social-responsibility "Diversity and Social Responsibility"), we have an intentional focus on [increasing the diversity of our Professional Scrum Trainer (PST) Community](https://www.scrum.org/become-professional-scrum-trainer/supporting-world "Supporting the World"). As a result, we are pleased to bring you opportunities specifically for Scrum practitioners who are women and are interested in learning about the journey to [becoming a PST](https://www.scrum.org/become-professional-scrum-trainer "Become a Professional Scrum Trainer"). We want to help you uncover ways for how to get started, nurture you on your journey and provide opportunities to network with others who can support you as you work towards earning this globally recognized credential.
Image
### Why Train with Scrum.org
Scrum.org is the _Home of Scrum_. We place a focus on what it means to [use Scrum professionally](https://www.scrum.org/what-professional-scrum "What is Professional Scrum?") as we fulfill our mission of helping people and teams solve complex problems. This work is rooted in supporting people in their ongoing learning and development in the [Professional Scrum Competencies](https://www.scrum.org/professional-scrum-competencies "The Professional Scrum™ Competencies").Being a PST gives you an opportunity to play a critical role in shaping the workforce of the future, showing other women what is possible in their own careers. There are [many compelling reasons to become a PST](https://www.scrum.org/supporting-women-reasons-become-pst "Supporting Women: Reasons to Become a PST"). Our existing PSTs tell us that the reputation and trust of the Scrum.org PST credential opens doors. 
### What is a Professional Scrum Trainer
Professional Scrum Trainers are professionals who teach the official Scrum.org curriculum. They are experts in Scrum and have extensive experience applying, leading, teaching, and coaching it. They have been servant-leaders at an organizational level and are active in local agile and/or software development communities, as well as the broader global agile and Scrum movements.﻿ We invite you to [learn more about becoming a PST.](https://www.scrum.org/become-professional-scrum-trainer "Become a Professional Scrum Trainer")
### Connect with Scrum.org Staff
Our staff loves to make connections with prospective Professional Scrum Trainers. They are here to answer your questions, help you determine the best ways to prepare for entering the PST Candidate Program, and are a resource to leverage as you navigate the journey to becoming a PST.Don't hesitate [**contact us**](https://www.scrum.org/become-professional-scrum-trainer/contact-us-about-becoming-a-trainer "Contact Us About Becoming a Trainer") so that the team can support you.
### What Students are Saying
Women PSTs make a difference!
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
