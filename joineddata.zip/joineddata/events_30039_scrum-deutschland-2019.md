---
source_url: https://www.scrum.org/events/30039/scrum-deutschland-2019
date_scraped: 2025-06-29T05:21:14.242253
---

[ Skip to main content ](https://www.scrum.org/events/30039/scrum-deutschland-2019#main-content)
#  Scrum Deutschland 2019
Germany
Scrum Germany is coming back this year and is celebrating its 5 year anniversary! For this we have come up with something very special! This year, we look beyond Scrum for the additional ingredients needed to successfully create value with Scrum. Dave West will be the opening keynote. Professional Scrum Trainers Evelien Roos, Laurens Bonnema, Peter Koning and Rob van Lanen will be speaking at the event.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
