---
source_url: https://www.scrum.org/events/25675/mad-city-agility-want-more-agility-do-these-3-things
date_scraped: 2025-06-29T05:12:48.933010
---

[ Skip to main content ](https://www.scrum.org/events/25675/mad-city-agility-want-more-agility-do-these-3-things#main-content)
#  Mad City Agility - Want More Agility? Do These 3 Things 
Bring your team, department, or organization’s context to this conversation and let’s dissect and test a simple, practical prescription with Professional Scrum Trainer Chad Beier!
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
