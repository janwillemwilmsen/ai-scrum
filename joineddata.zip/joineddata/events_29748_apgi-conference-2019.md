---
source_url: https://www.scrum.org/events/29748/apgi-conference-2019
date_scraped: 2025-06-29T05:20:47.950738
---

[ Skip to main content ](https://www.scrum.org/events/29748/apgi-conference-2019#main-content)
#  APGI Conference 2019
India
First time was a charm, second was an experience, third's going to change the way you think about agility. [#APGI2018](https://www.youtube.com/watch?v=QuQs_3oPzJU&list=PLm3JD5KpgUuC7MIMoP_DngiOmmTI_w8o0) saw 250+ participants, 48 sessions, and 58 speakers; #APGI2019 aims to address a different monster. ​
At APGI, we believe in bringing understanding through experience. We understand that though perfection is not attainable, if we chase perfection, we can catch excellence and we strive hard to exceed expectations every time. The APGI conference aims to bring about Agile awareness and bring concurring people together.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
