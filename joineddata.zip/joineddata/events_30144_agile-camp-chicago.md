---
source_url: https://www.scrum.org/events/30144/agile-camp-chicago
date_scraped: 2025-06-29T05:21:51.624825
---

[ Skip to main content ](https://www.scrum.org/events/30144/agile-camp-chicago#main-content)
#  Agile Camp Chicago
Chicago is a city with a rich history, vibrant food scene, beloved museums, and world-class architecture. The city is buzzing with enriching experiences, which is why we’re thrilled to bring AgileCamp to this magnificent location inside Chase Tower downtown Chicago. Professional Scrum Trainer Robb Pieper will be speaking at this event. 
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
