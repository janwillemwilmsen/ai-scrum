---
source_url: https://www.scrum.org/events/32447/joint-meeting-scrumrva-ieee-computer-society
date_scraped: 2025-06-29T05:27:17.048341
---

[ Skip to main content ](https://www.scrum.org/events/32447/joint-meeting-scrumrva-ieee-computer-society#main-content)
#  Joint meeting with ScrumRVA & the IEEE Computer Society
Dave West will be speaking at this joint meeting with ScrumRVA & the IEEE Computer Society.
**Scrum Turns 21, Are We Done Yet?**
**Abstract:** 90% of Agile teams are using Scrum. With over ½ a million people trained and certified. Scrum has become, for many the de-facto standard in Agile team organization. But what is next for Scrum? Will Scrum just become the ‘way you build software’ rather than something special or unique? In this talk Dave West will discuss the success and future of Scrum and what needs to happen to Scrum to continue its relevance. We describe how measurement, scaling and DevOps need to be weaved into Scrum to not only ensure its relevance, but also help the profession of software development improve.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
