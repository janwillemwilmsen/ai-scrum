---
source_url: https://www.scrum.org/events/37237/agile-lean-ireland
date_scraped: 2025-06-29T05:34:22.732109
---

[ Skip to main content ](https://www.scrum.org/events/37237/agile-lean-ireland#main-content)
#  Agile-Lean Ireland
Ireland
Agile-Lean Ireland 2020 will return to Croke Park on April 20-21st 2020! Professional Scrum Trainers Daniel Vacanti, Christiaan Verwijs, Barry Overeem, Jose Casal, JP Bayley and John Coleman will be speaking at the event.
[ visit event website ](https://ali2020.sched.com/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
