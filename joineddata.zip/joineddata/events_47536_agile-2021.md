---
source_url: https://www.scrum.org/events/47536/agile-2021
date_scraped: 2025-06-29T05:40:23.613845
---

[ Skip to main content ](https://www.scrum.org/events/47536/agile-2021#main-content)
#  Agile 2021
**Agile Alliance’s annual conference** is dedicated to exploring, innovating, and advancing Agile values and priniciples, and creating a space for people and ideas to flourish. The Agile20XX conference brings Agile communities together year after year to share experiences and make new connections — and this year we’ll be celebrating the 20th Anniversary of the Agile Manifesto, as well as Agile Alliance’s 20th birthday! Join passionate Agilists from around the world to learn about the latest practices, ideas, and strategies in Agile software development from the world’s leading experts, change agents, and innovators.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
