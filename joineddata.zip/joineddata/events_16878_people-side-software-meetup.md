---
source_url: https://www.scrum.org/events/16878/people-side-software-meetup
date_scraped: 2025-06-29T05:09:42.798732
---

[ Skip to main content ](https://www.scrum.org/events/16878/people-side-software-meetup#main-content)
#  The People Side of Software Meetup
In this edition of the People Side of Software Meetup, Professional Scrum Trainer Robb Pieper will be presenting an Intro to Scrum.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
