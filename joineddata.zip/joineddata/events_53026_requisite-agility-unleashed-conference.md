---
source_url: https://www.scrum.org/events/53026/requisite-agility-unleashed-conference
date_scraped: 2025-06-29T05:44:21.437147
---

[ Skip to main content ](https://www.scrum.org/events/53026/requisite-agility-unleashed-conference#main-content)
#  Requisite Agility Unleashed Conference
The Requisite Agility Conference will take place on December 7-8. RA is doing what is required, based on what your customers and stakeholders need and value. This conference unleashes the four realms of Requisite Agility - Personal Agility, Team Agility, Business Agility and Societal Agility. Use the code SCRUM50 for 50% off your ticket! Patricia Kong will be speaking at the event!
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
