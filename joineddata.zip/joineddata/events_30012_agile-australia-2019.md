---
source_url: https://www.scrum.org/events/30012/agile-australia-2019
date_scraped: 2025-06-29T05:20:58.933642
---

[ Skip to main content ](https://www.scrum.org/events/30012/agile-australia-2019#main-content)
#  Agile Australia 2019
Australia
AgileAus relies on the goodwill of a diverse and welcoming cohort of community members who are united in their curiosity to explore better ways of working.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
