---
source_url: https://www.scrum.org/events/44241/deutschsprachige-event-serie-zum-scrum-guide-2020
date_scraped: 2025-06-29T05:38:33.253812
---

[ Skip to main content ](https://www.scrum.org/events/44241/deutschsprachige-event-serie-zum-scrum-guide-2020#main-content)
#  Deutschsprachige Event-Serie zum Scrum Guide 2020!
Die Online Scrum Community (OSC) ist die erste deutschsprachige non-profit Online-Community zu Scrum. Die OSC organisiert neben aktuellen Themen regelmäßig online Veranstaltungen zu Scrum (z.B. Stakeholdermanagement, Skalierung). 
Die OSC bietet eine deutschsprachige Event-Serie zum neuen Scrum Guide 2020 an. 
Wir werfen gemeinsam mit Euch gespannte Blicke auf den Scrum Guide 2020!
Welche Änderungen bringt er? Was davon begeistert Euch? Wo seht ihr besondere Herausforderungen?
Anmeldungen zu den online Events am 20.11. / 27.11. / 11.12. / 18.12., jeweils um 17 Uhr <https://www.andrena.de/scrum-guide-2020><https://www.xing.com/events/online-scrum-community-uberblick-scrum-guide-2020-3178703>
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
