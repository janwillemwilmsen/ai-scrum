---
source_url: https://www.scrum.org/events/74832/agile-example
date_scraped: 2025-06-29T05:52:38.126522
---

[ Skip to main content ](https://www.scrum.org/events/74832/agile-example#main-content)
#  Agile by Example
Poland
Save the Date!
October 2–4
For more than ten years, AgileByExample has become the leading conference in its field.
It's the perfect event to learn more, explore new perspectives, get hands-on experience, and make the most of networking.
Join us and 500 other enthusiasts in Warsaw for ABE23.
[ Visit event website ](https://agilebyexample.com/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
