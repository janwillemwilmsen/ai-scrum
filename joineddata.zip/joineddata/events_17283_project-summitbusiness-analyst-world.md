---
source_url: https://www.scrum.org/events/17283/project-summitbusiness-analyst-world
date_scraped: 2025-06-29T05:09:54.099672
---

[ Skip to main content ](https://www.scrum.org/events/17283/project-summitbusiness-analyst-world#main-content)
#  Project Summit/Business Analyst World
ProjectSummit*BusinessAnalystWorld is the largest series of conferences for Project Managers and Business Analysts in North America. These industry leading events feature expert speakers representing every sector, from all reaches of the globe. Scrum.org is sponsoring this event.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
