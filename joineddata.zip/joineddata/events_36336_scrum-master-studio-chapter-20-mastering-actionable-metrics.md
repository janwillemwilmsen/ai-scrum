---
source_url: https://www.scrum.org/events/36336/scrum-master-studio-chapter-20-mastering-actionable-metrics
date_scraped: 2025-06-29T05:33:05.062584
---

[ Skip to main content ](https://www.scrum.org/events/36336/scrum-master-studio-chapter-20-mastering-actionable-metrics#main-content)
#  Scrum Master Studio - Chapter 20 - Mastering Actionable Metrics
India
This chapter would move away Scrum Masters from Metrics Mastering to Professional Scrum Mastery that creates outcomes! This meetup will feature Professional Scrum Trainer Venkatesh Rajamani.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
