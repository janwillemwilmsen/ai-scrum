---
source_url: https://www.scrum.org/events/43296/women-agile-conference-europe
date_scraped: 2025-06-29T05:37:41.621579
---

[ Skip to main content ](https://www.scrum.org/events/43296/women-agile-conference-europe#main-content)
#  Women in Agile Conference Europe
The Women in Agile Conference - Europe is taking place online this year with many powerful speakers!
[ visit event website ](https://womeninagile.eu/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
