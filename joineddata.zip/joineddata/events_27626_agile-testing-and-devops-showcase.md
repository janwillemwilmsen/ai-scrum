---
source_url: https://www.scrum.org/events/27626/agile-testing-and-devops-showcase
date_scraped: 2025-06-29T05:17:07.964463
---

[ Skip to main content ](https://www.scrum.org/events/27626/agile-testing-and-devops-showcase#main-content)
#  Agile, Testing and DevOps Showcase
Agile, Testing and DevOps: Are they a Separate conversation or a progression of capability?
DevOps, Testing and Agile have shared environments that facilitate working together. Spurred by greater demand for excellence, these three methods are more than simply adopting new tools and processes. The synergy involves building an evolving and a stable Continuous Integration (CI) Infrastructure, as well as an automated pipeline that moves deliverables from development to production to meet users’ expectations. They can work together, and the entire build process should be transparent, and it should enable and support development and operations. This transformation depends on: significant changes in culture; roles and responsibilities; team structure; tools and processes. This conference focuses on the convergence of Agile, DevOps and testing. Professional Scrum Trainer [Evelien Roos](https://www.scrum.org/evelien-roos) will be speaking at this event. 
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
