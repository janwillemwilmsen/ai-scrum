---
source_url: https://www.scrum.org/events/12882/professional-development-day
date_scraped: 2025-06-29T05:03:59.370378
---

[ Skip to main content ](https://www.scrum.org/events/12882/professional-development-day#main-content)
#  Professional Development Day
United States
The Milwaukee chapter of PMI is putting on a great event to help further your career and drive results. It will feature three tracks which align with the PMI Talent Triangle. You will have the ability to choose sessions of interest to you, or those that get you the PDUs you need. Depending on the number of activities you participate in that day, you will have the opportunity to earn up to seven PDUs.
Featured speakers include PST [Gary Pedretti](https://www.scrum.org/user/147), who will hold a session on **Agile Architecture – Ideals, History and a New Hope**. This talk will review the history of architecture in the agile development world, explain common pitfalls, and provide concrete patterns and practices for growing and maintaining application and enterprise architecture in a sustainable, agile way.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
