---
source_url: https://www.scrum.org/events/30806/iterate-workshop
date_scraped: 2025-06-29T05:23:23.048092
---

[ Skip to main content ](https://www.scrum.org/events/30806/iterate-workshop#main-content)
#  Iterate Workshop
[Iterate™ Product Development Game](https://iterate.game/go) is a simulation board game for product development professionals. It is a unique sandbox experience of a software product development life cycle. For trainers and coaches [Iterate™ Product Development Game](https://iterate.game/go) is a teaching platform with endless possibilities.
### TARGET AUDIENCE
All software product development professionals, especially founders, Product Owners, Product Managers, and Development Team Members. This workshop is also for all the Scrum Masters, Scrum Trainers, and Agile Coaches looking to spice up their teachings.
### LEARNING OUTCOMES
In this workshop, you will manage the development process. You will manage the budget and the revenue stream. You will strive to stay innovative and profitable. You will grow the team, deal with stakeholders, the market, the competition, and more.
> At the end of the workshop you will:
  * Understand Scrum as product and business development method.
  * Understand a Scrum Sprint as an investment and contingency strategy and learn how to optimize the value of it.
  * Understand the role and accountabilities of a Scrum Product Owner.
  * Understand how hard data, transparency and openness support decision making.
  * Learn how to work with the product backlog, capacity and velocity and how to use them for long-term projections.
  * Understand the impact of technical debt on the product and the development team.
  * Understand how [Iterate™ Product Development Game](https://iterate.game/go) can be used to enhance, extend or exchange Scrum related training courses.


By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
