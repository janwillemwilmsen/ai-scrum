---
source_url: https://www.scrum.org/events/32304/agile-midwest
date_scraped: 2025-06-29T05:26:43.543932
---

[ Skip to main content ](https://www.scrum.org/events/32304/agile-midwest#main-content)
#  Agile Midwest
Agile Midwest was founded to promote Lean and Agile concepts across all companies regardless of industry segment. Our goal is make the latest industry developments accessible to audiences in the midwest, who deserve the same access to leading-edge knowledge as other technology hubs around the world. Whether you make software, hardware, or just work at an organization that could benefit from finding better ways to work together, you can find something knowledge and inspiration at Agile Midwest 2019. Professional Scrum Trainer Mark Wavle is presenting at the event!
[ visit event website ](https://agilemidwest.org/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
