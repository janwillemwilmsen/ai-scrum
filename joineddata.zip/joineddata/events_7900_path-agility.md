---
source_url: https://www.scrum.org/events/7900/path-agility
date_scraped: 2025-06-29T04:58:59.419794
---

[ Skip to main content ](https://www.scrum.org/events/7900/path-agility#main-content)
#  The Path to Agility
United States
#### Begin or continue your path to Craftsmanship & Agility
The Path to Agility conference was developed to further COHAA’s mission to promote the use of Agile practices and principles. COHAA has engaged a number of national and regional Agile thought leaders to provide session content focused on a mix of business, technical, and/or management topics. Whether you are well along the path or just starting out, this conference will help guide you in the right direction.
The Central Ohio Agile Association (COHAA) is a non-profit group of IT professionals dedicated to finding a better way to deliver software. COHAA is dedicated to promoting the use of Agile practices and principles in project management, software development, quality assurance, and business analysis with an emphasis on solution delivery.
[Dave West](https://www.scrum.org/user/252) talks about Scrum's past and future - what's in store for the next 20 years?
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
