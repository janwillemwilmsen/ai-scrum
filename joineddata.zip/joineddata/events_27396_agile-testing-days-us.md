---
source_url: https://www.scrum.org/events/27396/agile-testing-days-us
date_scraped: 2025-06-29T05:16:40.529555
---

[ Skip to main content ](https://www.scrum.org/events/27396/agile-testing-days-us#main-content)
#  Agile Testing Days US
The Agile Testing Days USA reach out to all software engineers and testing professionals. The conference provides a fun platform to connect & network in the agile community. Equip your team with new methods & a mindset to take your projects to a new level!
[ visit event website ](https://agiletestingdays.us/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
