---
source_url: https://www.scrum.org/events/17986/agile-leadership-series-working-agile-resisters
date_scraped: 2025-06-29T05:11:19.770456
---

[ Skip to main content ](https://www.scrum.org/events/17986/agile-leadership-series-working-agile-resisters#main-content)
#  Agile Leadership Series - Working with Agile Resisters
Every agile transformation hits roadblocks. Some of these are technical but most of them are people related. Resisters not only slow your transformation down but they can negatively impact other members of your team.
People fight agile transformations for a variety of reasons and in this session I will discuss ways of getting through most of the common issues. From “Too many meetings” to the change in mindset from “Me” to “Us” we discuss how to get through to get to the root of why they are resisting and how to get them aligned with your vision.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
