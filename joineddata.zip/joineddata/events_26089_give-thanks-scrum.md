---
source_url: https://www.scrum.org/events/26089/give-thanks-scrum
date_scraped: 2025-06-29T05:14:12.385274
---

[ Skip to main content ](https://www.scrum.org/events/26089/give-thanks-scrum#main-content)
#  Give Thanks for Scrum
Join us on Tuesday November 20, 2018 in Burlington Massachusetts for Agile Boston’s 10th Annual Give Thanks For Scrum event. You may not know that Scrum was born in Boston and thus its very appropriate that Give Thanks For Scrum has become a true Agile Boston tradition! Dave West will be presenting at the event and Scrum.org will host a Nexus Zoo Workshop.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
