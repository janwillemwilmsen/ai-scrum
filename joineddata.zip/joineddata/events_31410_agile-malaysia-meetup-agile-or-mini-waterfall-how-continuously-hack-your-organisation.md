---
source_url: https://www.scrum.org/events/31410/agile-malaysia-meetup-agile-or-mini-waterfall-how-continuously-hack-your-organisation
date_scraped: 2025-06-29T05:25:30.048019
---

[ Skip to main content ](https://www.scrum.org/events/31410/agile-malaysia-meetup-agile-or-mini-waterfall-how-continuously-hack-your-organisation#main-content)
#  Agile Malaysia Meetup -Agile or Mini-Waterfall: How to continuously hack your organisation to improve agility
Malaysia
Given that agile started in software development, it is common to see the genesis of agile initiatives within corporations coming from the IT / Tech divisions. While corporate leaders understand the need to have business agility in the 21st century to succeed, many do not know how to scale agility beyond technology teams or even what indicators should be used to measure their agility. Join Joshua Partogi as he shares the principles and methods of measurements used at iPrice to continuously improve their agility. Joshua is an experienced Professional Scrum trainer with Scrum.org. A psychology graduate, he is passionate about people, with a mission to bring back humanity to workplaces. Find out more about Joshua [here](https://www.linkedin.com/in/jpartogi/) This event is FREE but registration is mandatory for security and logistics purposes. Agenda: 7.00pm Networking & light refreshments (sponsored by iPrice) 7.30pm How to continuously hack your organisation to improve agility 8.15pm Q&A Panel 8.45pm Event Ends
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
