---
source_url: https://www.scrum.org/events/12414/gatineau-ottawa-agile-tour-2017
date_scraped: 2025-06-29T05:03:26.335658
---

[ Skip to main content ](https://www.scrum.org/events/12414/gatineau-ottawa-agile-tour-2017#main-content)
#  GATINEAU OTTAWA AGILE TOUR 2017
Canada
Agile Tour is a series of non-profit events over several cities throughout October to December. Join us for the 2017 edition of the Gatineau Ottawa Agile Tour, affectionately known as GOAT. Organized by a local team of dedicated Agile practitioners, #GOAT2017 will be a value-packed conference for the 500+ professionals expected to attend this year.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
