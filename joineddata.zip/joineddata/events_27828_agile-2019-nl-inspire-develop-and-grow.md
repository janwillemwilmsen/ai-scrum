---
source_url: https://www.scrum.org/events/27828/agile-2019-nl-inspire-develop-and-grow
date_scraped: 2025-06-29T05:17:34.305608
---

[ Skip to main content ](https://www.scrum.org/events/27828/agile-2019-nl-inspire-develop-and-grow#main-content)
#  Agile 2019 NL - Inspire, Develop and Grow
The Agile community is rapidly growing which luckily means that more experience and knowledge can be shared. Agile 2019 focuses on sharing Agile knowledge with as many Agile professionals as possible. With various inspirational sessions, the goal is to share and spread Agile trends, success stories as well as war stories and make it possible to share growth paths with all who want to grow in their current role as either Scrum Master, Product Owner or Agile Coach.
Master of neuromagic Victor Mids opens the program after which Rini van Solingen facilitates an inspirational session about the power of Agile. Product Owners of the year will share their success stories and multiple Agile trainers and Professional Scrum trainers aim to share worthy upcoming trends when it comes to the Agile way of working. 
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
