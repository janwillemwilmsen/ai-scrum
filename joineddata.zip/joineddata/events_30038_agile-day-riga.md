---
source_url: https://www.scrum.org/events/30038/agile-day-riga
date_scraped: 2025-06-29T05:21:08.826557
---

[ Skip to main content ](https://www.scrum.org/events/30038/agile-day-riga#main-content)
#  Agile Day Riga
Latvia
### What is Agile Day Riga?
The goal of this event is to enable and nurture Agile and Lean community of people in Latvia for collaboration, information sharing, discussions, and, as an agile community, to enable self-organization. ADR is:
  * Completely non-profit.
  * Organised for over seven years without a need of formal structures or management
  * Is all about practitioners which actully work Agile and Lean.
  * Since 2011, volunteers from [Agile Latvia](https://www.agiledayriga.lv/index.html#alv) network have organized annual (un-)conferences to meet old and new friends, to exchange opinions and learn or share.


Professional Scrum Trainer Roland Flemm will be presenting - Iterating Toward Professional Scrum. 
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
