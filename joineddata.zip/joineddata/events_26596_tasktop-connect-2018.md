---
source_url: https://www.scrum.org/events/26596/tasktop-connect-2018
date_scraped: 2025-06-29T05:14:44.774646
---

[ Skip to main content ](https://www.scrum.org/events/26596/tasktop-connect-2018#main-content)
#  Tasktop Connect 2018
Learn, from industry leaders, ways to achieving end-to-end visibility and traceability across your software development and delivery value stream and how the Flow FrameworkTM will enable your company's evolution from project-oriented dinosaur to product-centric innovator that thrives in the Age of Software. Dave West will be speaking at this event.
[ visit event website ](https://connect.tasktop.com/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
