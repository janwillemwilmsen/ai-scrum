---
source_url: https://www.scrum.org/events/42446/agile-week-carolinas
date_scraped: 2025-06-29T05:36:56.483347
---

[ Skip to main content ](https://www.scrum.org/events/42446/agile-week-carolinas#main-content)
#  Agile Week Carolinas
Agile Week Carolinas™ was created by BrandDisco©, an Agile Leadership & Business Readiness Company, to help Connect & Catapult The Carolinas’ Growing Agile Community! One Time per Year. One Location. One Week. One Voice - exchanging ideas and sharing experiences!
Patricia Kong, Leslie Morse and Dave West from Scrum.org will all be speaking at this exciting virtual event!
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
