---
source_url: https://www.scrum.org/events/40029/lean-agile-global-2020
date_scraped: 2025-06-29T05:35:14.773470
---

[ Skip to main content ](https://www.scrum.org/events/40029/lean-agile-global-2020#main-content)
#  Lean Agile Global 2020
Two days packed with awesome talks and lots of opportunities to engage and interact with other speakers & participants.
[ Visit Event Website ](https://leanagile.global/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
