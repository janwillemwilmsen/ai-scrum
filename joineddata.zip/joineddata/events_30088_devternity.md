---
source_url: https://www.scrum.org/events/30088/devternity
date_scraped: 2025-06-29T05:21:40.287458
---

[ Skip to main content ](https://www.scrum.org/events/30088/devternity#main-content)
#  Devternity 
Latvia
DevTernity is the top 3 international software development conference in Europe. They focus on the core skills paramount to your success – code design, software architecture and leadership. Professional Scrum Trainer [Peter Gfader](https://www.scrum.org/peter-gfader) will be speaking at this event. 
[ visit event website ](https://devternity.com/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
