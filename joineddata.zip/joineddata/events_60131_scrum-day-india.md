---
source_url: https://www.scrum.org/events/60131/scrum-day-india
date_scraped: 2025-06-29T05:47:16.164800
---

[ Skip to main content ](https://www.scrum.org/events/60131/scrum-day-india#main-content)
#  Scrum Day India
It all started in 2016 when India launched its Startup India initiative. The objective was to provide an environment for promoting innovation and to drive sustainable economic growth and generate employment opportunities in the country. Despite the global pandemic, Indian startups have not only grown up but have got a solid foundation and some great success stories too. The new-age entrepreneurs are thinking beyond revenue and their focus is more on solving customer problems – be it in agriculture, logistics, pharma, banking, or any other domain. With so much growth that happened under this initiative in the last 5 years, the “Scrum Day India” event is a platform provided to people who would like to share their stories about, how they “STARTED” and how they are “UP”
[ visit event website ](https://scrumdayindia.org)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
