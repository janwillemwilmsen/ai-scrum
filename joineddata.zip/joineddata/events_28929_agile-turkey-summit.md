---
source_url: https://www.scrum.org/events/28929/agile-turkey-summit
date_scraped: 2025-06-29T05:19:48.216596
---

[ Skip to main content ](https://www.scrum.org/events/28929/agile-turkey-summit#main-content)
#  Agile Turkey Summit
Türkiye
Agile Turkey Summit 2019 is a single day, international event gathering Agile enthusiasts together. We would like to invite you to take part in the 7th Agile Turkey Summit to discuss the hot topics in Agile world.
[ visit event website ](http://summit.agileturkey.org/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
