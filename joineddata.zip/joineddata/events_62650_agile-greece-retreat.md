---
source_url: https://www.scrum.org/events/62650/agile-greece-retreat
date_scraped: 2025-06-29T05:49:09.142756
---

[ Skip to main content ](https://www.scrum.org/events/62650/agile-greece-retreat#main-content)
#  Agile Greece Retreat
Greece
Agile Greece Retreat aspires to be a deep learning experience; a weekend by the sea, where we meet to solve problems, share lessons learned, exchange and challenge ideas about all aspects of agility and human-centered work.
[ Visit Event Website ](https://www.agileretreat.gr/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
