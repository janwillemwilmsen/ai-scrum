---
source_url: https://www.scrum.org/events/62965/agile-tour-quebec
date_scraped: 2025-06-29T05:49:30.371668
---

[ Skip to main content ](https://www.scrum.org/events/62965/agile-tour-quebec#main-content)
#  Agile Tour Quebec
Cet événement majeur réunira plus de 1000 adeptes de l’agilité, en présentiel comme à distance, et donnera l’opportunité aux conférenciers de partager leurs savoirs, leurs expériences et leurs dernières découvertes. Cette journée enrichissante pour les participants de tous les horizons est une opportunité de se faire connaître et d’échanger au travers des conférences et ateliers proposés.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
