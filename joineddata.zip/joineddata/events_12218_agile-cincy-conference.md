---
source_url: https://www.scrum.org/events/12218/agile-cincy-conference
date_scraped: 2025-06-29T05:02:36.615961
---

[ Skip to main content ](https://www.scrum.org/events/12218/agile-cincy-conference#main-content)
#  Agile Cincy Conference
United States
Agile Cincinnati is rolling out the red carpet to the most well-known Agile leaders, and you're invited! Come learn, network, and experience Agile in Cincinnati!
The annual AgileCincy Conference is tailored to business professionals looking for actionable learnings. Speakers and break-out sessions cover baseline topics like storyboarding and working with Agile principles, core topics like retrospectives and backlog management, and progressive topics like Agile Fluency and OpenSpace Agility. The AgileCincy Conference attendee roster include your peers - motivated to improve their Agile team - and your competition - innovators ready to launch Agile teams at the company next-door. Let’s join together for some entertaining Agile games, thought-provoking discussions, and world-class collaboration!
Featured speakers include
  * [Stephanie Ockerman](https://www.scrum.org/user/204)


By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
