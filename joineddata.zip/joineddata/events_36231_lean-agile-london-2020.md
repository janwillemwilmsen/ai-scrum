---
source_url: https://www.scrum.org/events/36231/lean-agile-london-2020
date_scraped: 2025-06-29T05:32:59.389794
---

[ Skip to main content ](https://www.scrum.org/events/36231/lean-agile-london-2020#main-content)
#  Lean Agile London 2020
United Kingdom
Lean Agile London will take place on 27-28 April 2020. Speakers include Professional Scrum Trainers Dan Vacanti, Glaudia Califano, and Andy Hiles.
[ visit event website ](https://leanagile.london/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
