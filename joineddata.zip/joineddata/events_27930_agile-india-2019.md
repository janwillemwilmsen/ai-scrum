---
source_url: https://www.scrum.org/events/27930/agile-india-2019
date_scraped: 2025-06-29T05:17:51.325247
---

[ Skip to main content ](https://www.scrum.org/events/27930/agile-india-2019#main-content)
#  Agile India 2019
India
Agile India is organized by Agile Software Community of India, a non-profit registered society founded in 2004 with a vision to evangelize new, better ways of building products & services that delight the users.
Over the last **15 years** , we've organized **57 conferences** across **13 cities** in India. We've hosted **1,000+ speakers** from **38 countries** , who have delivered **1,200+** **sessions** to **10,000+** **attendees**. We continue to be a non-profit, volunteer-run community conference.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
