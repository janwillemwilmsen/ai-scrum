---
source_url: https://www.scrum.org/events/41304/manage-agile-2020
date_scraped: 2025-06-29T05:35:27.142358
---

[ Skip to main content ](https://www.scrum.org/events/41304/manage-agile-2020#main-content)
#  Manage Agile 2020
Germany
**The Manage Agile 2020 is becoming hybrid**
The Manage Agile from November 24 to 26, 2020, in Berlin will be offered as a hybrid conference for the first time. What does hybrid mean? Both the speakers and the participants have the choice of participating in the conference on-site or online. 
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
