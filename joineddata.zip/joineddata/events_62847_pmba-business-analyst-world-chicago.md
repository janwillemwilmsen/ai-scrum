---
source_url: https://www.scrum.org/events/62847/pmba-business-analyst-world-chicago
date_scraped: 2025-06-29T05:49:14.558839
---

[ Skip to main content ](https://www.scrum.org/events/62847/pmba-business-analyst-world-chicago#main-content)
#  PMBA - Business Analyst World - Chicago
United States
BusinessAnalystWorld is the largest conference for Business Analysts in North America. This industry leading event features expert speakers representing every sector, from all reaches of the globe.
From the opening Keynote to the close, BusinessAnalystWorld offers tangible education and non-stop opportunities to learn. You will leave feeling invigorated and motivated, armed with new skills, tools, and techniques that can be immediately applied in your workplace – not to mention an arsenal of new contacts. BusinessAnalystWorld places great importance on connecting you with others in your community.
PST [Robb Pieper](https://www.scrum.org/robert-pieper) will be speaking at the event and Scrum.org will have a booth there with Responsive Advisors.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
