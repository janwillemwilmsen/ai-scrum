---
source_url: https://www.scrum.org/events/63678/ascent-global-conference
date_scraped: 2025-06-29T05:49:50.177630
---

[ Skip to main content ](https://www.scrum.org/events/63678/ascent-global-conference#main-content)
#  Ascent Global Conference
United States
The 5th Annual Ascent Conference is the #1 SaaS conference on the East Coast built specifically for busy C-level GTM leaders – CEOs, CROs, and CMOs.
On November 14-15th, we’ll gather 1,500 of the top go-to-market leaders in the country for exclusive networking, 150+ C-level roundtables, and 30+ hours of stage content looking at the biggest trends in SaaS over the next year. Dave West will be speaking at the event with a talk titled Team First – What we have learned from 25 years of Scrum.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
