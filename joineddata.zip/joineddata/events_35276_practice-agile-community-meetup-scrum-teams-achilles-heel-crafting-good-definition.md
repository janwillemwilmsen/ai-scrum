---
source_url: https://www.scrum.org/events/35276/practice-agile-community-meetup-scrum-teams-achilles-heel-crafting-good-definition
date_scraped: 2025-06-29T05:32:16.480386
---

[ Skip to main content ](https://www.scrum.org/events/35276/practice-agile-community-meetup-scrum-teams-achilles-heel-crafting-good-definition#main-content)
#  Practice Agile Community Meetup - Scrum Team's Achilles Heel - Crafting Good Definition of "Done"
India
This event will dive into the root cause of why Agile Teams struggle to deliver working software every Sprint. Keep your energy level high for the fun-filled learning activities to challenge the existing thought process. Let's ask our toughest questions and explore the opportunities to improve our practices! 
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
