---
source_url: https://www.scrum.org/events/28758/agile-africa-2019
date_scraped: 2025-06-29T05:19:42.776408
---

[ Skip to main content ](https://www.scrum.org/events/28758/agile-africa-2019#main-content)
#  Agile in Africa 2019
Ghana
Agile in Africa (AiA19) will be happening again on 23rd – 25th October 2019 at Accra Digital Center.
Our theme for this year’s conference is: “Become Agile, Produce Better Results”
[ visit event website ](https://agileinafrica.com/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
