---
source_url: https://www.scrum.org/events/16004/ascent-conference-2018
date_scraped: 2025-06-29T05:07:13.559669
---

[ Skip to main content ](https://www.scrum.org/events/16004/ascent-conference-2018#main-content)
#  Ascent Conference 2018
Ascent unites the East Coast tech community for two days of talks, groundbreaking startups, round-table discussions, gala events, and experiences all designed to build lasting connections and to edify our guests. Scrum.org will be sponsoring and exhibiting at the conference. Please stop by our booth to say hello!
[ visit event website ](https://www.ascentconf.com/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
