---
source_url: https://www.scrum.org/events/52234/regional-scrum-gathering-belgrade-2021
date_scraped: 2025-06-29T05:44:05.478374
---

[ Skip to main content ](https://www.scrum.org/events/52234/regional-scrum-gathering-belgrade-2021#main-content)
#  Regional Scrum Gathering Belgrade 2021
Regional Scrum Gathering ℠ is a global event of like-minded Agile practitioners, developers, trainers, coaches, and enthusiasts. As truly a unique and valuable experience, this is an incredibly important Agile ceremony for each person and organization! Welcome! Patricia Kong and Gunther Verheyen will be speaking at the event. 
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
