---
source_url: https://www.scrum.org/events/42462/agile-devops-east
date_scraped: 2025-06-29T05:37:08.330688
---

[ Skip to main content ](https://www.scrum.org/events/42462/agile-devops-east#main-content)
#  Agile + DevOps East
In light of recent events, TechWell has morphed the popular Agile + DevOps East conference into a fully virtual experience this year! From the comfort of your own digital device, you will have access to all of the same great content and experts you have come to expect from an Agile + DevOps East conference. Agile + DevOps Virtual will be **streaming over 75 talks—including 5 keynotes, 20+ tutorials, 40+ sessions, and 10+ Industry Technical Presentations** all in an engaging and interactive premium virtual atmosphere. Plus, with 3 packages to choose from and a variety of exciting add-on options (such as a live virtual training class or the Agile Leadership Summit), you can select the conference package that fits your needs and your budget!
Patricia Kong and Professional Scrum Trainer Ryan Ripley will be speaking at the event.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
