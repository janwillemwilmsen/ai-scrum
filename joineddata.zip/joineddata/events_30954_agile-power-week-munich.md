---
source_url: https://www.scrum.org/events/30954/agile-power-week-munich
date_scraped: 2025-06-29T05:23:50.560896
---

[ Skip to main content ](https://www.scrum.org/events/30954/agile-power-week-munich#main-content)
#  Agile Power Week Munich
Germany
The Agile Power Week in Munich October 2019 is a on of its kind training event for organizations and individuals alike. For the first time ever, we are organizing numerous certification trainings in parallel on OCT 21-22 followed by a combined Keynote + Open Space event on OCT 23. The Agile Power Week is targeted towards in-house-training managers and entire teams that are looking for a variety of agile training courses at the same time. During breaks and especially during the 3rd day, attendees from the various courses and put their learning experiences back together. As a positive side-effect, participants will also experience and learn how to organize and run an Open Space in their organizations.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
