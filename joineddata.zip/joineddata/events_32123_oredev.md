---
source_url: https://www.scrum.org/events/32123/oredev
date_scraped: 2025-06-29T05:26:32.879333
---

[ Skip to main content ](https://www.scrum.org/events/32123/oredev#main-content)
#  Øredev
Sweden
Øredev is the perfect blend, with one day of in-depth pre-conference workshops and three days of sessions, you will get tons of inspiration and learning to keep you creating your best work all year long. Professional Scrum Trainer [Julia Wester](https://www.scrum.org/julia-wester) will be speaking at this event.
[ visit event website ](https://oredev.org/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
