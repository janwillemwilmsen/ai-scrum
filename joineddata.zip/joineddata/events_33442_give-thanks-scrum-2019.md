---
source_url: https://www.scrum.org/events/33442/give-thanks-scrum-2019
date_scraped: 2025-06-29T05:29:23.575424
---

[ Skip to main content ](https://www.scrum.org/events/33442/give-thanks-scrum-2019#main-content)
#  Give Thanks for Scrum 2019
Join us on **Tuesday November 26, 2019** in Burlington Massachusetts for Agile Boston’s **11th Annual Give Thanks For Scrum** event.
You may not know that Scrum was born in Boston and thus its very appropriate that Give Thanks For Scrum has become a true Agile Boston tradition! Register now and get **Jeff Sutherland, David West,** and**Daniel Mezick** for the WHOLE DAY, where they will give individual presentations and then join forces to answer your toughest Scrum questions in a special afternoon Q&A session. Patricia Kong will also be hosting a workshop - How to keep your Scrum from Losing its “Why”: An Introduction to Measuring with Evidence-Based Management.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
