---
source_url: https://www.scrum.org/events/41308/scrum-week
date_scraped: 2025-06-29T05:35:33.061558
---

[ Skip to main content ](https://www.scrum.org/events/41308/scrum-week#main-content)
#  Scrum Week
Peru
Scrum Week
Welcome to our free Scrum Week event. 4 days in a row where we will talk about Scrum and its impact on delivering value through product innovation and empiricism.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
