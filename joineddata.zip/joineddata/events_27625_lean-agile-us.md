---
source_url: https://www.scrum.org/events/27625/lean-agile-us
date_scraped: 2025-06-29T05:17:02.530020
---

[ Skip to main content ](https://www.scrum.org/events/27625/lean-agile-us#main-content)
#  Lean Agile US
LeanAgileUS is the premier conference for Lean and Agile discussion in North America. Nowhere else can you find this unique blend of all flavors of Agile. Come join us to hear world-class speakers, engage with great people and share ideas with some of the best agile minds in the world. Professional Scrum Trainer [Evelien Roos](https://www.scrum.org/evelien-roos) will be speaking at this event. 
[ visit event website ](http://leanagileus.com/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
