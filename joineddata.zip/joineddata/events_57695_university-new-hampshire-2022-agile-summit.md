---
source_url: https://www.scrum.org/events/57695/university-new-hampshire-2022-agile-summit
date_scraped: 2025-06-29T05:46:16.358515
---

[ Skip to main content ](https://www.scrum.org/events/57695/university-new-hampshire-2022-agile-summit#main-content)
#  University of New Hampshire - 2022 Agile Summit
This year's Agile Summit will focus on Agile in a Remote Environment. Patricia Kong will be moderating a panel - Agile Applications in a Broader Business Setting, where the discussion will focus on Agile in non-software environments.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
