---
source_url: https://www.scrum.org/events/43357/semana-del-escalamiento-en-scrum
date_scraped: 2025-06-29T05:37:52.819109
---

[ Skip to main content ](https://www.scrum.org/events/43357/semana-del-escalamiento-en-scrum#main-content)
#  Semana del Escalamiento en Scrum
Semana del Escalamiento en Scrum Del 16 al 19 de Noviembre.
Hora: 5:00 pm. a 5:50 pm. en cada día.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
