---
source_url: https://www.scrum.org/events/30439/project-world-business-analyst-world-toronto
date_scraped: 2025-06-29T05:22:44.869780
---

[ Skip to main content ](https://www.scrum.org/events/30439/project-world-business-analyst-world-toronto#main-content)
#  Project World/ Business Analyst World - Toronto
Canada
ProjectWorld*BusinessAnalystWorld is the largest series of conferences for Project Managers and Business Analysts in North America. These industry leading events feature expert speakers representing every sector, from all reaches of the globe.
From the opening Keynote to the close, ProjectWorld*BAWorld events offers tangible education and non-stop opportunities to learn. You will leave feeling invigorated and motivated, armed with new skills, tools and techniques that can be immediately applied in your workplace - not to mention an arsenal of new contacts. PW*BAW places great importance in connecting you with others in your community.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
