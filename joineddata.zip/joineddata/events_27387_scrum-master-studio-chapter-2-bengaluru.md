---
source_url: https://www.scrum.org/events/27387/scrum-master-studio-chapter-2-bengaluru
date_scraped: 2025-06-29T05:15:58.896335
---

[ Skip to main content ](https://www.scrum.org/events/27387/scrum-master-studio-chapter-2-bengaluru#main-content)
#  Scrum Master Studio Chapter 2 - Bengaluru
India
The "Scrum Master Studio" is intended to instill skills within Scrum Masters to create them as future leaders. Leadership require learning, convincing, nurturing and bringing in Change. That doesn't happen overnight, but its a journey. Come Role Play. This is a platform to Improve your leadership skills and meet like minded people to broaden your Systemic Thinking Skills. 
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
