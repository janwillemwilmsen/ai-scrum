---
source_url: https://www.scrum.org/events/59991/witis-28th-annual-women-technology-summit
date_scraped: 2025-06-29T05:47:10.484666
---

[ Skip to main content ](https://www.scrum.org/events/59991/witis-28th-annual-women-technology-summit#main-content)
#  WITI's 28th Annual Women in Technology Summit
Forward-thinking women understand that climate change is an urgent challenge, a generational responsibility … AND a professional opportunity. The good news is that we women in technology are the world’s best bet in the fight for a clean, healthy, and sustainable planet.
And we have the tools to do it: Digital Transformation (DX) helps organizations do a better job of both delivering their traditional value propositions and creating new ones – especially those focused on sustainability. Accenture finds that by using public cloud services, enterprises could cut their IT-related greenhouse gas emissions by some 6%, the equivalent of taking 22 million cars off the road.
At the crux of achieving sustainability through DX are exciting new technologies like artificial intelligence, blockchain, cloud computing, and the Internet of Things. This will create both technical and non-technical career opportunities, and WITI is here to help you explore them. 
**Patricia Kong will be moderating a panel discussion at this event - Facilitating Progress in a Virtual Setting. Professional Scrum Trainers Magdalena Firlit, Glaudia Califano and Mica Syjuco will be panelists.**
[ visit event website ](https://summit.witi.com/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
