---
source_url: https://www.scrum.org/events/75431/brewing-agile
date_scraped: 2025-06-29T05:52:59.212450
---

[ Skip to main content ](https://www.scrum.org/events/75431/brewing-agile#main-content)
#  Brewing Agile 
Sweden
Brewing Agile is a conference created to spread and debate the practice of agile. We hope that everyone, regardless of background, will be able to take something with them from the conference. It will take place October 18-19 in Göteborg, Sweden
They want to invite not only developers but, project managers, marketing professionals, sales people, and many others. Anyone with passion about their products! Brewing Agile focuses on agile thinking and process, rather than the technical. PSTs [Gunther Verheyen](https://www.scrum.org/gunther-verheyen) and [Julia Wester](https://www.scrum.org/julia-wester) will be providing workshops at the event.
[ Visit event website ](https://brewingagile.org/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
