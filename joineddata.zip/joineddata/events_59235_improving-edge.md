---
source_url: https://www.scrum.org/events/59235/improving-edge
date_scraped: 2025-06-29T05:46:58.707235
---

[ Skip to main content ](https://www.scrum.org/events/59235/improving-edge#main-content)
#  The Improving Edge
Improving Edge was designed from the ground up to bring as much value to the community as possible. We are leveraging our long standing relationships and community connections, to pull together a schedule of speakers that should bring value to individuals, executives, and team leaders alike. If you are looking for inspiration, new tips and techniques, or fellowship in the community then the Improving Edge is for you.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
