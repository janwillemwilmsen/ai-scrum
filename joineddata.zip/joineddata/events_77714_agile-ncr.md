---
source_url: https://www.scrum.org/events/77714/agile-ncr
date_scraped: 2025-06-29T05:54:23.371181
---

[ Skip to main content ](https://www.scrum.org/events/77714/agile-ncr#main-content)
#  Agile NCR
India
AgileNCR is an annual Agile software development conference organized by Xebia and Agile enthusiasts of the NCR region. The first conference was held in 2007 when Agile software development was in nascent stages in India. Now it is conducted every year with a new -conference theme and the presentations made are suitable for beginner to expert level adopters of Agile. 
[ Visit event website ](https://agilencr.org/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
