---
source_url: https://www.scrum.org/events/44503/agility-today-fest-unconference
date_scraped: 2025-06-29T05:38:48.813758
---

[ Skip to main content ](https://www.scrum.org/events/44503/agility-today-fest-unconference#main-content)
#  Agility Today Fest - Unconference
Every year AgileVirgin (A country-wide CoP for Agilists in India) and Agile Alliance organize a few months long learning and networking fest in India for Agile Community Development. This fest is called AgilityToday. It offers multiple Agility enabling spaces and intends to establish a cultural exchange for Agilists across the globe. This year it is virtual and hence enables everyone to join it from their home. This year the Unconference event will be held February 27-28 2021.
[ visit event website ](https://2021.agilitytoday.com/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
