---
source_url: https://www.scrum.org/events/36713/lean-agile-us
date_scraped: 2025-06-29T05:33:58.006994
---

[ Skip to main content ](https://www.scrum.org/events/36713/lean-agile-us#main-content)
#  Lean Agile US
United States
​LeanAgileUS is the premier conference for Lean and Agile discussion in North America. Nowhere else can you find this unique blend of all flavours of Agile. Come join us to hear world-class speakers, engage with great people and share ideas with some of the best agile minds in the world. Scrum.org is sponsoring the event. Professional Scrum Trainers John Coleman, Jose Casal, JP Bayley and Julia Wester are speaking at the event.
[ visit event website ](https://leanagileus.com/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
