---
source_url: https://www.scrum.org/events/4282/openslava-2016
date_scraped: 2025-06-29T04:57:10.847932
---

[ Skip to main content ](https://www.scrum.org/events/4282/openslava-2016#main-content)
#  OPENSLAVA 2016
Slovakia
Accenture, the world's leading consulting, technology and outsourcing company, invites you to this October conference on the current and emerging technologies within the open source ecosystem.
You should consider attending OpenSlava 2016 if you are
  * A technology architect or developer
  * An IT consultant
  * An IT student or a teacher from an IT university/faculty
  * Or simply an IT enthusiast interested in the latest trends in open source and Java


By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
