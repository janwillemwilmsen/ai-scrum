---
source_url: https://www.scrum.org/events/48178/scrum-day-europe
date_scraped: 2025-06-29T05:41:03.058417
---

[ Skip to main content ](https://www.scrum.org/events/48178/scrum-day-europe#main-content)
#  Scrum Day Europe
**SHAPING AGILE TEAMS AND ORGANIZATIONS IN A HYBRID WORLD**
It’s almost time for the 9th edition of Scrum Day Europe, the event for and by the Agile community and friends of Scrum. This year’s edition will be all about shaping Agile Teams and Organizations in a hybrid world. Online value delivery with Scrum, but going beyond software. Use coupon code SCRUM.ORG FRIEND to save 95 EUR on a regular ticket (does not apply to early bird).
[ visit event website ](https://scrumdayeurope.com/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
