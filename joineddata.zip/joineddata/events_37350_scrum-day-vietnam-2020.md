---
source_url: https://www.scrum.org/events/37350/scrum-day-vietnam-2020
date_scraped: 2025-06-29T05:34:39.600058
---

[ Skip to main content ](https://www.scrum.org/events/37350/scrum-day-vietnam-2020#main-content)
#  Scrum Day Vietnam 2020
Vietnam
Scrum Day Vietnam is a great and exclusive occasion contributed by and for Vietnam Scrum/ Agile community and friends. This virtual event is a perfect place for people who are interested in Scrum/ Agile. This is the good opportunity to meet and interact with presenters as Professional Scrum Trainers and like-minded peers who can share their experiences and lessons learned.
The Professional Scrum Trainers speaking at the event are:[Gunther Verheyen](https://www.scrum.org/gunther-verheyen), [Khoa Doan](https://www.scrum.org/khoa-doan-tien), [Chee Hong Hsia](https://www.scrum.org/chee-hong-hsia), [Lorenz Cheung](https://www.scrum.org/lorenz-cheung) , [Shirley Santiago](https://www.scrum.org/shirley-santiago), Tony Lee, Sjoerd Kranendonk, Sanjay Saini
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
