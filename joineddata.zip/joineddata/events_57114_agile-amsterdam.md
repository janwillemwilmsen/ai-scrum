---
source_url: https://www.scrum.org/events/57114/agile-amsterdam
date_scraped: 2025-06-29T05:45:48.968193
---

[ Skip to main content ](https://www.scrum.org/events/57114/agile-amsterdam#main-content)
#  Agile Amsterdam
Netherlands
The yearly Agile Amsterdam conferences are among the best Agile conferences in Europe. Their line-up of thought-leaders and companies are always impressive and carefully selected. Together with several workshops, masterclasses, and an open space, they make sure the event is always highly interactive, meaningful, and fun!
The theme of Agile Amsterdam 2022 is ‘Agile Adoption’. We see an explosive increase in agile adoption across all the functions of the organization, and across the industries, including our schooling system. Why is that? What are our experiences, opportunities, trends, and challenges? 
Come and join us in our lustrum year. The conference day is on Thursday, September 22. Optionally, you can join the warm-up evening on September 21, or extend your conference day with one of our masterclasses on September 23. And for your convenience, we negotiated a very attractive discount on the regular room rates at the Casa hotel.
If you have any additional questions, you can reach out to us via info@agileamsterdam.nl. We are looking forward to welcoming you in Amsterdam!
Dave West will be speaking at this event.
[ Visit Event Website ](https://www.agileamsterdam.nl/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
