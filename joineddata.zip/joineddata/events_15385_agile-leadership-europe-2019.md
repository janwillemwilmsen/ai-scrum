---
source_url: https://www.scrum.org/events/15385/agile-leadership-europe-2019
date_scraped: 2025-06-29T05:06:46.344585
---

[ Skip to main content ](https://www.scrum.org/events/15385/agile-leadership-europe-2019#main-content)
#  Agile Leadership Europe 2019
Nowadays, many organisations work with self-organising teams. That’s why an increasing number of managers question what this means for their role as a leader. Does their role become less important, more important or will it disappear completely and does a new one arise? In addition, it’s being said that managers are leaders, but what does this type of leadership entail? Agile Leadership Europe addresses this question and focuses on the subject ‘(Agile) leadership of the future’. With a variety of speakers, from seasoned management coaches to the authors of popular management books, Agile Leadership Europe promises to be an inspiring day. Will you become the Agile leader of the future? 
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
