---
source_url: https://www.scrum.org/events/35579/scrum-master-studio-surprising-power-retrospectives
date_scraped: 2025-06-29T05:32:42.628269
---

[ Skip to main content ](https://www.scrum.org/events/35579/scrum-master-studio-surprising-power-retrospectives#main-content)
#  Scrum Master Studio - The Surprising Power of Retrospectives
India
This meeting of the Scrum Master Studio will focus on Retrospectives and will feature Professional Scrum Trainer Venkatesh Rajamani.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
