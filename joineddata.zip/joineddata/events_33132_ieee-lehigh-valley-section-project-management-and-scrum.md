---
source_url: https://www.scrum.org/events/33132/ieee-lehigh-valley-section-project-management-and-scrum
date_scraped: 2025-06-29T05:28:54.986926
---

[ Skip to main content ](https://www.scrum.org/events/33132/ieee-lehigh-valley-section-project-management-and-scrum#main-content)
#  IEEE Lehigh Valley Section - Project Management and Scrum
Agenda:
In this meeting, Eric Naiburg will discuss the role of the Scrum Master, the need for project management and how the transition to agile impacts those within an organization. We will talk about the “it depends” response and why it really does depend. The session will cover some of the “soft skills” that are required by the Scrum Master and what may change. We will also talk about other roles in “traditional” organizations and what happens next for them like business analysts, QA and others.
Location: Room: 466 Bldg: Packard Lab Lehigh University 19 Memorial Drive West Bethlehem, Pennsylvania 18015
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
