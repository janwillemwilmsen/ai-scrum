---
source_url: https://www.scrum.org/events/46963/agile-bee-experience
date_scraped: 2025-06-29T05:40:00.912172
---

[ Skip to main content ](https://www.scrum.org/events/46963/agile-bee-experience#main-content)
#  Agile Bee Experience
Organized by the**Bee Lab Academy****ASSESPRO-PR,****Agile Bee Experience**
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
