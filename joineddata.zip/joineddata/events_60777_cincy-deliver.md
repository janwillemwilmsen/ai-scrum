---
source_url: https://www.scrum.org/events/60777/cincy-deliver
date_scraped: 2025-06-29T05:47:38.119510
---

[ Skip to main content ](https://www.scrum.org/events/60777/cincy-deliver#main-content)
#  Cincy Deliver
United States
The Cincinnati Day of Agile is Cincinnati's largest, longest running, community-run non-profit conference dedicated to software development. Founded in 2010, we have seen incredible speakers, attendees, and sponsors as the conference has continued to grow. 2019 saw our largest conference, with over 550 attendees, 32 speakers, and 14 sponsors.
We also introduced Cincy.Develop() in 2017, co-located with the Cincinnati Day of Agile. We believe that truly exceptional teams are cross functional, with everyone working side by side to achieve a common goal. While we have always included technical content in the Day of Agile, adding an entire conference that focuses on the technical allows your entire team to get first class training in one day, in one place.
During the planning of the 2019 year's event, it struck us that the conference is really about delivering software. Our selected sessions covered agile processes and scaling, development, quality, dev-ops, and soft skills. Hence the new name, CincyDeliver!
To simplify navigation, all of the old URLs still work (www.dayofagile.org, www.cincydevelop.org), but the new home that we are promoting is www.cincydeliver.org.
CincyDeliver will be held on Friday, July 29, 2022 at the elegant Manor House in Mason, Ohio. The past two conferences brought in more than 500 attendees. We don't know what to expect this year due to potential limitations and safety concerns.
[ visit event website ](http://www.cincydeliver.org/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
