---
source_url: https://www.scrum.org/events/16402/agile-turkey-2018
date_scraped: 2025-06-29T05:08:47.487207
---

[ Skip to main content ](https://www.scrum.org/events/16402/agile-turkey-2018#main-content)
#  Agile Turkey 2018
Türkiye
Agile Turkey Summit 2018 is a single day, 3 tracks international event gathering Agile enthusiasts together. We would like to invite you to take part in the 6th Agile Turkey Summit at Wyndham Grand Levent, Istanbul, Turkey on 25th October 2018 to discuss the hot topics in Agile world. 
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
