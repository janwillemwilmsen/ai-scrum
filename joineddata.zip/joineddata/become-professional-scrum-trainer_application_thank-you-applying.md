---
source_url: https://www.scrum.org/become-professional-scrum-trainer/application/thank-you-applying
date_scraped: 2025-06-30T00:23:27.659183
---

[ Skip to main content ](https://www.scrum.org/become-professional-scrum-trainer/application/thank-you-applying#main-content)
#  Thank you for Applying
We typically review applications and provide feedback within 10 business days. 
If your application is accepted, the next step will be to participate in an interview with a member of Scrum.org staff. The interview will dig into your experiences with Professional Scrum, offer opportunities for you to showcase your training skills, and explore the overall PST Candidate Journey to ensure this program is a good fit for you. 
Please be aware that we are prioritizing PST candidates who support our diverse population of learners. If you are a woman; increase our racial/ethnic diversity; serve Africa, China, Japan, or Spanish-speaking South and North America; or have significant experience with Scrum in non-software products, we especially want to support you! People who do not meet one of these prioritized characteristics, please be aware you may wait longer to enter the PST community. You can learn more about our focus on diversity on [Supporting the World](https://www.scrum.org/become-professional-scrum-trainer/supporting-world "Supporting the World").
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
