---
source_url: https://www.scrum.org/courses/professional-scrum-training-competency-mapping
date_scraped: 2025-06-30T00:21:34.301582
---

[ Skip to main content ](https://www.scrum.org/courses/professional-scrum-training-competency-mapping#main-content)
#  Professional Scrum Training Competency Mapping
Scrum.org has created these [Professional Scrum Competencies](https://www.scrum.org/professional-scrum-competencies) to help guide an individual’s personal development with Scrum. The flow chart will help you better understand how our [Professional Scrum Training](https://www.scrum.org/courses) courses map to the different Competencies and Focus Areas.
[Download Course Comparison](https://s3.amazonaws.com/static.scrum.org/web/Professional+Scrum+Training+Competency+Mapping_082023+\(1\).pdf)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
