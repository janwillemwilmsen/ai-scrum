---
source_url: https://www.scrum.org/events/33019/agile-tour-dublin
date_scraped: 2025-06-29T05:28:49.290850
---

[ Skip to main content ](https://www.scrum.org/events/33019/agile-tour-dublin#main-content)
#  Agile Tour Dublin
United Kingdom
The 10th Agile Tour conference is taking place in Dublin on October 1st. It is Ireland’s favourite informal agile event to share experiences and exchange ideas. It has grown from 30 participants to 300 but retains a strong feeling of community. For our 10th birthday event we intend to mix talks from international speakers, with talks from within our own agile community. We want to retain a firm focus on our ever increasing local agile knowledge.
Professional Scrum Trainer [Glaudia Califano](https://www.scrum.org/glaudia-califano) will be speaking at the event. 
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
