---
source_url: https://www.scrum.org/events/7901/scrum-days-poland
date_scraped: 2025-06-29T04:59:05.373730
---

[ Skip to main content ](https://www.scrum.org/events/7901/scrum-days-poland#main-content)
#  Scrum Days Poland
Poland
ScrumDays Poland wants to make Software Development professional again. 
Experts like [Barry Overeem](https://www.scrum.org/user/60) and [Dominik Maximini](https://www.scrum.org/user/67) gathered countless experiences from their experiments (mistakes), and share them with you so you won't have to learn some of these lessons the hard way.
This un-conference is truly Agile, with TED-style talks, workshops, a "speaker's pen," lots of open space talks, and even a job corner to connect professionals with organizations.
The conference includes five tracks to deepen your knowledge and understanding:
  * Process Track: the Scrum Mindset
  * Product Track: The Product Owner Mindset
  * Experience Track: Touch and Try
  * Afternoon Workshops & Open Space: Deep Dive
  * Executive Track: High-Level Subjects


By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
