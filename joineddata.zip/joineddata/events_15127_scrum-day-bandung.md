---
source_url: https://www.scrum.org/events/15127/scrum-day-bandung
date_scraped: 2025-06-29T05:05:59.586572
---

[ Skip to main content ](https://www.scrum.org/events/15127/scrum-day-bandung#main-content)
#  Scrum Day Bandung
Indonesia
Scrum Day Bandung 2018 is an exclusive and intense 1-day business agility & modern management with Scrum framework conference. Professional Scrum Trainers [Shirley Santiago](https://www.scrum.org/shirley-santiago) and [Joshua Partogi](https://www.scrum.org/joshua-partogi) will be presenting at the conference.
Scrum Day Bandung 2018 will be  _more than just a conference_. We think it is a regional gathering for like minded people who wish to make a change in management. At Scrum Day Bandung we will implement some of the feedback that we have received from the previous series.
Scrum Day Bandung is one of that event in 2018 you do not want to miss.
Scrum Day Bandung is where great minds come together. Scrum Day Bandung is a perfect place to be for leaders, managers and change agents who have concerns about business agility and professionalism in software delivery ecosystem to meet, exchange experiences and support each other. Unlike other conferences where participants only leave the event with information or knowledge, at Scrum Day Bandung participants will feel inspired and empowered to make changes in their respective companies knowing that others will walk alongside them.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
