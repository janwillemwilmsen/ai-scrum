---
source_url: https://www.scrum.org/events/12270/scrum-day-denmark
date_scraped: 2025-06-29T05:02:42.399917
---

[ Skip to main content ](https://www.scrum.org/events/12270/scrum-day-denmark#main-content)
#  Scrum Day Denmark
Denmark
Get your tickets for this one-of-a-kind conference on the water! This conference cruise where you can learn with world-class Agile experts is not to be missed! Scrum Day Denmark is organized by [Ole Rich Henningsen](https://www.scrum.org/user/100) and [Mads Troels Hansen](https://www.scrum.org/user/97) from Teamdriven together with Scrum.org and sponsors.
Featured speakers include [Gunther Verheyen](https://www.scrum.org/gunther-verheyen) and [Mikkel Toudal Kristiansen](https://www.scrum.org/user/186).
Featured Keynote: "Agility in the face of perplexity."
[ View Event Website ](https://scrumday.dk/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
