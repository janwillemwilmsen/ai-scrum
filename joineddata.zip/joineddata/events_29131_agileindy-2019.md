---
source_url: https://www.scrum.org/events/29131/agileindy-2019
date_scraped: 2025-06-29T05:20:25.546071
---

[ Skip to main content ](https://www.scrum.org/events/29131/agileindy-2019#main-content)
#  AgileIndy 2019
Join us on Friday, April 26, 2019 at the Indianapolis Marriott Downtown for our seventh annual AgileIndy Conference! AgileIndy focuses on bringing thought leaders and practitioners from around the country to Indianapolis for an intense learning and networking experience. Sessions range from agile basics to leadership and technical practices. Whether you are completely new to agile or have been practicing for many years, make this the next stop on your agile journey!
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
