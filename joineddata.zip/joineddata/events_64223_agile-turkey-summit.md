---
source_url: https://www.scrum.org/events/64223/agile-turkey-summit
date_scraped: 2025-06-29T05:50:28.512705
---

[ Skip to main content ](https://www.scrum.org/events/64223/agile-turkey-summit#main-content)
#  Agile Turkey Summit
This is a proud moment for Agile Turkey community. This year we are going to conduct the 10th version of Agile Turkey Summit one of the best Agile conferences all around the world. This year we are opening our virtual doors for the future, the new era after pandemic, the most complex time of world history! Join us on the 24th November and lets discover the future together.
This year is different than others! The event is “completely free*” for all who are eager to learn, discuss and share! We are expecting 5000+ participants (a new record in Agile Turkey history) this year. Please do not hesitate to share the word of Agile Turkey Summit and help us to spread the word.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
