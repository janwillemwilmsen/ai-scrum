---
source_url: https://www.scrum.org/events/63180/give-thanks-scrum-2022
date_scraped: 2025-06-29T05:49:34.902965
---

[ Skip to main content ](https://www.scrum.org/events/63180/give-thanks-scrum-2022#main-content)
#  Give Thanks for Scrum 2022
Join us on Tuesday November 22, 2022 virtually for Agile Boston’s 14th Annual Give Thanks For Scrum event. That’s right … for 2022, the GIVE THANKS FOR SCRUM is once again GOING GLOBAL….over Zoom !!
You may not know that Scrum was born in Boston and thus it is very appropriate that Give Thanks For Scrum has become a true Boston tradition! AND NOW A WORLDWIDE EVENT! Dave West will be speaking at this event and so will PSTs Todd Miller and Ryan Ripley!
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
