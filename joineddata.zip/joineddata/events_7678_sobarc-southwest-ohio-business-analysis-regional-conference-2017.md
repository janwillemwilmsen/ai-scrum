---
source_url: https://www.scrum.org/events/7678/sobarc-southwest-ohio-business-analysis-regional-conference-2017
date_scraped: 2025-06-29T04:58:26.431122
---

[ Skip to main content ](https://www.scrum.org/events/7678/sobarc-southwest-ohio-business-analysis-regional-conference-2017#main-content)
#  SOBARC (Southwest Ohio Business Analysis Regional Conference) 2017
United States
We invite you to the Southwestern Ohio Business Analysis Regional Conference (SOBARC) on Friday, May 5, 2017. For the first time ever, SOBARC will be held at the Kingsgate Marriott Conference Center located near the University of Cincinnati.
As IIBA® Cincinnati Chapter's most exciting & rewarding bi-annual event, the conference is being held to benefit the Greater Cincinnati, Southern Ohio, Southeastern Indiana and Northern Kentucky business communities. This year's theme is value-driven business analysis.
Regardless of your current experience level, you will leave this year's conference with a better understanding of the ever-changing and highly-demanded business analysis profession while engaging with thought leaders in the business analysis industry.
Your presence at this conference is very important to us. Are YOU ready?
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
