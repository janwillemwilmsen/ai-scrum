---
source_url: https://www.scrum.org/events/32122/lean-agile-scotland
date_scraped: 2025-06-29T05:26:28.516860
---

[ Skip to main content ](https://www.scrum.org/events/32122/lean-agile-scotland#main-content)
#  Lean Agile Scotland
United Kingdom
Lean Agile Scotland brings together some of the most engaging minds in the community, to share ideas and help generate new ones.
Returning for its 8th year, Lean Agile Scotland provides three days of inspiring learning from a dynamic mix of stimulating keynotes and practitioners working on the front line of the industry. Professional Scrum Trainer Julia Wester will be speak at this event.
[ visit event website ](https://2019.leanagile.scot/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
