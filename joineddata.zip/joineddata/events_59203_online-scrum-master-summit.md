---
source_url: https://www.scrum.org/events/59203/online-scrum-master-summit
date_scraped: 2025-06-29T05:46:53.865160
---

[ Skip to main content ](https://www.scrum.org/events/59203/online-scrum-master-summit#main-content)
#  Online Scrum Master Summit
No matter how experienced you are as Scrum Master, you are in the right place to learn from other agile experts. During the Scrum Master Summit you can attend 20 sessions with 20 speakers from all over Europe to get tips, tricks and techniques that will help you further in your role as Scrum Master. Get inspired and step up a level in your role as Scrum Master. Professional Scrum Trainer [Evelien Roos](https://www.scrum.org/evelien-roos) will be speaking at the event. 
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
