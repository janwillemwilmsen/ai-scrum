---
source_url: https://www.scrum.org/events/15005/scanagile-18
date_scraped: 2025-06-29T05:05:40.459646
---

[ Skip to main content ](https://www.scrum.org/events/15005/scanagile-18#main-content)
#  ScanAgile 18
Finland
The Scandinavian Agile Conference is a two-day event organized by Agile Finland and focused on Agile software development and Scrum. It takes place in Helsinki and discusses Agile organizations, state of the art in programming practices and Agile coaching.
At the event, Professional Scrum Trainer, [Wim Heemskerk](https://www.scrum.org/user/115 "Wim Heemskerk"), is hosting a workshop titled, "Take ScanAgile to Work" on March 15. 
[ visit event website ](http://www.scan-agile.org/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
