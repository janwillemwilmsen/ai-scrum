---
source_url: https://www.scrum.org/events/33163/european-women-tech
date_scraped: 2025-06-29T05:29:06.071895
---

[ Skip to main content ](https://www.scrum.org/events/33163/european-women-tech#main-content)
#  European Women in Tech
Netherlands
Don’t just be part of the conversation, drive it – join us at Europe's largest and most vibrant women in tech conference.
Following three years of sell-out conferences, European Women in Tech returns to Amsterdam for two days of life-changing content designed to provide you with actionable insights into the tech industry.
Network with thousands of inspirational tech leaders from every corner of the continent. Drive your commercial objectives forward by embracing diversity and inclusion. Deep dive into tech trends that are changing the face of the sector. Leave with the knowledge and drive to write your own success story.
Professional Scrum Trainer Evelien Roos will be speaking at the event. 
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
