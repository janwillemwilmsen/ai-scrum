---
source_url: https://www.scrum.org/events/27280/scrum-day-brazil-2019
date_scraped: 2025-06-29T05:15:43.523822
---

[ Skip to main content ](https://www.scrum.org/events/27280/scrum-day-brazil-2019#main-content)
#  Scrum Day Brazil 2019
Brazil
Scrum Day Brazil 2019 will be held on June 15 and will feature a Keynote from Dave West. Professional Scrum Trainers Barry Overeem, Alexandre MacFadden, Andre Gomes, Andre Coelho and Alexander Hardt will also be presenting. 
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
