---
source_url: https://www.scrum.org/events/48035/agile-vienna
date_scraped: 2025-06-29T05:40:51.374920
---

[ Skip to main content ](https://www.scrum.org/events/48035/agile-vienna#main-content)
#  Agile Vienna
Detailing the entire agile transformation upfront when transitioning from a plan-driven to a value-driven organization neither makes sense, nor does it carry the right message between executives and the rest of the organization during an agile transformation. Because of that, bottom-up or top-down agile transformations may cause friction between the different players in the organization. In addition, the large number of agile processes in the industry and home-grown internal processes can leave employees confused about the strategy of an agile transformation. New leadership topics such as crowd-sourcing, Emotional Intelligence (EQ), self-organization and holacracy are adding to disorientation and often delay the call to action and defer real change. In some instances the agile transformation comes to a standstill and may even fail.
In this conference, we are going to challenge us how to spark, drive and communicate change. Which approach do we take? Is it measurable? Visionairs and companies will share their stories. High quality Workshops and an Open Space complements our learning.
[ Visit Event Website ](https://www.agile-vienna.com/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
