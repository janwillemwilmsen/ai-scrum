---
source_url: https://www.scrum.org/events/36499/agile-day-atlanta-2020
date_scraped: 2025-06-29T05:33:16.453711
---

[ Skip to main content ](https://www.scrum.org/events/36499/agile-day-atlanta-2020#main-content)
#  Agile Day Atlanta 2020
United States
Agile Day Atlanta is a community-driven, one-day Agile conference. Entering our seventh year, their goal is to continue promoting agile methodologies within the Atlanta Agile community.
[ visit event website ](http://agiledayatlanta.com/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
