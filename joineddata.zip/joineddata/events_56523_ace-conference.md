---
source_url: https://www.scrum.org/events/56523/ace-conference
date_scraped: 2025-06-29T05:45:31.959511
---

[ Skip to main content ](https://www.scrum.org/events/56523/ace-conference#main-content)
#  ACE Conference
Poland
ACE! is the largest regional conference of its kind in Central Europe, attracting people from all over the region. We're really excited about the next edition which will combine two tracks: Agile Software Development and Product Design & Management into one conference. - The Building Software Better track includes the traditional ACE! content such as agile, lean, Scrum, Kanban, System Thinking, and other methods for improving the software development process It is a great place to learn for Scrum Masters, Agile Coaches, Project & Product Managers, Team Leaders, attendees on the C-level position and everyone engaged in the Product Delivery process . - The Building Better Products track that features Lean Startup, LeanUX, Design Thinking and Customer Development topics. This track is for everyone involved in creating products, including Product Managers, UI and Interaction Designers, and UX Designers & Researchers.
Professional Scrum Trainers [Magdalena Firlit ](https://www.scrum.org/magdalena-firlit)and[Beata Nowakowska ](https://www.scrum.org/beata-nowakowska)will be speaking at the event. 
[ visit event website ](https://aceconf.com/home)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
