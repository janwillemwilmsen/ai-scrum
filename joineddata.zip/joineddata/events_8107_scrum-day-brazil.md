---
source_url: https://www.scrum.org/events/8107/scrum-day-brazil
date_scraped: 2025-06-29T05:00:15.868198
---

[ Skip to main content ](https://www.scrum.org/events/8107/scrum-day-brazil#main-content)
#  Scrum Day Brazil
Brazil
Brazil's first Scrum Day! This event is a great opportunity for individuals, teams, & managers to increase their success in the search for more Agility and better software development.
The event is run exclusively by Scrum.org's global community of experts and you can increase your networking with other practitioners and Professional Scrum Trainers (PST's) through motivating talks, participating in training, open space sessions, workshops, and more.
Two courses will run after the event:
  * [Scaled Professional Scrum](https://www.scrum.org/courses/scaled-professional-scrum-sao-paulo-sp-2017-06-15-8002) with [Victor Hugo de Oliveira](https://www.scrum.org/user/164)
  * [Professional Scrum Master](https://www.scrum.org/courses/professional-scrum-master-sao-paulo-sp-2017-06-15-8030) with [Stephanie Ockerman](https://www.scrum.org/user/204)


By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
