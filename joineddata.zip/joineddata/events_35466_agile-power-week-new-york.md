---
source_url: https://www.scrum.org/events/35466/agile-power-week-new-york
date_scraped: 2025-06-29T05:32:27.709457
---

[ Skip to main content ](https://www.scrum.org/events/35466/agile-power-week-new-york#main-content)
#  Agile Power Week New York
United States
This first Agile Power Week in New York City takes the original concept to the next level. We are offering a series of parallel certification training courses on March 3-4 followed by an Open Space with Keynote on March 5th. Speakers will include Professional Scrum Trainers Joe Krebs, Nils Oud, Ryan Ripley, and Todd Miller.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
