---
source_url: https://www.scrum.org/events/55244/agility-today-fest
date_scraped: 2025-06-29T05:44:49.268927
---

[ Skip to main content ](https://www.scrum.org/events/55244/agility-today-fest#main-content)
#  Agility Today Fest
AgilityToday is more than just a 2 Days Conference or Training. Hosted by AgileVirgin, this Fest is India’s BIGGEST Agility enabling Fest that spreads over a multi-month canvas and helps Lean-Agile Thought Leaders and Learners in various roles - Scrum Master, Product Owner, Managers, Project Leads & Coordinators, Agile Coaches, Change Agents, Transformation Leaders, and CXOs, with different resources and experiences via different Agility enabling spaces. Each Space is dedicated to a different purpose, to help Agilists who are on different stages of their journeys. Visit the website for more details on the various events within the fest. Professional Scrum Trainers Nisha Patel and Simran Nagrani will be speaking.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
