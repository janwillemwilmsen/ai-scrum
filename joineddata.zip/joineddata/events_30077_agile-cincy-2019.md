---
source_url: https://www.scrum.org/events/30077/agile-cincy-2019
date_scraped: 2025-06-29T05:21:29.104286
---

[ Skip to main content ](https://www.scrum.org/events/30077/agile-cincy-2019#main-content)
#  Agile Cincy 2019
Agile Cincinnati is hand-selecting 29 most innovative and mind-blowing Agile experts from across the nation and local area to share their tips and tricks with the Agile Cincinnati community. Interact with these gurus in a collaborative, fun conference where the focus is on inspiring better practices and solving real challenges. Speakers include Professional Scrum Trainers John Coleman and Chuck Suscheck.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
