---
source_url: https://www.scrum.org/events/59029/wisconsin-prodcon-2022
date_scraped: 2025-06-29T05:46:48.101657
---

[ Skip to main content ](https://www.scrum.org/events/59029/wisconsin-prodcon-2022#main-content)
#  Wisconsin ProdCon 2022
nvisia is excited to bring ProdCon back to life in 2022 after a two year break. This will be nvisia's sixth year of organizing annual tech events. It's no secret that Milwaukee is viewed as a "technology underdog" by other major tech hub cities throughout the United States. Our "why" for organizing these events is to unite the local and surrounding tech communities. We hope to inspire, make connections and empower the tech community as a whole to succeed and grow. PST Mary Iqbal will be speaking at the event. 
[ visit event website ](https://www.prodconwi.com/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
