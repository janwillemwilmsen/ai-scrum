---
source_url: https://www.scrum.org/events/27370/agile-spain-2018
date_scraped: 2025-06-29T05:15:53.250534
---

[ Skip to main content ](https://www.scrum.org/events/27370/agile-spain-2018#main-content)
#  Agile Spain 2018
Spain
CAS 2018 is a conference created by people who understand CAS is a meeting point for professionals in the agile industry to share knowledge and exchange experience in agile.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
