---
source_url: https://www.scrum.org/events/44502/agility-today-fest-agile-career-bootcamp
date_scraped: 2025-06-29T05:38:44.187571
---

[ Skip to main content ](https://www.scrum.org/events/44502/agility-today-fest-agile-career-bootcamp#main-content)
#  Agility Today Fest - Agile Career Bootcamp
Every year AgileVirgin (A country-wide CoP for Agilists in India) and Agile Alliance organize a few months long learning and networking fest in India for Agile Community Development. This fest is called **AgilityToday**. It offers multiple Agility enabling spaces and intends to establish a cultural exchange for Agilists across the globe. This year it is virtual and hence enables everyone to join it from their home. The Agile Career Bootcamp event takes place February 6 and 7.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
