---
source_url: https://www.scrum.org/events/72661/2023-product-owner-conference
date_scraped: 2025-06-29T05:52:21.462916
---

[ Skip to main content ](https://www.scrum.org/events/72661/2023-product-owner-conference#main-content)
#  2023 Product Owner Conference
**Virtual - June 16, 2023**
**By Product Owners, for Product Owners**
Free admission
Sponsored by , Scrum.org, and ProductOwners.nl. 
**'Product Leadership 3.0. The next level in leading your business'**
  * The impact of disruptive technologies and trends, like ChatGPT
  * Product Ownership in non-IT functions. Is it different? What can we learn? Learn from e.g. ASML
  * Tools and Techniques for more effective Product Ownership
  * , where participants determine the agenda topics and discuss their topics in smaller groups (e.g. You can bring in the topic 'How to remain valueable as a PO in tomorrow's job market', and then facilitate that topic in a break-out session with others who are interested in your topic)


[ Visit Event Website ](https://www.poconference.nl/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
