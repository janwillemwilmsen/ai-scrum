---
source_url: https://www.scrum.org/events/63769/festival-agile-trends
date_scraped: 2025-06-29T05:50:17.175253
---

[ Skip to main content ](https://www.scrum.org/events/63769/festival-agile-trends#main-content)
#  Festival Agile Trends
Festival Agile Trends is a free, online event sponsored by Banco Santander and supported by several organizations.
Our goal is to bring together experts worldwide to share their experiences and help people and companies interested in developing and evolving their agile practices.
Patricia Kong will be speaking at this event.
[ Visit Event Website ](https://agiletrends.online/en/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
