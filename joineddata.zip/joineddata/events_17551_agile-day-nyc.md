---
source_url: https://www.scrum.org/events/17551/agile-day-nyc
date_scraped: 2025-06-29T05:10:05.718973
---

[ Skip to main content ](https://www.scrum.org/events/17551/agile-day-nyc#main-content)
#  Agile Day NYC
We are getting ready for the 9th Annual Agile Day 2018 in New York City. The conference will be held Wednesday September 5th at Pace University. The keynote will be delivered by Caitlin Walker who will be coming to the Big Apple from Liverpool. Scrum.org will be sponsoring the event. Be sure to stop by our booth!
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
