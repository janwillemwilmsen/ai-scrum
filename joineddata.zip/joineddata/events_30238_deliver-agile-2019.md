---
source_url: https://www.scrum.org/events/30238/deliver-agile-2019
date_scraped: 2025-06-29T05:22:22.727292
---

[ Skip to main content ](https://www.scrum.org/events/30238/deliver-agile-2019#main-content)
#  Deliver Agile 2019
The 3-day event is built around [3 themes](https://www.agilealliance.org/deliveragile-2019/about/#themes) and will explore topics such as:
  * New and updated core Agile development practices
  * The integration of user experience (UX) principles
  * Advances in testing practices and automation
  * The evolution of tools and techniques that bridge development, deployment, and operations
  * The growing importance of Big Data across the entire spectrum of activities


Professional Scrum Trainer [Martin Hinshelwood](https://www.scrum.org/martin-hinshelwood) will be presenting a talk at the event on May 1 titled - Scaling Unicorns and how to tame them.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
