---
source_url: https://www.scrum.org/events/41701/agile-ncr-2020
date_scraped: 2025-06-29T05:35:44.334756
---

[ Skip to main content ](https://www.scrum.org/events/41701/agile-ncr-2020#main-content)
#  Agile NCR 2020
This year's Agile NCR event will be a live virtual event and will feature speakers including Professional Scrum Trainers Gunther Verheyen, Raju K and Steve Porter.
[ visit event website ](http://www.agilencr.org)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
