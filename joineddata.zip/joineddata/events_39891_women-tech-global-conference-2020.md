---
source_url: https://www.scrum.org/events/39891/women-tech-global-conference-2020
date_scraped: 2025-06-29T05:35:08.934339
---

[ Skip to main content ](https://www.scrum.org/events/39891/women-tech-global-conference-2020#main-content)
#  Women Tech Global Conference 2020
**A GLOBAL NETWORK FOR WOMEN IN TECH!**
### **Join us for invite-only events supporting women in tech, especially engineers, product managers, UX designers and digital marketeers to network, learn from each other and identify opportunities at diversity-focused companies.**
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
