---
source_url: https://www.scrum.org/events/52212/project-management-business-analyst-world-global
date_scraped: 2025-06-29T05:43:59.735336
---

[ Skip to main content ](https://www.scrum.org/events/52212/project-management-business-analyst-world-global#main-content)
#  Project Management Business Analyst World - Global
ProjectWorld*ProjectSummit*BusinessAnalystWorld GLOBAL is the largest virtual conference for Project Managers and Business Analysts in North America. This industry leading event features expert speakers representing every sector, from all reaches of the globe.
From the opening Keynote to the close, ProjectWorld*ProjectSummit*BusinessAnalystWorld GLOBAL offers tangible education and non-stop opportunities to learn. You will leave feeling invigorated and motivated, armed with new skills, tools, and techniques that can be immediately applied in your workplace – not to mention an arsenal of new contacts. PW*PS*BAW Global places great importance on connecting you with others in your community.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
