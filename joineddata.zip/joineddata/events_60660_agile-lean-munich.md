---
source_url: https://www.scrum.org/events/60660/agile-lean-munich
date_scraped: 2025-06-29T05:47:27.214856
---

[ Skip to main content ](https://www.scrum.org/events/60660/agile-lean-munich#main-content)
#  Agile Lean Munich
Germany
Die Agile Lean Munich ist eine Open Space* Konferenz von der agilen Community für die agile Community und alle, die zu ihr stoßen möchten.
Egal ob Du Anfänger:in, fortgeschritten oder Expert:in bist, auf der ALM findest Du Gleichgesinnte, die sich mit Dir austauschen wollen.
Du bist Product Owner:in, Scrum Master:in, Entwickler:in, Frühungskraft oder arbeitest im Bereich HR?
Du oder Dein Unternehmen steht gerade am Anfang der agilen Reise, strauchelt gerade mittendrin oder habt teilenswerte Erfahrungen gemacht?
Auf der ALM kannst Du Dein Wissen teilen oder auch einfach Deine Fragen mitbringen.
Komm vorbei, es lohnt sich! Wir freuen uns auf Dich!
[ Visit Event Website ](https://agile-lean-munich.de/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
