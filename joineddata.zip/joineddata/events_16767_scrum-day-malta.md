---
source_url: https://www.scrum.org/events/16767/scrum-day-malta
date_scraped: 2025-06-29T05:09:15.880206
---

[ Skip to main content ](https://www.scrum.org/events/16767/scrum-day-malta#main-content)
#  Scrum Day Malta
On this second round of the annual agile conference, we bring you a Scrum Day themed on **"agile transformations"** , with double the attendance, interactive workshops and international speakers. Speakers include Kurt Bittner, VP of Enterprise Solutions and Professional Scrum Trainer [Chris Lukassen.](https://www.scrum.org/chris-lukassen)
[ visit event website ](http://www.scrumdaymalta.com/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
