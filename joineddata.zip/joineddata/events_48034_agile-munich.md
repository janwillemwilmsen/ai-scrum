---
source_url: https://www.scrum.org/events/48034/agile-munich
date_scraped: 2025-06-29T05:40:45.626963
---

[ Skip to main content ](https://www.scrum.org/events/48034/agile-munich#main-content)
#  Agile Munich
Agile Munich is coming up April 21! PST Nils Oud will be speaking.
[ visit event website ](https://www.agilemunich.com/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
