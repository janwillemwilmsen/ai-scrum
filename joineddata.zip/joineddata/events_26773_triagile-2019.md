---
source_url: https://www.scrum.org/events/26773/triagile-2019
date_scraped: 2025-06-29T05:15:00.458131
---

[ Skip to main content ](https://www.scrum.org/events/26773/triagile-2019#main-content)
#  TriAgile 2019
This conference is planned by local agile enthusiasts who are passionate about continuous learning and giving back to the community. Historically, TriAgile has brought together hundreds of individuals of varying backgrounds and professions from in and around the greater RTP area. 
[ visit event website ](https://triagile.com/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
