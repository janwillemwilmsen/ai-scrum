---
source_url: https://www.scrum.org/events/27797/agile-manchester
date_scraped: 2025-06-29T05:17:28.750521
---

[ Skip to main content ](https://www.scrum.org/events/27797/agile-manchester#main-content)
#  Agile Manchester
United Kingdom
Returning for its fifth year, Agile Manchester 2019 is a practical agile development conference that allows participants to connect and learn from their peers and leaders in the industry.
The conference has a strong practical focus and attracts industry practitioners and decision-makers who want to improve their success with agile and lean methods.
The event provides three days of inspiring agile and lean learning from a dynamic mix of stimulating keynotes and practitioners working on the front line of the industry.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
