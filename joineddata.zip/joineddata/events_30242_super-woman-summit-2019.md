---
source_url: https://www.scrum.org/events/30242/super-woman-summit-2019
date_scraped: 2025-06-29T05:22:28.026065
---

[ Skip to main content ](https://www.scrum.org/events/30242/super-woman-summit-2019#main-content)
#  Super Woman Summit 2019
Join us for a transformational experience devoted to inspiring and activating the next generation of strong, successful women leaders. Professional Scrum Trainer Stephanie Ockerman will be facilitating a workshop titled "Stepping into Your Power to Influence Culture Change".
[ visit event website ](https://superwomansummit.com/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
