---
source_url: https://www.scrum.org/events/49952/scrum-day-brazil
date_scraped: 2025-06-29T05:43:14.901206
---

[ Skip to main content ](https://www.scrum.org/events/49952/scrum-day-brazil#main-content)
#  Scrum Day Brazil
Os Scrum Days são eventos de Agilidade e Scrum dirigidos exclusivamente pela comunidade global de especialistas da Scrum.org. O Scrum Day é uma ótima oportunidade para indivíduos e equipes aumentarem as chances de sucesso na busca por melhores resultados no desenvolvimento de software.
[ visit event website ](https://en.scrumday.com.br/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
