---
source_url: https://www.scrum.org/events/36985/scrum-day-chennai-2020
date_scraped: 2025-06-29T05:34:07.209946
---

[ Skip to main content ](https://www.scrum.org/events/36985/scrum-day-chennai-2020#main-content)
#  Scrum Day- Chennai 2020
India
Scrum Day Chennai is tryScrum's flagship conference bringing all the best, most emergent ideas about Organizational Agility and some of the most important global minds working in the field under one roof. Professional Scrum Trainer Daniel Vacanti will be speaking at the event.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
