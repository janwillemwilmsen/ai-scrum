---
source_url: https://www.scrum.org/events/15847/agile-prague-2018
date_scraped: 2025-06-29T05:06:57.177462
---

[ Skip to main content ](https://www.scrum.org/events/15847/agile-prague-2018#main-content)
#  Agile Prague 2018
The theme of the AgilePrague Conference 2018 is "Business Agility". This year we are going to introduce over 30 speakers from all around the world. The conference is running in two parallel tracks in two days, where you can choose from the variety of talks for managers, scrum masters, product owners and try agile practices in practical workshops for testers and developers, share the know-how, discuss in open space. Professional Scrum Trainer [Barry Overeem](https://www.scrum.org/user/60) will be speaking at this event.
[ visit event website ](http://agileprague.com/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
