---
source_url: https://www.scrum.org/events/15184/meetup-scrum-chapter-mumbai-march-2018
date_scraped: 2025-06-29T05:06:04.553335
---

[ Skip to main content ](https://www.scrum.org/events/15184/meetup-scrum-chapter-mumbai-march-2018#main-content)
#  MeetUp - Scrum Chapter Mumbai - March 2018
A Shift from Scrum But to Scrum And 
Presenters: Professional Scrum Trainers, Hiren Doshi and Punit Doshi
In the next Scrum Chapter Mumbai in March 2018, we will explore the repercussions of ScrumButs and explore options to make Scrum implementations stronger by crossing over to ScrumAnd (<https://guntherverheyen.com/2013/12/19/illustrations-of-scrumand/>) making a stronger implementation of Scrum where teams can say, “We use Scrum And engineering practices like Continuous Delivery to have robust framework for delivering value”
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
