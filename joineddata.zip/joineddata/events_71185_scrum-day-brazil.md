---
source_url: https://www.scrum.org/events/71185/scrum-day-brazil
date_scraped: 2025-06-29T05:51:47.970278
---

[ Skip to main content ](https://www.scrum.org/events/71185/scrum-day-brazil#main-content)
#  Scrum Day Brazil
Brazil
Esse é um dos melhores eventos de transformação digital do país e já reuniu mais de 10 mil pessoas.
Acontece há alguns anos em diversos lugares do mundo, como Alemanha, Dinamarca, Inglaterra, EUA, Índia, Polônia, Ucrânia, entre outros.
[ Visit Event Website ](https://www.scrumday.com.br/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
