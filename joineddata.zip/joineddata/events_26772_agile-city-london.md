---
source_url: https://www.scrum.org/events/26772/agile-city-london
date_scraped: 2025-06-29T05:14:54.725399
---

[ Skip to main content ](https://www.scrum.org/events/26772/agile-city-london#main-content)
#  Agile in the City: London
United Kingdom
Agile in the City: London is a hands-on event where participants connect with and learn from their peers and leaders in the industry.
Returning for its fifth year, the conference has a strong practical focus and attracts industry practitioners and decision-makers who want to improve their success with agile and lean methods.
The event provides three days of inspiring agile and lean learning from a dynamic mix of stimulating keynotes and practitioners working on the front line of the industry. Don't miss Jeff Gothelf and Dave West present "Scrum with UX - Moving Beyond Design Sprints" on April 5 at 11 AM!
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
