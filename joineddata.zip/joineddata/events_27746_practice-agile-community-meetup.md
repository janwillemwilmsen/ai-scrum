---
source_url: https://www.scrum.org/events/27746/practice-agile-community-meetup
date_scraped: 2025-06-29T05:17:23.267235
---

[ Skip to main content ](https://www.scrum.org/events/27746/practice-agile-community-meetup#main-content)
#  Practice Agile Community Meetup
India
This meetup at Practice Agile Solutions is an Agile Gamification evening. With years of Agile experience, we have built over 60+ Myth and Fact Cards and the list is still growing. We have used them in our workshops and participants have given us "TWO THUMBS UP"! It's time for us to experiment it with wider audience and we invite everybody to join us in - Community building Understanding Agile, the correct way Empowerment, and more than that ... put your Agile knowledge to test. Practice Agile Myth and Fact cards is an Agile concept testing and team building game. The objective of the game is to score higher points in a buzzer round to decide quickly whether a statement related to Agile is a myth or a fact. Join us for a fun evening with snacks on us!
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
