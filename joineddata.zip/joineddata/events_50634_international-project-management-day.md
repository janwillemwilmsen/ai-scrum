---
source_url: https://www.scrum.org/events/50634/international-project-management-day
date_scraped: 2025-06-29T05:43:20.496684
---

[ Skip to main content ](https://www.scrum.org/events/50634/international-project-management-day#main-content)
#  International Project Management Day
International Project Management Day (IPM Day) is an annual day of recognition for the achievements of project managers and project teams around the world. IIL has planned and delivered an International Project Management Day event every year since the idea was first introduced in 2004. Eric Naiburg will be speaking about Professional Scrum! Use the promo code NAIBURG for $10 off!
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
