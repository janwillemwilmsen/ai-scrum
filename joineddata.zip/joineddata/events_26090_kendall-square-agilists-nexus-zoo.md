---
source_url: https://www.scrum.org/events/26090/kendall-square-agilists-nexus-zoo
date_scraped: 2025-06-29T05:14:17.785075
---

[ Skip to main content ](https://www.scrum.org/events/26090/kendall-square-agilists-nexus-zoo#main-content)
#  Kendall Square Agilists - Nexus Zoo
Patricia Kong of Scrum.org and co-author of the "The Nexus Framework for Scaling Scrum" will lead this session. She'll take us through a game, based on Nexus, that replicates the challenges of scaling product development across many teams. The teams will need to turn their individual features into one collective increment within a Sprint.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
