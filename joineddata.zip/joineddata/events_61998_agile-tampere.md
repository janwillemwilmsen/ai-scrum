---
source_url: https://www.scrum.org/events/61998/agile-tampere
date_scraped: 2025-06-29T05:48:59.393312
---

[ Skip to main content ](https://www.scrum.org/events/61998/agile-tampere#main-content)
#  Agile Tampere
Finland
Agile Tampere is known of its high quality content and focuses to business agility, agile transformations, and how to apply it all even in challenging organisations. PSTs Jose Casal, Julia Wester, Ryan Brook and Andrii Glushchenko are speaking at the event!
What to expect:
  * International keynote presentations followed by exciting stories from different industries
  * Onsite workshops to practice new concepts in a safe-to-fail environment
  * After party, of course!


By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
