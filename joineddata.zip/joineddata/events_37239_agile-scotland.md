---
source_url: https://www.scrum.org/events/37239/agile-scotland
date_scraped: 2025-06-29T05:34:33.543130
---

[ Skip to main content ](https://www.scrum.org/events/37239/agile-scotland#main-content)
#  Agile Scotland
United Kingdom
Agile Scotland aims to make learning with local and international practitioner communities more accessible, affordable, and as inclusive as possible. Professional Scrum Trainer Chris Bexon will be speaking at the event.
Our core organiser team runs Agile Scotland around family, day jobs, and charity work. We are thankful to be supported by fantastic associate organisers across different organisations, groups, and communities.
[ visit event website ](https://www.agilescotland.com/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
