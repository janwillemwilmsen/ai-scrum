---
source_url: https://www.scrum.org/events/47590/agile-camp-berlin
date_scraped: 2025-06-29T05:40:39.822482
---

[ Skip to main content ](https://www.scrum.org/events/47590/agile-camp-berlin#main-content)
#  Agile Camp Berlin
Join the virtual Agile Camp Berlin 2021 and experience three energizing days with 200-plus agile peers focusing on community, sharing, and learning. We will practice games and exercises; we will share tips & tricks, lessons learned, and war stories from the agile trenches—all self-organized in a virtual Barcamp format from May 27-29, 2021.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
