---
source_url: https://www.scrum.org/events/48570/women-technology-international-27th-annual-virtual-summit
date_scraped: 2025-06-29T05:41:25.322955
---

[ Skip to main content ](https://www.scrum.org/events/48570/women-technology-international-27th-annual-virtual-summit#main-content)
#  Women in Technology International 27th Annual Virtual Summit
COME SHARE YOUR TALENTS AND TRIUMPHS AT WITI THIS JUNE — AND LET US CELEBRATE INGENUITY! The WITI (Women In Technology International) 27th Annual Summit — a virtual event to be held June 22-24, 2021 — will feature insights, inspirations, and action items from tech-savvy women worldwide. Professional Scrum Trainers [Mica Syjuco](https://www.scrum.org/micaela-syjuco), [Julee Everett ](https://www.scrum.org/julee-bellomo)and [Stephanie Ockerman](https://www.scrum.org/stephanie-ockerman) will be speaking on a panel titled, Growing Your Career in Agile from 3 Women’s Perspectives: Product Management, Scrum Mastery and Leadership, and Software Development!
[ visit event website ](https://summit.witi.com/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
