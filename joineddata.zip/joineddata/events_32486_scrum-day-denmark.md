---
source_url: https://www.scrum.org/events/32486/scrum-day-denmark
date_scraped: 2025-06-29T05:27:27.862918
---

[ Skip to main content ](https://www.scrum.org/events/32486/scrum-day-denmark#main-content)
#  Scrum Day Denmark
Denmark
Scrum Day Denmark will take place November 25 and will feature talks by Kurt Bittner and Professional Scrum Trainers Gunther Verheyen and Fredrik Wendt.
[ visit event website ](https://scrumday.dk/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
