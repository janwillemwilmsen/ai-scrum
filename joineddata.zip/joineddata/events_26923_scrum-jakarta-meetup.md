---
source_url: https://www.scrum.org/events/26923/scrum-jakarta-meetup
date_scraped: 2025-06-29T05:15:27.246436
---

[ Skip to main content ](https://www.scrum.org/events/26923/scrum-jakarta-meetup#main-content)
#  Scrum Jakarta Meetup
Indonesia
On Monday, November 26, Professional Scrum Trainer Joshua Partogi will present "Value Delivery Optimization Using Scrum" at the Scrum Jakarta Meetup.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
