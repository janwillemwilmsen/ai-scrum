---
source_url: https://www.scrum.org/events/27650/agility-today
date_scraped: 2025-06-29T05:17:13.412516
---

[ Skip to main content ](https://www.scrum.org/events/27650/agility-today#main-content)
#  Agility Today
India
AgilityToday is India’s first 2-day annual “UnConference”, started in Feb 2018, that intends to brings together Agility seekers, learners, practitioner and experts from various Organizations, Domains and Countries – to converse, collaborate and help IT and Software companies and professionals in Delhi-NCR create a truly Agile mindset and work culture.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
