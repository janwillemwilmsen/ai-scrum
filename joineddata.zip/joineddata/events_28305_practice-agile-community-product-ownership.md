---
source_url: https://www.scrum.org/events/28305/practice-agile-community-product-ownership
date_scraped: 2025-06-29T05:18:30.084820
---

[ Skip to main content ](https://www.scrum.org/events/28305/practice-agile-community-product-ownership#main-content)
#  Practice Agile Community - Product Ownership
India
This meetup at Practice Agile Solutions is to dive into Product Ownership role. We are going to have lively discussions surrounding Product Owner role and look into what it takes to become a ROCKSTAR Product Owner. As usual, it will be a high energy get-together of like-minded Agilists in Mumbai to share our experiences. We will be debunking some myths surrounding Product Owner role to help participants understand the accountability of the role. 
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
