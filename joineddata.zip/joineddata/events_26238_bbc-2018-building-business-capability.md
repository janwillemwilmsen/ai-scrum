---
source_url: https://www.scrum.org/events/26238/bbc-2018-building-business-capability
date_scraped: 2025-06-29T05:14:34.341316
---

[ Skip to main content ](https://www.scrum.org/events/26238/bbc-2018-building-business-capability#main-content)
#  BBC 2018 Building Business Capability
BBC 2018 features four concurrent event trails. Trails single out industry areas where there are concentrations of focused business opportunity, extensive vendor tool-sets, and specialized skills and experience.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
