---
source_url: https://www.scrum.org/events/25455/agile-central-pa-meetup-lean-coffee
date_scraped: 2025-06-29T05:12:26.160575
---

[ Skip to main content ](https://www.scrum.org/events/25455/agile-central-pa-meetup-lean-coffee#main-content)
#  Agile Central PA Meetup - Lean Coffee
Let's get together and Lean Coffee style group discussion on any and all Agile practices. Hors d'oeuvres will be provided by ABC. See you there!
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
