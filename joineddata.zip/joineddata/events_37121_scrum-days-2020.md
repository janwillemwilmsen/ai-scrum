---
source_url: https://www.scrum.org/events/37121/scrum-days-2020
date_scraped: 2025-06-29T05:34:17.237136
---

[ Skip to main content ](https://www.scrum.org/events/37121/scrum-days-2020#main-content)
#  Scrum Days 2020
Russia
Scrum Days is an official conference bringing together professionals. All reports and workshops are real cases of implementation and Scrum in organizations. Professional Scrum Trainers Ilia Pavlichenko, Roman Doroschenko, Konstantin Razumobskiy, Sergey Lobin and Gunther Verheyen will be speaking at the event. 
[ visit event website ](http://agilix.ru/scrumday2020)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
