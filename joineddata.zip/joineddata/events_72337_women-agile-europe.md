---
source_url: https://www.scrum.org/events/72337/women-agile-europe
date_scraped: 2025-06-29T05:52:04.653470
---

[ Skip to main content ](https://www.scrum.org/events/72337/women-agile-europe#main-content)
#  Women in Agile Europe
Netherlands
This conference will be in-person on Tuesday 14 November 2023 on a location near Eindhoven, the Netherlands. 
This conference is for all genders, but the stage is reserved to women and non-binary speakers only.
Although this is a non-profit event we ask participants for a small fee for a day with lots of fun, knowledge, networking and practice. 
[ Visit Event Website ](https://womeninagile.eu/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
