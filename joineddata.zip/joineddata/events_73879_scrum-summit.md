---
source_url: https://www.scrum.org/events/73879/scrum-summit
date_scraped: 2025-06-29T05:52:32.654700
---

[ Skip to main content ](https://www.scrum.org/events/73879/scrum-summit#main-content)
#  Scrum Summit
Organizations are everyday evolving, transforming and outmatching the current technology. It requires them to adapt to futuristic solutions and go strength to strength.
The event mission is to address the challenges of the current business environment to explore Scrum for Future, and guide the industry to lead through the volatility by bringing the best knowledge and information from the pioneers and leaders of Scrum, and advance the conversation to actionable ideas.
Leslie Morse from Scrum.org will be speaking at the event!
[ Visit Event Website ](https://www.scrumsummit.org/)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
