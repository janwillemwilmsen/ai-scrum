---
source_url: https://www.scrum.org/events/31335/nexus-taiwan
date_scraped: 2025-06-29T05:24:29.010077
---

[ Skip to main content ](https://www.scrum.org/events/31335/nexus-taiwan#main-content)
#  Nexus in Taiwan
Nexus In Taiwan event organized by the Agile Experts Association and will feature Patricia Kong and Professional Scrum Trainers Lorenz Cheung and Shirley Santiago . At the event, there will be deep discussion on : Scrum Scaling Introduction, The State of Nexus (trends, current status and case studies),and Scaling Challenges. Two Nexus Zoo workshops will also be held at the event.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
