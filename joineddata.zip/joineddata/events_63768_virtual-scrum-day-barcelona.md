---
source_url: https://www.scrum.org/events/63768/virtual-scrum-day-barcelona
date_scraped: 2025-06-29T05:50:12.512752
---

[ Skip to main content ](https://www.scrum.org/events/63768/virtual-scrum-day-barcelona#main-content)
#  Virtual Scrum Day Barcelona
Do you struggle **aligning Scrum with other models, tools and approaches?** In the third edition of Scrumday Barcelona we want to **explore other approaches and create bridges** between Scrum and other approaches! 
Scrum.org has 20 free tickets. Use this code to redeem: **sd22_sdo. Note: These 20 tickets are first come first served.**
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
