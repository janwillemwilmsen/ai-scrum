---
source_url: https://www.scrum.org/events/7993/agile-and-beyond-2017
date_scraped: 2025-06-29T04:59:35.871723
---

[ Skip to main content ](https://www.scrum.org/events/7993/agile-and-beyond-2017#main-content)
#  Agile and Beyond 2017
United States
Agile and Beyond is a grassroots, volunteer run conference. It helps people learn about agile principles and practices as well as covers topics that help make people and companies awesome. With approximately 100 sessions spread across two days, there is a wide variety of topics for the agile newbie all the way through to the agile expert. 
#### Highlighted sessions:
May 4: "[Discover the Power of Pair Testing!](https://aab17.sched.com/event/9WaJ/discover-the-power-of-pair-testing)" with [Pradeepa Narayanaswamy](https://aab17.sched.com/speaker/pradeepa.narayanaswamy?iframe=no&w=100%&sidebar=no&bg=no)
May 5: "[Be Extraordinary: Treat Your Life as the Product](https://aab17.sched.com/event/9WtA/be-extraordinary-treat-your-life-as-the-product)" with [Stephanie Ockerman](https://aab17.sched.com/speaker/stockerman?iframe=no&w=100%&sidebar=no&bg=no)
May 5: "[Scaling Agility in a Large Organization? Meet in the Middle](https://aab17.sched.com/event/9WtE/scaling-agility-in-a-large-organization-meet-in-the-middle)" with [Dave Dame](https://aab17.sched.com/speaker/ddame1?iframe=no&w=100%&sidebar=no&bg=no)
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
