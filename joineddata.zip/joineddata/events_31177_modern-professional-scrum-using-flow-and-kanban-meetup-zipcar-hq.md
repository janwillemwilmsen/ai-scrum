---
source_url: https://www.scrum.org/events/31177/modern-professional-scrum-using-flow-and-kanban-meetup-zipcar-hq
date_scraped: 2025-06-29T05:24:00.700258
---

[ Skip to main content ](https://www.scrum.org/events/31177/modern-professional-scrum-using-flow-and-kanban-meetup-zipcar-hq#main-content)
#  Modern Professional Scrum using Flow and Kanban - Meetup at ZipCar HQ
How can we Leverage Kanban and Flow to improve Scrum?
Should you use Scrum, Kanban, or maybe even DevOps? You don’t have to choose: Scrum teams improve when they look at flows inside and outside their sprints from a Lean/Kanban perspective. In this session, we will talk about Kanban-related myths prevalent in the Scrum world and identify common ground between them. We will look at ways to bring Kanban flow into your Scrum: the Kanban-based Sprint/Product Backlog, flow-based Daily Scrum, visualizing aging work, and flow-based Sprint Planning. We will describe ways to wrap Scrum with a Kanban flow system, and at the higher-level picture of a DevOps culture and process.
You’ll leave with a better understanding of how Scrum, Kanban, and DevOps relate to each other and with ideas for experiments to try when back at work.
Yuval Yeret is a Professional Scrum Trainer at AgileSparks has been practicing Scrum with Kanban since 2007.
By using this site you are agreeing to the [Privacy Policy](https://www.scrum.org/privacy-policy) and [Terms of Service](https://www.scrum.org/website-terms-service)
